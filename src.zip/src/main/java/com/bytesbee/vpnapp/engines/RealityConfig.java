package pvt.zalmiltd.vpn.engines;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URLDecoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * ADDED: a VLESS + REALITY server as used by the Hydra engine (ported from UAE VPN Pro's RealityServerConfig,
 * VlessLinkParser and XrayConfigFactory). Built from a vless://uuid@host:port?params#name share link; REALITY over
 * tcp/raw, xhttp and grpc is accepted, and plain VLESS (security=none) too, since that is what the engine can run.
 * A plain server's traffic is not encrypted by the tunnel itself.
 */
public final class RealityConfig {

    public static final String NETWORK_TCP = "tcp";
    public static final String NETWORK_XHTTP = "xhttp";
    public static final String NETWORK_GRPC = "grpc";

    static final String SECURITY_REALITY = "reality";
    static final String SECURITY_NONE = "none";

    static final String FLOW_VISION = "xtls-rprx-vision";
    static final int DEFAULT_MTU = 1500;

    private static final String SCHEME = "vless://";
    private static final String TUN_NAME = "xray0";
    private static final String TUN_FD_ENV_KEY = "xray.tun.fd";
    private static final String MLKEM_ENCRYPTION_PREFIX = "mlkem768x25519plus.";

    private static final Set<String> SUPPORTED_FLOWS = new HashSet<>(Arrays.asList(FLOW_VISION, FLOW_VISION + "-udp443"));
    private static final Set<String> XHTTP_MODES = new HashSet<>(Arrays.asList("", "auto", "packet-up", "stream-up", "stream-one"));
    private static final Set<String> GRPC_MODES = new HashSet<>(Arrays.asList("", "gun", "multi"));
    private static final Pattern UUID_PATTERN =
            Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");
    //32 raw bytes as unpadded base64url
    private static final Pattern PUBLIC_KEY_PATTERN = Pattern.compile("^[A-Za-z0-9_-]{43}$");
    //up to 8 bytes as hex; an empty short id is valid
    private static final Pattern SHORT_ID_PATTERN = Pattern.compile("^([0-9a-fA-F]{2}){0,8}$");

    String address = "";
    int port = 443;
    String uuid = "";
    String publicKey = "";
    String shortId = "";
    String sni = "";
    String fingerprint = "chrome";
    String flow = "";
    String network = NETWORK_TCP;
    String security = SECURITY_REALITY;
    String encryption = "none";
    String spiderX = "/";
    String path = "/";
    String host = "";
    String mode = "";
    String extra;
    String serviceName = "";
    String authority = "";

    private RealityConfig() {
    }

    /** Server address, for reachability checks. */
    public String address() {
        return address.trim();
    }

    public int port() {
        return port;
    }

    /** @return the parsed server, or null when the link is not something the Hydra engine can run. */
    public static RealityConfig parseOrNull(String link) {
        try {
            return parse(link);
        } catch (Exception e) {
            return null;
        }
    }

    static RealityConfig parse(String link) {
        String trimmed = link == null ? "" : link.trim();
        if (!trimmed.toLowerCase(Locale.ROOT).startsWith(SCHEME)) throw new IllegalArgumentException("not a vless:// link");

        //The name after '#' may hold spaces and emoji and is of no use here
        String body = trimmed.substring(SCHEME.length());
        int hash = body.indexOf('#');
        if (hash >= 0) body = body.substring(0, hash);
        int question = body.indexOf('?');
        String authorityPart = question >= 0 ? body.substring(0, question) : body;
        Map<String, String> query = parseQuery(question >= 0 ? body.substring(question + 1) : "");

        int userInfoEnd = authorityPart.lastIndexOf('@');
        if (userInfoEnd < 0) throw new IllegalArgumentException("missing user id");

        RealityConfig c = new RealityConfig();
        c.uuid = decode(authorityPart.substring(0, userInfoEnd));
        splitHostPort(authorityPart.substring(userInfoEnd + 1), c);

        String security = orEmpty(query.get("security")).toLowerCase(Locale.ROOT);
        if (security.equals(SECURITY_REALITY)) c.security = SECURITY_REALITY;
        else if (security.isEmpty() || security.equals(SECURITY_NONE)) c.security = SECURITY_NONE;
        else throw new IllegalArgumentException("security is not supported");
        String headerType = query.get("headerType");
        if (headerType != null && !headerType.isEmpty() && !"none".equals(headerType)) {
            throw new IllegalArgumentException("tcp header type is not supported");
        }

        String type = orEmpty(query.get("type")).toLowerCase(Locale.ROOT);
        if (type.isEmpty() || type.equals("tcp") || type.equals("raw")) c.network = NETWORK_TCP;
        else if (type.equals("xhttp") || type.equals("splithttp")) c.network = NETWORK_XHTTP;
        else if (type.equals("grpc")) c.network = NETWORK_GRPC;
        else throw new IllegalArgumentException("transport is not supported");

        c.publicKey = orEmpty(query.get("pbk"));
        c.shortId = orEmpty(query.get("sid"));
        c.sni = orEmpty(query.get("sni"));
        c.fingerprint = orDefault(query.get("fp"), "chrome");
        c.flow = orEmpty(query.get("flow"));
        c.encryption = orDefault(query.get("encryption"), "none");
        c.spiderX = orDefault(query.get("spx"), "/");
        c.path = orDefault(query.get("path"), "/");
        c.host = orEmpty(query.get("host"));
        c.mode = NETWORK_TCP.equals(c.network) ? "" : orEmpty(query.get("mode"));
        String extra = query.get("extra");
        c.extra = extra == null || extra.isEmpty() ? null : extra;
        c.serviceName = orEmpty(query.get("serviceName"));
        c.authority = orEmpty(query.get("authority"));

        c.validate();
        return c;
    }

    /** Mirrors what Xray-core itself enforces for VLESS clients, so bad data fails here with a clear message. */
    void validate() {
        String net = network.trim();
        String m = mode.trim();
        String enc = encryption.trim();
        String f = flow.trim();

        require(!address.trim().isEmpty(), "address is empty");
        require(port >= 1 && port <= 65535, "port is out of range");
        require(UUID_PATTERN.matcher(uuid.trim()).matches(), "uuid is not a valid UUID");
        if (isReality()) {
            require(PUBLIC_KEY_PATTERN.matcher(publicKey()).matches(), "public key must be 32 bytes of base64url");
            require(SHORT_ID_PATTERN.matcher(shortId.trim()).matches(), "short id is invalid");
            require(!sni.trim().isEmpty(), "sni is empty");
            require(spiderX.isEmpty() || spiderX.startsWith("/"), "spider x must start with '/'");
        }
        require(net.equals(NETWORK_TCP) || net.equals(NETWORK_XHTTP) || net.equals(NETWORK_GRPC), "network is not supported");
        require(enc.isEmpty() || enc.equals("none") || enc.startsWith(MLKEM_ENCRYPTION_PREFIX), "encryption is not supported");
        require(f.isEmpty() || SUPPORTED_FLOWS.contains(f), "flow is not supported");
        require(f.isEmpty() || net.equals(NETWORK_TCP), "flow needs the tcp network");
        //Vision rides on the outer TLS/REALITY layer; Xray rejects it without one
        require(f.isEmpty() || isReality(), "flow needs reality");
        if (net.equals(NETWORK_XHTTP)) {
            require(XHTTP_MODES.contains(m), "xhttp mode is not supported");
            require(extra == null || extra.trim().isEmpty() || parseObject(extra) != null, "xhttp extra is not a JSON object");
        } else if (net.equals(NETWORK_GRPC)) {
            require(GRPC_MODES.contains(m), "grpc mode is not supported");
        }
    }

    /** Full Xray config: TUN inbound on [tunFd] (the caller keeps ownership), VLESS + REALITY outbound. */
    String buildXrayJson(int tunFd, int mtu) {
        JsonObject root = new JsonObject();

        JsonObject log = new JsonObject();
        log.addProperty("loglevel", "warning");
        root.add("log", log);

        JsonObject env = new JsonObject();
        env.addProperty(TUN_FD_ENV_KEY, String.valueOf(tunFd));
        root.add("env", env);

        JsonObject tunSettings = new JsonObject();
        //Left unnamed, Xray enumerates network interfaces to pick a free name, which Android 11+ denies to apps
        tunSettings.addProperty("name", TUN_NAME);
        tunSettings.addProperty("mtu", mtu);
        JsonObject tun = new JsonObject();
        tun.addProperty("tag", "tun-in");
        tun.addProperty("port", 0);
        tun.addProperty("protocol", "tun");
        tun.add("settings", tunSettings);
        JsonArray inbounds = new JsonArray();
        inbounds.add(tun);
        root.add("inbounds", inbounds);

        JsonArray outbounds = new JsonArray();
        outbounds.add(proxyOutbound());
        JsonObject direct = new JsonObject();
        direct.addProperty("tag", "direct");
        direct.addProperty("protocol", "freedom");
        outbounds.add(direct);
        JsonObject block = new JsonObject();
        block.addProperty("tag", "block");
        block.addProperty("protocol", "blackhole");
        outbounds.add(block);
        root.add("outbounds", outbounds);

        JsonObject routing = new JsonObject();
        routing.addProperty("domainStrategy", "AsIs");
        JsonArray rules = new JsonArray();
        //Plain Vision makes Xray refuse UDP/443; dropping it up front lets QUIC clients fall back to TCP at once
        if (FLOW_VISION.equals(flow.trim())) {
            JsonObject rule = new JsonObject();
            rule.addProperty("type", "field");
            rule.addProperty("network", "udp");
            rule.addProperty("port", "443");
            rule.addProperty("outboundTag", "block");
            rules.add(rule);
        }
        routing.add("rules", rules);
        root.add("routing", routing);
        return root.toString();
    }

    /** Config for a pingBatch probe: only the outbound matters there, and no TUN exists yet. */
    String buildProbeJson() {
        JsonObject root = new JsonObject();
        JsonArray outbounds = new JsonArray();
        outbounds.add(proxyOutbound());
        root.add("outbounds", outbounds);
        return root.toString();
    }

    private JsonObject proxyOutbound() {
        JsonObject user = new JsonObject();
        user.addProperty("id", uuid.trim());
        user.addProperty("encryption", encryption.trim().isEmpty() ? "none" : encryption.trim());
        if (!flow.trim().isEmpty()) user.addProperty("flow", flow.trim());
        JsonArray users = new JsonArray();
        users.add(user);

        JsonObject server = new JsonObject();
        server.addProperty("address", address.trim());
        server.addProperty("port", port);
        server.add("users", users);
        JsonArray vnext = new JsonArray();
        vnext.add(server);
        JsonObject settings = new JsonObject();
        settings.add("vnext", vnext);

        JsonObject outbound = new JsonObject();
        outbound.addProperty("tag", "proxy");
        outbound.addProperty("protocol", "vless");
        outbound.add("settings", settings);
        outbound.add("streamSettings", streamSettings());
        return outbound;
    }

    private boolean isReality() {
        return SECURITY_REALITY.equals(security);
    }

    private JsonObject streamSettings() {
        String net = network.trim();
        JsonObject stream = new JsonObject();
        stream.addProperty("network", net);
        stream.addProperty("security", isReality() ? SECURITY_REALITY : SECURITY_NONE);

        if (NETWORK_XHTTP.equals(net)) {
            JsonObject xhttp = new JsonObject();
            xhttp.addProperty("path", path.trim().isEmpty() ? "/" : path);
            if (!host.trim().isEmpty()) xhttp.addProperty("host", host.trim());
            if (!mode.trim().isEmpty()) xhttp.addProperty("mode", mode.trim());
            JsonObject extraObject = parseObject(extra);
            if (extraObject != null) xhttp.add("extra", extraObject);
            stream.add("xhttpSettings", xhttp);
        } else if (NETWORK_GRPC.equals(net)) {
            JsonObject grpc = new JsonObject();
            if (!serviceName.trim().isEmpty()) grpc.addProperty("serviceName", serviceName);
            if (!authority.trim().isEmpty()) grpc.addProperty("authority", authority.trim());
            if ("multi".equals(mode.trim())) grpc.addProperty("multiMode", true);
            stream.add("grpcSettings", grpc);
        }

        if (!isReality()) return stream;

        JsonObject reality = new JsonObject();
        reality.addProperty("serverName", sni.trim());
        reality.addProperty("fingerprint", (fingerprint.trim().isEmpty() ? "chrome" : fingerprint.trim()).toLowerCase(Locale.ROOT));
        reality.addProperty("publicKey", publicKey());
        reality.addProperty("shortId", shortId.trim());
        reality.addProperty("spiderX", spiderX.isEmpty() ? "/" : spiderX);
        stream.add("realitySettings", reality);
        return stream;
    }

    private String publicKey() {
        String key = publicKey.trim();
        while (key.endsWith("=")) key = key.substring(0, key.length() - 1);
        return key;
    }

    private static JsonObject parseObject(String json) {
        if (json == null) return null;
        try {
            com.google.gson.JsonElement element = JsonParser.parseString(json);
            return element.isJsonObject() ? element.getAsJsonObject() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new HashMap<>();
        for (String pair : query.split("&")) {
            int eq = pair.indexOf('=');
            if (eq < 0) continue;
            map.put(decode(pair.substring(0, eq)), decode(pair.substring(eq + 1)));
        }
        return map;
    }

    private static void splitHostPort(String hostPort, RealityConfig c) {
        String hostText;
        String portText;
        if (hostPort.startsWith("[")) {
            int end = hostPort.indexOf(']');
            if (end < 0) throw new IllegalArgumentException("unterminated IPv6 address");
            hostText = hostPort.substring(1, end);
            portText = hostPort.substring(end + 1);
            if (portText.startsWith(":")) portText = portText.substring(1);
        } else {
            int colon = hostPort.lastIndexOf(':');
            hostText = colon >= 0 ? hostPort.substring(0, colon) : hostPort;
            portText = colon >= 0 ? hostPort.substring(colon + 1) : "";
        }
        try {
            c.port = Integer.parseInt(portText);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("missing or invalid port");
        }
        c.address = decode(hostText);
    }

    private static String decode(String value) {
        try {
            return URLDecoder.decode(value, "UTF-8");
        } catch (Exception e) {
            throw new IllegalArgumentException("malformed percent-encoding");
        }
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalArgumentException(message);
    }

    private static String orEmpty(String value) {
        return value == null ? "" : value;
    }

    private static String orDefault(String value, String fallback) {
        return value == null || value.isEmpty() ? fallback : value;
    }
}
