package pvt.zalmiltd.vpn;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

import pvt.zalmiltd.vpn.models.Server;
import pvt.zalmiltd.vpn.utils.OvpnConfigBuilder;

public class ServerLoader extends AsyncTask<Void, Void, List<Server>> {

    private static final String TAG = "ServerLoader";

    // CHANGED: the JSON source URL used to be a hardcoded JSON_URL constant
    // here. It's now passed in by the caller (MainActivity, via
    // RemoteConfigManager.getServersApiUrl()) so it can come from Firebase
    // Remote Config instead of being baked into the APK — this is what
    // lets it be switched between the GitHub JSON and the admin-panel API
    // without an app update.
    private final String jsonUrl;

    // ADDED: marker prefix Server.getOvpn() carries when it holds a full,
    // already-built OpenVPN config text (admin-panel servers, built by
    // OvpnConfigBuilder) instead of a URL to download or an assets
    // filename to open. MainActivity.prepareVpn() checks for this prefix
    // and uses the rest of the string directly instead of fetching
    // anything.
    public static final String RAW_CONFIG_PREFIX = "RAW_CONFIG::";

    public interface ServerLoadListener {
        void onServersLoaded(List<Server> servers);
        void onServerLoadFailed(String error);
    }

    private final ServerLoadListener listener;

    public ServerLoader(String jsonUrl, ServerLoadListener listener) {
        this.jsonUrl = jsonUrl;
        this.listener = listener;
    }

    // CHANGED: the list now merges three sources into one, in this order —
    // Hydra (VLESS + REALITY), then OpenConnect (AnyConnect), then the
    // OpenVPN servers this loader always fetched. The three are fetched in
    // parallel; any of them failing just leaves its group out.
    @Override
    protected List<Server> doInBackground(Void... voids) {
        java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(3);
        try {
            java.util.concurrent.Future<List<Server>> hydra = pool.submit(ExtraServerSources::loadHydra);
            java.util.concurrent.Future<List<Server>> openConnect = pool.submit(ExtraServerSources::loadOpenConnect);
            java.util.concurrent.Future<List<Server>> openVpn = pool.submit(this::loadOpenVpnServers);

            List<Server> servers = new ArrayList<>();
            servers.addAll(resultOf(hydra));
            servers.addAll(resultOf(openConnect));
            servers.addAll(resultOf(openVpn));
            nameByCountry(servers);
            return servers;
        } finally {
            pool.shutdownNow();
        }
    }

    // ADDED: every server is shown as "<Country> <n>" (USA 1, USA 2,
    // Germany 1, ...) instead of the city its source reported. Numbering runs
    // through the whole merged list, so each name is unique. Servers without
    // a two-letter country code keep their original name.
    private static final java.util.Map<String, String> SHORT_COUNTRY_NAMES = new java.util.HashMap<>();

    static {
        SHORT_COUNTRY_NAMES.put("us", "USA");
        SHORT_COUNTRY_NAMES.put("gb", "UK");
        SHORT_COUNTRY_NAMES.put("ae", "UAE");
    }

    private static void nameByCountry(List<Server> servers) {
        java.util.Map<String, Integer> counters = new java.util.HashMap<>();
        for (Server server : servers) {
            String iso = server.getFlagIso() == null ? "" : server.getFlagIso().trim().toLowerCase(Locale.ROOT);
            if (iso.length() != 2) continue;

            String country = SHORT_COUNTRY_NAMES.get(iso);
            if (country == null) {
                country = new Locale.Builder().setRegion(iso.toUpperCase(Locale.ROOT)).build()
                        .getDisplayCountry(Locale.ENGLISH);
            }
            if (country == null || country.isEmpty() || country.equalsIgnoreCase(iso)) continue;

            Integer n = counters.get(country);
            n = n == null ? 1 : n + 1;
            counters.put(country, n);
            server.setCountry(country + " " + n);
        }
    }

    private static List<Server> resultOf(java.util.concurrent.Future<List<Server>> future) {
        try {
            List<Server> result = future.get(40, java.util.concurrent.TimeUnit.SECONDS);
            return result == null ? new ArrayList<>() : result;
        } catch (Exception e) {
            Log.e(TAG, "A server source failed", e);
            return new ArrayList<>();
        }
    }

    private List<Server> loadOpenVpnServers() {
        List<Server> servers = new ArrayList<>();
        HttpURLConnection conn = null;
        try {
            URL url = new URL(jsonUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.connect();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();

            String body = sb.toString().trim();

            // ADDED: the admin-panel API returns a flat JSON array
            // ([{...},{...}]) while the old GitHub source returns a single
            // JSON object ({"VpnController":{...}}). Branch on that shape
            // so either source works no matter what the Remote Config URL
            // currently points at.
            if (body.startsWith("[")) {
                servers = parseAdminPanelFormat(body);
            } else {
                servers = parseLegacyFormat(body);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error loading servers", e);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return servers;
    }

    // UNCHANGED parsing logic — the old GitHub JSON source:
    // {"VpnController":{"VpnUserName","VpnPassword",
    // "VpnList":[{vpnName,vpnIso,vpnFile,vpnNoAuth,vpnUser,vpnPass}]}}.
    // Each entry already points at a ready-to-download .ovpn file.
    private List<Server> parseLegacyFormat(String body) throws Exception {
        List<Server> servers = new ArrayList<>();
        JSONObject root = new JSONObject(body);
        JSONObject vpnController = root.getJSONObject("VpnController");

        String globalUser = vpnController.optString("VpnUserName", "");
        String globalPass = vpnController.optString("VpnPassword", "");

        JSONArray list = vpnController.getJSONArray("VpnList");
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.getJSONObject(i);
            String name    = item.getString("vpnName");
            String iso     = item.getString("vpnIso");
            String ovpnUrl = item.getString("vpnFile");
            boolean noAuth = item.optBoolean("vpnNoAuth", false);

            String user = noAuth ? "" : item.optString("vpnUser", globalUser);
            String pass = noAuth ? "" : item.optString("vpnPass", globalPass);

            Server server = new Server(name, iso, ovpnUrl, user, pass);
            Log.d(TAG, "Loaded (legacy): " + name);
            servers.add(server);
        }
        return servers;
    }

    // ADDED: the admin-panel API's own format — a flat array of
    // {id,country_code,city,ip,protocol,port,vpn_username,vpn_password,
    // is_free,order,use_file,free_connect_duration,connected_devices}
    // objects. There's no ready-made .ovpn/cert here, so a full config is
    // built per server with OvpnConfigBuilder, using the shared client
    // identity every server behind this API uses (see ApiServerSecrets).
    private List<Server> parseAdminPanelFormat(String body) throws Exception {
        JSONArray arr = new JSONArray(body);
        // Keyed by the API's own "order" field so display order matches
        // the admin panel regardless of what order the array itself came
        // back in.
        TreeMap<Integer, Server> ordered = new TreeMap<>();
        int fallbackOrder = 0;

        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject item = arr.getJSONObject(i);

                String ip = item.getString("ip");
                if (ip.trim().isEmpty()) continue;

                String countryCode = item.optString("country_code", "").trim();
                String city = item.optString("city", "").trim();
                String protocol = item.optString("protocol", "udp");
                int port = item.optInt("port", "tcp".equalsIgnoreCase(protocol) ? 443 : 1194);
                String user = item.optString("vpn_username", "");
                String pass = item.optString("vpn_password", "");
                int order = item.optInt("order", fallbackOrder);
                fallbackOrder++;

                String displayName = city.isEmpty()
                        ? countryCode.toUpperCase(Locale.US)
                        : city;

                String config = OvpnConfigBuilder.build(protocol, ip, port, user, pass);
                Server server = new Server(displayName, countryCode, RAW_CONFIG_PREFIX + config, user, pass);
                Log.d(TAG, "Loaded (api): " + displayName + " (" + ip + ":" + port + "/" + protocol + ")");

                // "order" isn't guaranteed unique by the API — fall back to
                // the next free slot on a collision so no server silently
                // gets dropped.
                while (ordered.containsKey(order)) order++;
                ordered.put(order, server);
            } catch (Exception itemError) {
                // One bad record shouldn't take down the whole list.
                Log.e(TAG, "Skipping malformed server entry at index " + i, itemError);
            }
        }
        return new ArrayList<>(ordered.values());
    }

    @Override
    protected void onPostExecute(List<Server> servers) {
        if (listener == null) return;
        if (servers != null && !servers.isEmpty()) {
            listener.onServersLoaded(servers);
        } else {
            listener.onServerLoadFailed("Failed to load server list");
        }
    }
}