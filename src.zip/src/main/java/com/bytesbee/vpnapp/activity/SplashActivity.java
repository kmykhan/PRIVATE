package pvt.zalmiltd.vpn.activity;

import android.app.Activity;
import android.app.Application;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.util.concurrent.atomic.AtomicBoolean;

import pvt.zalmiltd.vpn.BuildConfig;
import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.managers.Screens;
import pvt.zalmiltd.vpn.managers.SessionManager;

public class SplashActivity extends AppCompatActivity {

    private static final long AD_TIMEOUT_MS = 10000; // 10 seconds max wait for ad
    private long DELAY = 5;
    private boolean mainActivityStarted = false;
    private final Handler timeoutHandler = new Handler();

    // ADDED (AdMob "No CMP" fix): guards against the UMP async success
    // callback and the synchronous canRequestAds() fast-path both firing
    // proceedAfterConsent() twice for the same launch.
    private final AtomicBoolean adsFlowStarted = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        setWindowFlag(this, WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS, false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        setContentView(R.layout.activity_splash);

        if (BuildConfig.ADS_SHOWN) {
            // CHANGED (perf: "app feels slow/heavy to open"): this used to be
            // a flat 5 seconds on EVERY cold launch, even when there's no
            // app-open ad ready to show at all — which, on a fresh install or
            // whenever the previous ad was already used up, is most of the
            // time. showAdIfAvailable() only shows an ad that's already
            // loaded/cached; it doesn't wait for a new one to arrive here, so
            // there's nothing this delay actually buys once consent+SDK init
            // are underway. Cutting it to 2s keeps a brief branded splash
            // without making people stare at a blank screen for no reason.
            DELAY = 2;
            // CHANGED: was createTimer(DELAY) directly. UMP consent must be
            // resolved (and, for AdMob, MobileAds.initialize() called) before
            // any ad request goes out — that's what the AdMob Policy Center
            // "No CMP" / missing TC-string violation is about.
            requestConsentAndProceed();
        } else {
            DELAY = 3000;
            startMainActivity();
        }
    }

    // ── UMP consent flow — must run before AdMob/Yandex init or ad loads ──────
    private void requestConsentAndProceed() {
        ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build();

        ConsentInformation consentInformation = UserMessagingPlatform.getConsentInformation(this);

        consentInformation.requestConsentInfoUpdate(
                this,
                params,
                () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                        SplashActivity.this,
                        formError -> proceedAfterConsent(consentInformation)),
                requestConsentError -> {
                    // Couldn't fetch consent status (e.g. no network) — fall back
                    // to whatever canRequestAds() already knows (cached from a
                    // previous run), same as the official UMP quick-start sample.
                    proceedAfterConsent(consentInformation);
                }
        );

        // Fast path: consent already obtained/not required (cached), so we
        // don't block on the network round trip requestConsentInfoUpdate makes.
        if (consentInformation.canRequestAds()) {
            proceedAfterConsent(consentInformation);
        }
    }

    private void proceedAfterConsent(ConsentInformation consentInformation) {
        if (!adsFlowStarted.compareAndSet(false, true)) return; // already handled

        Application application = getApplication();
        if (application instanceof UIApplication && consentInformation.canRequestAds()) {
            ((UIApplication) application).initializeAdsSdk();
        }
        // If consent isn't granted/required-but-unresolved, we simply skip ad
        // SDK init — the timer below still runs, and showAdIfAvailable() will
        // find nothing loaded and fall straight through to MainActivity.
        createTimer(DELAY);
    }

    private void createTimer(long seconds) {
        new CountDownTimer(seconds * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                Application application = getApplication();

                if (!(application instanceof UIApplication)) {
                    startMainActivity();
                    return;
                }

                // Timeout fallback — agar ad 10 sec mein na aaye to seedha MainActivity
                timeoutHandler.postDelayed(() -> {
                    if (!mainActivityStarted) {
                        startMainActivity();
                    }
                }, AD_TIMEOUT_MS);

                ((UIApplication) application).showAdIfAvailable(SplashActivity.this, () -> {
                    timeoutHandler.removeCallbacksAndMessages(null);
                    startMainActivity();
                });
            }
        }.start();
    }

    public void startMainActivity() {
        if (mainActivityStarted) return;
        mainActivityStarted = true;

        Class cls;
        if (SessionManager.getInstance(this).isEntryDone()) {
            cls = MainActivity.class;
        } else {
            cls = TakeToTourActivity.class;
        }
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        Screens.showClearTopScreen(getApplicationContext(), cls);
    }

    public static void setWindowFlag(Activity activity, final int bits, boolean on) {
        Window win = activity.getWindow();
        WindowManager.LayoutParams winParams = win.getAttributes();
        if (on) {
            winParams.flags |= bits;
        } else {
            winParams.flags &= ~bits;
        }
        win.setAttributes(winParams);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timeoutHandler.removeCallbacksAndMessages(null);
    }
}