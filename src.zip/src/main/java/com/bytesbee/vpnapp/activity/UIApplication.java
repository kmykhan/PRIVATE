package pvt.zalmiltd.vpn.activity;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import pvt.zalmiltd.vpn.BuildConfig;
import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.managers.RemoteConfigManager;
import pvt.zalmiltd.vpn.managers.SessionManager;
import pvt.zalmiltd.vpn.managers.UsageManager;
import pvt.zalmiltd.vpn.utils.AdRetryPolicy;
import pvt.zalmiltd.vpn.utils.Utils;

// AdMob (GMA Next-Gen SDK)
// CHANGED: legacy com.google.android.gms.ads.{AdError,AdRequest,
// FullScreenContentCallback,LoadAdError,MobileAds} and
// com.google.android.gms.ads.appopen.AppOpenAd are replaced by Next-Gen's
// .appopen (format-specific) and .common (shared types) packages, plus a
// dedicated .initialization package for MobileAds.initialize()'s config.
import com.google.android.libraries.ads.mobile.sdk.MobileAds;
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAd;
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAdEventCallback;
import com.google.android.libraries.ads.mobile.sdk.appopen.AppOpenAdRequest;
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback;
import com.google.android.libraries.ads.mobile.sdk.common.AdValue;
import com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError;
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError;
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig;

// Yandex (SDK 8.x — AdRequestConfiguration removed; the request now carries
// the adUnitId and the listener goes straight into loadAd())
import com.yandex.mobile.ads.appopenad.AppOpenAdEventListener;
import com.yandex.mobile.ads.appopenad.AppOpenAdLoadListener;
import com.yandex.mobile.ads.appopenad.AppOpenAdLoader;
import com.yandex.mobile.ads.common.AdRequestError;
import com.yandex.mobile.ads.common.ImpressionData;

import java.util.Date;

import de.blinkt.openvpn.core.PRNGFixes;
import de.blinkt.openvpn.core.StatusListener;

public class UIApplication extends Application implements Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {

    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    // (AdMob "No CMP" fix, kept from the earlier UMP change): MobileAds.initialize()
    // no longer runs unconditionally here. It only runs from initializeAdsSdk(),
    // which SplashActivity calls once the UMP consent flow confirms
    // consentInformation.canRequestAds() == true. The AtomicBoolean guards
    // against a second, redundant initialize() call.
    private final AtomicBoolean isMobileAdsInitializeCalled = new AtomicBoolean(false);

    // FIXED (crash: "MobileAds.initialize must be called before using the
    // Google Mobile Ads SDK"): MainActivity.onCreate() used to call
    // Utils.initNativeAds()/firstLoadAds() unconditionally and immediately.
    // On a fresh process where SplashActivity's UMP flow hadn't finished
    // calling initializeAdsSdk() yet (or MobileAds.initialize() itself
    // hadn't returned, since it now runs on a background thread), that ad
    // load ran before the SDK was ready and threw. adsInitialized +
    // pendingAdsInitCallbacks let any screen ask to run ad-loading code
    // "once ads are ready", instead of assuming they already are.
    private static volatile boolean adsInitialized = false;
    private static final List<Runnable> pendingAdsInitCallbacks = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();

        this.registerActivityLifecycleCallbacks(this);

        SessionManager.init(getApplicationContext());
        UsageManager.init(getApplicationContext());
        // ADDED: bootstraps Firebase Remote Config so ServerLoader can read
        // the servers-list source URL from the "servers_api_url" key
        // (Firebase Console) instead of a hardcoded constant.
        RemoteConfigManager.init(getApplicationContext());
        try {
            Utils.setDarkMode(SessionManager.get().isDarkModeOn());
        } catch (Exception e) {
            Utils.getErrors(e);
        }

        if (SessionManager.get().getDeviceCreated().equalsIgnoreCase("null")) {
            SessionManager.get().setDeviceCreated(String.valueOf(System.currentTimeMillis()));
        }

        if (BuildConfig.ADS_SHOWN) {
            ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
            // Safe to construct unconditionally — this only stores ad unit
            // ids, it doesn't make a network call. The actual ad *requests*
            // (loadAdmob/loadYandex below) only start once initializeAdsSdk()
            // has run, which happens post-consent.
            appOpenAdManager = new AppOpenAdManager(
                    getString(R.string.app_open_id),
                    getString(R.string.yandex_app_open_id)
            );
        }

        PRNGFixes.apply();
        StatusListener mStatus = new StatusListener();
        mStatus.init(getApplicationContext());
    }

    // Called by SplashActivity only after the UMP consent flow resolves and
    // consentInformation.canRequestAds() is true.
    //
    // CHANGED (GMA Next-Gen SDK migration): MobileAds.initialize() is
    // @WorkerThread now — calling it on the main thread throws — so it's
    // dispatched onto a background thread. It also takes an
    // InitializationConfig built from the AdMob app ID instead of just a
    // Context + completion listener.
    //
    // FIXED (per GMA Next-Gen quick-start guide): Next-Gen SDK's
    // MobileAds.initialize() only exists as a 3-argument method —
    // (context, InitializationConfig, OnInitializationCompleteListener).
    // Unlike the legacy com.google.android.gms.ads.MobileAds, there is no
    // 2-arg (context, config) overload in this package, so the previous
    // 2-arg call here did not compile. The listener is a no-op — adsInitialized
    // below (set right after this call returns) is what the rest of the app
    // actually waits on, not the adapter-initialization callback.
    public void initializeAdsSdk() {
        if (!isMobileAdsInitializeCalled.compareAndSet(false, true)) return;

        String appId = getString(R.string.main_app_id);
        new Thread(() -> {
            MobileAds.initialize(
                    getApplicationContext(),
                    new InitializationConfig.Builder(appId).build(),
                    initializationStatus -> {
                        // Adapter initialization complete — intentionally
                        // a no-op; adsInitialized/runPendingAdsInitCallbacks
                        // below already track SDK readiness for the rest of
                        // the app.
                    }
            );
            // ADDED: MobileAds.initialize() above blocks until the SDK
            // itself is ready (adapters may still be finishing on their own
            // callback) — by the time it returns here the SDK is actually
            // ready, so flip the flag and release anything that was waiting
            // on it.
            adsInitialized = true;
            runPendingAdsInitCallbacks();
        }).start();
    }

    /**
     * ADDED. Runs {@code action} once MobileAds.initialize() has completed —
     * immediately (posted to the main thread) if it already has, otherwise
     * queued until it does. When ads are switched off entirely
     * (BuildConfig.ADS_SHOWN == false) initializeAdsSdk() is never called and
     * adsInitialized would stay false forever, so that case also runs
     * immediately: every Utils ad method already no-ops on ADS_SHOWN == false,
     * so there's nothing to actually wait for.
     */
    public static void runWhenAdsInitialized(Runnable action) {
        if (!BuildConfig.ADS_SHOWN || adsInitialized) {
            new Handler(Looper.getMainLooper()).post(action);
            return;
        }
        synchronized (pendingAdsInitCallbacks) {
            pendingAdsInitCallbacks.add(action);
        }
    }

    private static void runPendingAdsInitCallbacks() {
        Handler mainHandler = new Handler(Looper.getMainLooper());
        synchronized (pendingAdsInitCallbacks) {
            for (Runnable action : pendingAdsInitCallbacks) {
                mainHandler.post(action);
            }
            pendingAdsInitCallbacks.clear();
        }
    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStart(owner);
        if (BuildConfig.ADS_SHOWN) {
            if (currentActivity == null || currentActivity instanceof SplashActivity) {
                return;
            }
            appOpenAdManager.showAdIfAvailable(currentActivity);
        }
    }

    @Override
    public void onActivityCreated(@NonNull Activity activity, @Nullable Bundle savedInstanceState) {}

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        if (BuildConfig.ADS_SHOWN) {
            if (!appOpenAdManager.isShowingAd) {
                currentActivity = activity;
            }
        }
    }

    @Override public void onActivityResumed(@NonNull Activity activity) {}
    @Override public void onActivityPaused(@NonNull Activity activity) {}
    @Override public void onActivityStopped(@NonNull Activity activity) {}
    @Override public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle outState) {}
    @Override public void onActivityDestroyed(@NonNull Activity activity) {}

    public void showAdIfAvailable(
            @NonNull Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
        if (BuildConfig.ADS_SHOWN) {
            appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
        }
    }

    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AppOpenAdManager: AdMob first, Yandex fallback
    // ─────────────────────────────────────────────────────────────────────────
    private static class AppOpenAdManager {

        private final String admobAdUnitId;
        private final String yandexAdUnitId;

        // AdMob
        private AppOpenAd admobAppOpenAd = null;
        private boolean isLoadingAdmob = false;
        private long admobLoadTime = 0;

        // Yandex
        private com.yandex.mobile.ads.appopenad.AppOpenAd yandexAppOpenAd = null;
        private boolean isLoadingYandex = false;

        boolean isShowingAd = false;

        // RETRY: if AdMob AND Yandex both no-fill, back off then restart at
        // AdMob so a recovered AdMob regains priority. Safe against the
        // Application context — no Activity/View captured, nothing can leak.
        private final AdRetryPolicy retry = new AdRetryPolicy("appopen");
        private Context appContext;

        public AppOpenAdManager(String admobAdUnitId, String yandexAdUnitId) {
            this.admobAdUnitId = admobAdUnitId;
            this.yandexAdUnitId = yandexAdUnitId;
        }

        // ── AdMob load ────────────────────────────────────────────────────────
        // CHANGED (GMA Next-Gen SDK migration): legacy AppOpenAd.load(context,
        // adUnitId, adRequest, orientation, callback) -> AppOpenAd.load(request,
        // callback), with an AppOpenAdRequest (its own request type, not the
        // shared AdRequest interstitial/native use) replacing the adUnitId +
        // AdRequest + orientation trio. There's no orientation parameter
        // anymore — Next-Gen handles that itself.
        private void loadAdmob(Context context) {
            if (isLoadingAdmob || isAdmobAvailable()) return;
            // Application context: the retry chain must not hold an Activity.
            appContext = context.getApplicationContext();
            isLoadingAdmob = true;

            AppOpenAdRequest adRequest = new AppOpenAdRequest.Builder(admobAdUnitId).build();
            AppOpenAd.load(
                    adRequest,
                    new AdLoadCallback<AppOpenAd>() {
                        @Override
                        public void onAdLoaded(@NonNull AppOpenAd ad) {
                            admobAppOpenAd = ad;
                            isLoadingAdmob = false;
                            admobLoadTime = new Date().getTime();
                            yandexAppOpenAd = null; // AdMob ready, no need for Yandex
                            retry.reset();
                        }

                        @Override
                        public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                            isLoadingAdmob = false;
                            admobAppOpenAd = null;
                            loadYandex(context); // Fallback
                        }
                    });
        }

        private boolean wasAdmobLoadTimeLessThan4HoursAgo() {
            long diff = new Date().getTime() - admobLoadTime;
            return diff < (3600000L * 4);
        }

        private boolean isAdmobAvailable() {
            return admobAppOpenAd != null && wasAdmobLoadTimeLessThan4HoursAgo();
        }

        // ── Yandex load ───────────────────────────────────────────────────────
        // SDK 8: AdRequestConfiguration is gone — the adUnitId now lives on
        // AdRequest, and the listener is passed directly into loadAd()
        // instead of setAdLoadListener().
        private void loadYandex(Context context) {
            if (isLoadingYandex || yandexAppOpenAd != null) return;
            isLoadingYandex = true;
            AppOpenAdLoader loader = new AppOpenAdLoader(context);
            com.yandex.mobile.ads.common.AdRequest request =
                    new com.yandex.mobile.ads.common.AdRequest.Builder(yandexAdUnitId).build();

            loader.loadAd(request, new AppOpenAdLoadListener() {
                @Override
                public void onAdLoaded(@NonNull com.yandex.mobile.ads.appopenad.AppOpenAd ad) {
                    yandexAppOpenAd = ad;
                    isLoadingYandex = false;
                    retry.reset();
                }

                @Override
                public void onAdFailedToLoad(@NonNull AdRequestError error) {
                    yandexAppOpenAd = null;
                    isLoadingYandex = false;
                    // Both networks dry — back off, then restart at AdMob so a
                    // recovered AdMob regains priority over the fallback.
                    retry.scheduleRetry(() -> {
                        if (appContext != null) loadAdmob(appContext);
                    });
                }
            });
        }

        // ── Show ──────────────────────────────────────────────────────────────
        private void showAdIfAvailable(@NonNull final Activity activity) {
            showAdIfAvailable(activity, () -> {});
        }

        private void showAdIfAvailable(
                @NonNull final Activity activity,
                @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {

            if (isShowingAd) return;

            // FIXED (App Open ad never showed on "switch back to app"): this used
            // to also require activity.getClass().getSimpleName().equals("SplashActivity")
            // here. That contradicted the caller above (onStart(LifecycleOwner),
            // Google's documented "user switches back to the app" trigger) which
            // deliberately only calls this when currentActivity is NOT
            // SplashActivity — Splash already shows its own App Open ad via the
            // explicit call from its countdown timer, so this path exists purely
            // for the warm-start case. With the SplashActivity-only check here,
            // that warm-start branch was calling into a method that always
            // returned immediately — the ad was preloaded and then never shown.
            // Removing it restores the second half of AdMob's own guidance:
            // "display when a user opens the app OR switches back to it."
            //
            // ADDED: per that same guidance ("don't display ads immediately
            // before or after app open ads" / "avoid layering app open ads on
            // top of other existing ads"), this now shares Utils' full-screen-ad
            // cooldown with the interstitial flow — an App Open ad won't fire
            // right after an interstitial was just shown (or vice versa; see
            // markFullScreenAdShown() below and in Utils.showAdMobInterstitial /
            // showYandexInterstitial).
            if (Utils.isFullScreenAdCoolingDown()) {
                onShowAdCompleteListener.onShowAdComplete();
                return;
            }

            if (isAdmobAvailable()) {
                showAdmob(activity, onShowAdCompleteListener);
            } else if (yandexAppOpenAd != null) {
                showYandex(activity, onShowAdCompleteListener);
            } else {
                onShowAdCompleteListener.onShowAdComplete();
                loadAdmob(activity);
            }
        }

        // ── AdMob show ────────────────────────────────────────────────────────
        // CHANGED (GMA Next-Gen SDK migration): legacy
        // admobAppOpenAd.setFullScreenContentCallback(new FullScreenContentCallback())
        // -> admobAppOpenAd.setAdEventCallback(new AppOpenAdEventCallback()).
        // 6 methods now instead of 3 (adds onAdImpression/onAdClicked/onAdPaid),
        // implemented as no-ops below since this app never needed them.
        private void showAdmob(@NonNull Activity activity, @NonNull OnShowAdCompleteListener listener) {
            admobAppOpenAd.setAdEventCallback(new AppOpenAdEventCallback() {
                @Override
                public void onAdShowedFullScreenContent() {}

                @Override
                public void onAdDismissedFullScreenContent() {
                    admobAppOpenAd = null;
                    isShowingAd = false;
                    listener.onShowAdComplete();
                    loadAdmob(activity);
                }

                @Override
                public void onAdFailedToShowFullScreenContent(@NonNull FullScreenContentError fullScreenContentError) {
                    admobAppOpenAd = null;
                    isShowingAd = false;
                    // Try Yandex
                    if (yandexAppOpenAd != null) {
                        showYandex(activity, listener);
                    } else {
                        listener.onShowAdComplete();
                        loadAdmob(activity);
                    }
                }

                @Override
                public void onAdImpression() {}

                @Override
                public void onAdClicked() {}

                @Override
                public void onAdPaid(@NonNull AdValue adValue) {}
            });
            isShowingAd = true;
            Utils.markFullScreenAdShown();
            admobAppOpenAd.show(activity);
        }

        // ── Yandex show ───────────────────────────────────────────────────────
        private void showYandex(@NonNull Activity activity, @NonNull OnShowAdCompleteListener listener) {
            yandexAppOpenAd.setAdEventListener(new AppOpenAdEventListener() {
                @Override
                public void onAdShown() {}

                @Override
                public void onAdFailedToShow(@NonNull com.yandex.mobile.ads.common.AdError adError) {
                    yandexAppOpenAd = null;
                    isShowingAd = false;
                    listener.onShowAdComplete();
                    loadAdmob(activity);
                }

                @Override
                public void onAdDismissed() {
                    yandexAppOpenAd = null;
                    isShowingAd = false;
                    listener.onShowAdComplete();
                    loadAdmob(activity); // Reload AdMob (ya Yandex agar fail ho)
                }

                @Override
                public void onAdClicked() {}

                @Override
                public void onAdImpression(@Nullable ImpressionData impressionData) {}
            });
            isShowingAd = true;
            Utils.markFullScreenAdShown();
            yandexAppOpenAd.show(activity);
        }
    }
}