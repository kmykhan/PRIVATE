package pvt.zalmiltd.vpn.managers;

import static pvt.zalmiltd.vpn.constants.IConstants.ALL_APPS;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKeys;

import pvt.zalmiltd.vpn.models.Server;
import pvt.zalmiltd.vpn.utils.Utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class SessionManager {

    private SharedPreferences pref = null;
    private static final String PREF_NAME = "_BytesBeeV1";
    private static final String KEY_DEVICE_CREATED = "deviceCreated";
    private static final String KEY_ENTRY_DONE = "statusDone";
    private static final String KEY_SERVER_OBJ = "ServerObj";
    // ADDED (perf: instant server list on cold launch instead of waiting on
    // a fresh network fetch every time): the last successfully-loaded full
    // servers list, cached to disk.
    private static final String KEY_SERVERS_LIST_CACHE = "ServersListCache";
    private static final String KEY_ON_OFF_DARK_MODE = "onOffDarkMode";
    private static final String KEY_CONNECT_TUNNEL = "connectToVPN";
    public static final String KEY_SELECT_NOT = "selectAppsNot";
    public static final String KEY_ONLY_SELECT = "onlySelectApps";

    private static SessionManager mInstance;

    public static SessionManager get() {
        return mInstance;
    }

    public static void init(Context ctx) {
        if (mInstance == null) mInstance = new SessionManager(ctx);
    }

    public SessionManager(final Context context) {
        try {
            String masterKey = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC);
            pref = EncryptedSharedPreferences.create(
                    context.getPackageName() + PREF_NAME,
                    masterKey,
                    context,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            Utils.getErrors(e);
            // Fallback to regular SharedPreferences if encrypted fails
            try {
                pref = context.getSharedPreferences(
                        context.getPackageName() + PREF_NAME + "_plain",
                        Context.MODE_PRIVATE
                );
            } catch (Exception ex) {
                Utils.getErrors(ex);
            }
        }
    }

    private SharedPreferences.Editor getEditor() {
        if (pref == null) return null;
        return pref.edit();
    }

    public void setDeviceCreated(String device) {
        SharedPreferences.Editor editor = getEditor();
        if (editor == null) return;
        editor.putString(KEY_DEVICE_CREATED, device);
        editor.apply();
    }

    public String getDeviceCreated() {
        if (pref == null) return "null";
        return pref.getString(KEY_DEVICE_CREATED, "null");
    }

    public void setEntryDone() {
        SharedPreferences.Editor editor = getEditor();
        if (editor == null) return;
        editor.putBoolean(KEY_ENTRY_DONE, true);
        editor.apply();
    }

    public boolean isEntryDone() {
        if (pref == null) return false;
        return pref.getBoolean(KEY_ENTRY_DONE, false);
    }

    public static SessionManager getInstance(final Context context) {
        return new SessionManager(context);
    }

    public void saveServer(Server server) {
        SharedPreferences.Editor editor = getEditor();
        if (editor == null) return;
        editor.putString(KEY_SERVER_OBJ, new Gson().toJson(server));
        editor.apply();
    }

    public Server getServer() {
        try {
            if (pref == null) return null;
            return new Gson().fromJson(pref.getString(KEY_SERVER_OBJ, null), Server.class);
        } catch (Exception e) {
            return null;
        }
    }

    // ADDED (perf): persists the full servers list fetched from the API so
    // MainActivity can show it instantly on the next cold launch (process
    // freshly started, before any network call has even gone out) instead
    // of leaving the screen on "loading" until a new fetch finishes.
    public void saveServersList(java.util.List<Server> servers) {
        SharedPreferences.Editor editor = getEditor();
        if (editor == null) return;
        editor.putString(KEY_SERVERS_LIST_CACHE, new Gson().toJson(servers));
        editor.apply();
    }

    /** Never returns null — an empty ArrayList when nothing is cached yet or the cache is unreadable. */
    public ArrayList<Server> getCachedServersList() {
        try {
            if (pref == null) return new ArrayList<>();
            String json = pref.getString(KEY_SERVERS_LIST_CACHE, null);
            if (TextUtils.isEmpty(json)) return new ArrayList<>();
            java.lang.reflect.Type type = new TypeToken<ArrayList<Server>>() {
            }.getType();
            ArrayList<Server> cached = new Gson().fromJson(json, type);
            return cached != null ? cached : new ArrayList<>();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void setOnOffDarkMode(final boolean value) {
        SharedPreferences.Editor editor = getEditor();
        if (editor == null) return;
        editor.putBoolean(KEY_ON_OFF_DARK_MODE, value);
        editor.apply();
    }

    public boolean isDarkModeOn() {
        if (pref == null) return false;
        return pref.getBoolean(KEY_ON_OFF_DARK_MODE, false);
    }

    public void setConnectTunnel(final int value) {
        SharedPreferences.Editor editor = getEditor();
        if (editor == null) return;
        editor.putInt(KEY_CONNECT_TUNNEL, value);
        editor.apply();
    }

    public int getConnectTunnel() {
        if (pref == null) return ALL_APPS;
        return pref.getInt(KEY_CONNECT_TUNNEL, ALL_APPS);
    }

    public void saveHashMap(String key, Object obj) {
        SharedPreferences.Editor editor = getEditor();
        if (editor == null) return;
        Gson gson = new Gson();
        String json = gson.toJson(obj);
        editor.putString(key, json);
        editor.apply();
    }

    public HashMap<String, String> getHashMap(String key) {
        if (pref == null) return new HashMap<>();
        Gson gson = new Gson();
        String json = pref.getString(key, "");
        if (TextUtils.isEmpty(json)) {
            return new HashMap<>();
        } else {
            java.lang.reflect.Type type = new TypeToken<HashMap<String, String>>() {
            }.getType();
            return gson.fromJson(json, type);
        }
    }

    public ArrayList<String> getPackageList(String key) {
        try {
            HashMap<String, String> map = getHashMap(key);
            Set<String> keySet = map.keySet();
            return new ArrayList<>(keySet);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}