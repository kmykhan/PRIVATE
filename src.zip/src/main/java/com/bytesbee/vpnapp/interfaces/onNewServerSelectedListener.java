package pvt.zalmiltd.vpn.interfaces;

import pvt.zalmiltd.vpn.models.Server;

public interface onNewServerSelectedListener {
    void onNewServerSelected(Server server);
}
