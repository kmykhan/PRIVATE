package pvt.zalmiltd.vpn.utils;

import static pvt.zalmiltd.vpn.constants.IConstants.MINUS;
import static pvt.zalmiltd.vpn.constants.IConstants.ZERO;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.res.ResourcesCompat;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import pvt.zalmiltd.vpn.BuildConfig;
import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.constants.IConstants;
import pvt.zalmiltd.vpn.managers.Screens;

// AdMob — GMA Next-Gen SDK (com.google.android.libraries.ads.mobile.sdk.mobile.sdk:ads-mobile-sdk).
// The legacy com.google.android.gms.ads.* package is gone from the classpath
// (removed in build.gradle — see that file's comment), so every class below
// comes from the new package. TemplateView (nativetemplates module) was
// already migrated to accept this new NativeAd type — see that module's
// TemplateView.java / build.gradle.
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback;
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest;
import com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError;
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError;
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAd;
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback;
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAd;
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoader;
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdLoaderCallback;
import com.google.android.libraries.ads.mobile.sdk.nativead.NativeAdRequest;

// Yandex (SDK 8.x — AdRequestConfiguration/NativeAdRequestConfiguration and
// setAdLoadListener()/setNativeAdLoadListener() are gone; the request now
// carries the adUnitId and the listener goes straight into loadAd()).
import com.yandex.mobile.ads.common.AdBindingResult;
import com.yandex.mobile.ads.common.AdRequestError;
import com.yandex.mobile.ads.common.ImpressionData;
import com.yandex.mobile.ads.interstitial.InterstitialAdEventListener;
import com.yandex.mobile.ads.interstitial.InterstitialAdLoadListener;
import com.yandex.mobile.ads.interstitial.InterstitialAdLoader;
import com.yandex.mobile.ads.nativeads.MediaView;
import com.yandex.mobile.ads.nativeads.NativeAdLoadListener;
import com.yandex.mobile.ads.nativeads.NativeAdView;
import com.yandex.mobile.ads.nativeads.NativeAdViewBinder;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.Random;

public class Utils {
    public static final boolean IS_TRIAL = false;

    public static void getErrors(final Exception e) {
        final String stackTrace = Log.getStackTraceString(e);
        Utils.sout(String.format("%s", stackTrace));
    }

    public static void sout(final String msg) {
        if (IS_TRIAL) {
            System.out.println(IConstants.SOUT_MSG_PREFIX + msg);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Shared retry backoff config
    // ─────────────────────────────────────────────────────────────────────────
    private static final long RETRY_BASE_DELAY_MS = 2000L;   // first retry after 2s
    private static final long RETRY_MAX_DELAY_MS = 64000L;   // cap at 64s

    // ─────────────────────────────────────────────────────────────────────────
    // Native Ads: AdMob first, Yandex fallback, with capped exponential backoff
    // retry if BOTH networks fail.
    //
    // NOTE: Yandex SDK 8 removed NativeBannerView (the template renderer used
    // pre-8.0). The fallback now inflates native_ad_yandex.xml inside the
    // NativeAdView container and binds it manually via NativeAdViewBinder.
    // ─────────────────────────────────────────────────────────────────────────
    private static final Handler nativeRetryHandler = new Handler(Looper.getMainLooper());
    private static Runnable nativeRetryRunnable;
    private static long nativeRetryDelay = RETRY_BASE_DELAY_MS;

    public static void initNativeAds(Activity mActivity, TemplateView admobTemplate, NativeAdView yandexNativeAdView) {
        if (!BuildConfig.ADS_SHOWN) return;
        nativeRetryDelay = RETRY_BASE_DELAY_MS; // fresh screen, reset backoff
        loadAdMobNative(mActivity, admobTemplate, yandexNativeAdView);
    }

    // MIGRATED to GMA Next-Gen SDK: AdLoader.Builder(...).forNativeAd(...) is
    // gone. NativeAdLoader.load() takes a NativeAdRequest (adUnitId now lives
    // there, same pattern as the Yandex request below) and a single
    // NativeAdLoaderCallback that covers both success and failure (no more
    // separate AdListener for the failure case).
    private static void loadAdMobNative(Activity mActivity, TemplateView admobTemplate, NativeAdView yandexNativeAdView) {
        NativeAdRequest adRequest = new NativeAdRequest.Builder(
                mActivity.getString(R.string.native_app_id),
                List.of(NativeAd.NativeAdType.NATIVE))
                .build();

        NativeAdLoader.load(adRequest, new NativeAdLoaderCallback() {
            // FIXED: GMA Next-Gen SDK callbacks fire on a background coroutine
            // thread (seen in Logcat as "GMA(BG) N"), NOT the main/UI thread —
            // unlike the old legacy AdMob SDK. admobTemplate.setNativeAd(...)
            // touches many views internally (TemplateView.setNativeAd()), so
            // calling it straight from here threw a FATAL
            // ViewRootImpl$CalledFromWrongThreadException, which Crashlytics'
            // uncaught-exception handler turned into an immediate
            // Process.killProcess() — killing the whole app (and, mid-connect,
            // interrupting the OpenVPN socket too, which is why "servers not
            // connecting" showed up in the same crash). Every view-touching
            // line below is now posted back to the main thread, same pattern
            // already used in ServerListAdapter's banner callback and
            // UIApplication's app-open ad handling.
            @Override
            public void onNativeAdLoaded(@NonNull NativeAd nativeAd) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (mActivity == null || mActivity.isFinishing() || mActivity.isDestroyed()) return;
                    nativeRetryDelay = RETRY_BASE_DELAY_MS; // success — reset backoff
                    admobTemplate.setNativeAd(nativeAd);
                    admobTemplate.setVisibility(View.VISIBLE);
                    yandexNativeAdView.setVisibility(View.GONE);
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (mActivity == null || mActivity.isFinishing() || mActivity.isDestroyed()) return;
                    admobTemplate.setVisibility(View.GONE);
                    loadYandexNative(mActivity, admobTemplate, yandexNativeAdView); // Fallback
                });
            }
        });
    }

    private static void loadYandexNative(Activity mActivity, TemplateView admobTemplate, NativeAdView yandexNativeAdView) {
        String adUnitId = mActivity.getString(R.string.yandex_native_id);
        com.yandex.mobile.ads.nativeads.NativeAdLoader loader = new com.yandex.mobile.ads.nativeads.NativeAdLoader(mActivity);
        // SDK 8: adUnitId now lives on the request, not a separate config class.
        com.yandex.mobile.ads.common.AdRequest request =
                new com.yandex.mobile.ads.common.AdRequest.Builder(adUnitId).build();

        final WeakReference<Activity> activityRef = new WeakReference<>(mActivity);
        final WeakReference<TemplateView> admobRef = new WeakReference<>(admobTemplate);
        final WeakReference<NativeAdView> yandexRef = new WeakReference<>(yandexNativeAdView);

        // SDK 8: listener is passed directly to loadAd(), not via setNativeAdLoadListener().
        loader.loadAd(request, new NativeAdLoadListener() {
            @Override
            public void onAdLoaded(@NonNull com.yandex.mobile.ads.nativeads.NativeAd nativeAd) {
                nativeRetryDelay = RETRY_BASE_DELAY_MS; // success — reset backoff
                NativeAdView view = yandexRef.get();
                Activity activity = activityRef.get();
                if (view == null || activity == null || activity.isFinishing() || activity.isDestroyed()) return;

                bindYandexNativeAd(activity, view, nativeAd);
            }

            @Override
            public void onAdFailedToLoad(@NonNull AdRequestError error) {
                NativeAdView view = yandexRef.get();
                if (view != null) view.setVisibility(View.GONE);
                scheduleNativeRetry(activityRef, admobRef, yandexRef);
            }
        });
    }

    /**
     * NativeBannerView was removed in SDK 8. We inflate native_ad_yandex.xml
     * inside the NativeAdView container ourselves and bind each asset via
     * NativeAdViewBinder — domain and feedback views are mandatory assets,
     * skipping them causes bindNativeAd() to fail.
     */
    private static void bindYandexNativeAd(Activity activity, NativeAdView container, com.yandex.mobile.ads.nativeads.NativeAd nativeAd) {
        container.removeAllViews();
        View adView = LayoutInflater.from(activity).inflate(R.layout.native_ad_yandex, container, false);
        container.addView(adView);

        MediaView mediaView = adView.findViewById(R.id.yandex_media_view);
        ImageView iconView = adView.findViewById(R.id.yandex_icon);
        TextView titleView = adView.findViewById(R.id.yandex_title);
        TextView bodyView = adView.findViewById(R.id.yandex_body);
        TextView domainView = adView.findViewById(R.id.yandex_domain);
        TextView sponsoredView = adView.findViewById(R.id.yandex_sponsored);
        TextView warningView = adView.findViewById(R.id.yandex_warning);
        Button ctaView = adView.findViewById(R.id.yandex_cta);
        ImageView feedbackView = adView.findViewById(R.id.yandex_feedback);
        // NOTE: rating is intentionally NOT bound. setRatingView() requires a
        // custom View that implements Yandex's own Rating interface — a
        // plain android.widget.RatingBar does not satisfy that bound, and
        // rating is not a mandatory asset (unlike domain/feedback below), so
        // it's dropped rather than building a custom Rating-compliant view.
        adView.findViewById(R.id.yandex_rating).setVisibility(View.GONE);

        NativeAdViewBinder binder = new NativeAdViewBinder.Builder(container)
                .setMediaView(mediaView)
                .setIconView(iconView)
                .setTitleView(titleView)
                .setBodyView(bodyView)
                .setDomainView(domainView)
                .setSponsoredView(sponsoredView)
                .setWarningView(warningView)
                .setCallToActionView(ctaView)
                .setFeedbackView(feedbackView)
                .build();

        AdBindingResult result = nativeAd.bindNativeAd(binder);
        if (result instanceof AdBindingResult.Failure) {
            String missing = ((AdBindingResult.Failure) result).getMissingAssetName();
            Utils.sout("Yandex native bind failed, missing asset: " + missing);
            container.setVisibility(View.GONE);
            return;
        }
        container.setVisibility(View.VISIBLE);
    }

    private static void scheduleNativeRetry(
            WeakReference<Activity> activityRef,
            WeakReference<TemplateView> admobRef,
            WeakReference<NativeAdView> yandexRef
    ) {
        cancelNativeRetry(); // never stack more than one pending retry
        nativeRetryRunnable = () -> {
            Activity activity = activityRef.get();
            TemplateView admobTemplate = admobRef.get();
            NativeAdView yandexNativeAdView = yandexRef.get();
            if (activity == null || activity.isFinishing() || activity.isDestroyed()
                    || admobTemplate == null || yandexNativeAdView == null) {
                return; // screen is gone — nothing to fill
            }
            loadAdMobNative(activity, admobTemplate, yandexNativeAdView);
        };
        nativeRetryHandler.postDelayed(nativeRetryRunnable, nativeRetryDelay);
        nativeRetryDelay = Math.min(nativeRetryDelay * 2, RETRY_MAX_DELAY_MS);
    }

    /** Cancels any pending native-ad retry and resets backoff. Call from onDestroy(). */
    public static void cancelNativeRetry() {
        if (nativeRetryRunnable != null) {
            nativeRetryHandler.removeCallbacks(nativeRetryRunnable);
            nativeRetryRunnable = null;
        }
        nativeRetryDelay = RETRY_BASE_DELAY_MS;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Interstitial Ads: AdMob first, Yandex fallback, with capped exponential
    // backoff retry if BOTH networks fail to preload.
    // ─────────────────────────────────────────────────────────────────────────
    private static InterstitialAd mInterstitialAd;
    private static com.yandex.mobile.ads.interstitial.InterstitialAd mYandexInterstitialAd;
    private static final Handler interstitialRetryHandler = new Handler(Looper.getMainLooper());
    private static Runnable interstitialRetryRunnable;
    private static long interstitialRetryDelay = RETRY_BASE_DELAY_MS;

    public static void firstLoadAds(Activity mActivity) {
        if (!BuildConfig.ADS_SHOWN) return;
        interstitialRetryDelay = RETRY_BASE_DELAY_MS; // fresh screen, reset backoff
        loadAdMobInterstitial(mActivity);
    }

    // MIGRATED to GMA Next-Gen SDK: InterstitialAd.load() no longer takes a
    // Context or adUnitId string directly — both go into AdRequest.Builder
    // (adUnitId is now the Builder's constructor arg, same pattern as
    // NativeAdRequest above). InterstitialAdLoadCallback is replaced by the
    // generic AdLoadCallback<InterstitialAd>.
    private static void loadAdMobInterstitial(Activity mActivity) {
        AdRequest adRequest = new AdRequest.Builder(mActivity.getString(R.string.interstitial_app_id)).build();

        InterstitialAd.load(adRequest, new AdLoadCallback<InterstitialAd>() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                interstitialRetryDelay = RETRY_BASE_DELAY_MS; // success — reset backoff
                mInterstitialAd = interstitialAd;
                mYandexInterstitialAd = null;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null;
                loadYandexInterstitial(mActivity);
            }
        });
    }

    private static void loadYandexInterstitial(Activity mActivity) {
        InterstitialAdLoader loader = new InterstitialAdLoader(mActivity);
        final WeakReference<Activity> activityRef = new WeakReference<>(mActivity);

        String adUnitId = mActivity.getString(R.string.yandex_interstitial_id);
        // SDK 8: build the request with adUnitId, pass listener into loadAd().
        com.yandex.mobile.ads.common.AdRequest request =
                new com.yandex.mobile.ads.common.AdRequest.Builder(adUnitId).build();

        loader.loadAd(request, new InterstitialAdLoadListener() {
            @Override
            public void onAdLoaded(@NonNull com.yandex.mobile.ads.interstitial.InterstitialAd ad) {
                interstitialRetryDelay = RETRY_BASE_DELAY_MS; // success — reset backoff
                mYandexInterstitialAd = ad;
            }

            @Override
            public void onAdFailedToLoad(@NonNull AdRequestError error) {
                mYandexInterstitialAd = null;
                scheduleInterstitialRetry(activityRef);
            }
        });
    }

    private static void scheduleInterstitialRetry(WeakReference<Activity> activityRef) {
        cancelInterstitialRetry(); // never stack more than one pending retry
        interstitialRetryRunnable = () -> {
            Activity activity = activityRef.get();
            if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
                return; // screen is gone — nothing to preload for
            }
            loadAdMobInterstitial(activity);
        };
        interstitialRetryHandler.postDelayed(interstitialRetryRunnable, interstitialRetryDelay);
        interstitialRetryDelay = Math.min(interstitialRetryDelay * 2, RETRY_MAX_DELAY_MS);
    }

    /** Cancels any pending interstitial-ad retry and resets backoff. Call from onDestroy(). */
    public static void cancelInterstitialRetry() {
        if (interstitialRetryRunnable != null) {
            interstitialRetryHandler.removeCallbacks(interstitialRetryRunnable);
            interstitialRetryRunnable = null;
        }
        interstitialRetryDelay = RETRY_BASE_DELAY_MS;
    }

    private static int LAUNCH_ADS = 1;
    private static final int COUNT_ADS = 3;

    // ADDED (AdMob "Site Behavior: Navigation" policy fix — "Ad density across
    // transitions"): every call site that shows an interstitial (Connect tap in
    // MainActivity, server-row tap in FreeServersFragment, the layoutServers
    // menu tap) used to go straight to mInterstitialAd.show()/mYandexInterstitialAd.show()
    // with no shared throttle between them, so two different transitions taken
    // seconds apart could each pop a full-screen ad back-to-back.
    //
    // WIDENED to cover App Open ads too (per Google's own App Open guidance —
    // "Don't display ads immediately before or after app open ads" / "Avoid
    // layering app open ads on top of other existing ads"): UIApplication's
    // AppOpenAdManager now reads and marks this SAME cooldown, so a warm-start
    // App Open ad and a Connect-tap interstitial can never land back-to-back
    // either. One full-screen ad (of ANY format) per interval, app-wide —
    // every other call site silently falls through to its no-ad path (action
    // still happens) until the cooldown clears.
    //
    // TUNED (more impressions, still policy-safe): started at 150s (2.5 min),
    // then 60s — still comfortably above every concrete number AdMob's own
    // guidance ties to real violations (the ~30s a slow network can take to
    // render a full-screen ad's close button; the recommendation to insert a
    // "please wait" pause after fast repeated taps).
    //
    // LOWERED again to 45s (still within the ~45–60s floor called out below —
    // do NOT drop further without re-checking Policy Center first). At 45s,
    // the fastest any two of Connect / server-select / open-Select-Server /
    // App Open can ever re-trigger an ad is 45s apart, which is still "never
    // twice in the same short burst of navigation" — the exact pattern that
    // was flagged — while showing more ads per session than 60s did.
    private static final long MIN_FULLSCREEN_AD_INTERVAL_MS = 45_000L; // 45s
    private static long lastFullScreenAdShownAt = 0L;

    public static boolean isFullScreenAdCoolingDown() {
        return System.currentTimeMillis() - lastFullScreenAdShownAt < MIN_FULLSCREEN_AD_INTERVAL_MS;
    }

    public static void markFullScreenAdShown() {
        lastFullScreenAdShownAt = System.currentTimeMillis();
    }

    public static void showIntAds(final Activity mActivity, final Handler handler) {
        showIntAds(mActivity, null, ZERO, handler);
    }

    public static void showIntAds(final Activity mActivity, final Class cls) {
        showIntAds(mActivity, cls, MINUS, null);
    }

    public static void showIntAds(final Activity mActivity, final Class cls, final int what, final Handler handler) {
        if (!BuildConfig.ADS_SHOWN) {
            openNextActivity(mActivity, cls, what, handler);
            return;
        }
        if (isFullScreenAdCoolingDown()) {
            Log.w("AdPolicyDebug", "showIntAds: COOLDOWN active, skipping ad, action runs immediately");
            openNextActivity(mActivity, cls, what, handler);
            return;
        }
        if (mInterstitialAd != null) {
            Log.w("AdPolicyDebug", "showIntAds: cooldown clear, AdMob interstitial ready -> showing now");
            showAdMobInterstitial(mActivity, cls, what, handler);
        } else if (mYandexInterstitialAd != null) {
            Log.w("AdPolicyDebug", "showIntAds: cooldown clear, Yandex interstitial ready -> showing now");
            showYandexInterstitial(mActivity, cls, what, handler);
        } else {
            Log.w("AdPolicyDebug", "showIntAds: cooldown clear but NO ad preloaded -> action runs immediately");
            openNextActivity(mActivity, cls, what, handler);
        }
    }

    public static void showIntAdsCount(final Activity mActivity, final Class cls) {
        showIntAdsCount(mActivity, cls, MINUS, null);
    }

    public static void showIntAdsCount(final Activity mActivity, final Class cls, final int what, final Handler handler) {
        if (!BuildConfig.ADS_SHOWN) {
            LAUNCH_ADS = 0;
            openNextActivity(mActivity, cls, what, handler);
            return;
        }
        boolean hasAd = (mInterstitialAd != null || mYandexInterstitialAd != null);
        if (hasAd && LAUNCH_ADS >= COUNT_ADS) {
            LAUNCH_ADS = 0;
            showIntAds(mActivity, cls, what, handler);
        } else {
            LAUNCH_ADS++;
            openNextActivity(mActivity, cls, what, handler);
        }
    }

    // MIGRATED to GMA Next-Gen SDK: setFullScreenContentCallback(FullScreenContentCallback)
    // is replaced by setAdEventCallback(InterstitialAdEventCallback). The
    // failure-to-show callback's error type changed from AdError to
    // FullScreenContentError. Two extra lifecycle methods (onAdShowedFullScreenContent,
    // onAdImpression, onAdClicked) are part of the same interface — left as
    // no-ops here since the original AdMob callback didn't use them either.
    private static void showAdMobInterstitial(Activity mActivity, Class cls, int what, Handler handler) {
        mInterstitialAd.setAdEventCallback(new InterstitialAdEventCallback() {
            @Override
            public void onAdShowedFullScreenContent() {}

            @Override
            public void onAdDismissedFullScreenContent() {
                openNextActivity(mActivity, cls, what, handler);
                firstLoadAds(mActivity);
            }

            @Override
            public void onAdFailedToShowFullScreenContent(@NonNull FullScreenContentError fullScreenContentError) {
                mInterstitialAd = null;
                if (mYandexInterstitialAd != null) {
                    showYandexInterstitial(mActivity, cls, what, handler);
                } else {
                    openNextActivity(mActivity, cls, what, handler);
                }
            }

            @Override
            public void onAdImpression() {}

            @Override
            public void onAdClicked() {}
        });
        markFullScreenAdShown();
        mInterstitialAd.show(mActivity);
    }

    private static void showYandexInterstitial(Activity mActivity, Class cls, int what, Handler handler) {
        mYandexInterstitialAd.setAdEventListener(new InterstitialAdEventListener() {
            @Override
            public void onAdShown() {}

            @Override
            public void onAdFailedToShow(@NonNull com.yandex.mobile.ads.common.AdError adError) {
                mYandexInterstitialAd = null;
                openNextActivity(mActivity, cls, what, handler);
            }

            @Override
            public void onAdDismissed() {
                mYandexInterstitialAd = null;
                openNextActivity(mActivity, cls, what, handler);
                firstLoadAds(mActivity);
            }

            @Override
            public void onAdClicked() {}

            @Override
            public void onAdImpression(@Nullable ImpressionData impressionData) {}
        });
        markFullScreenAdShown();
        mYandexInterstitialAd.show(mActivity);
    }

    private static void openNextActivity(Activity mActivity, Class cls, final int what, final Handler handler) {
        if (handler != null) {
            // FIXED: this used to ALSO build a second Message.obtain() (what=0),
            // attach the same handler as target, and sendToTarget() it right
            // after sendEmptyMessage(what) — so every call delivered TWO
            // messages to the handler instead of one. Callers whose
            // Handler.Callback doesn't branch on message.what (e.g.
            // MainActivity.myHandler -> prepareVpn(), FreeServersFragment.myHandler
            // -> startActivity(..., FLAG_ACTIVITY_CLEAR_TASK)) ran their action
            // twice back-to-back. For the VPN-connect flow that meant two
            // overlapping startVpn()/startActivity(CLEAR_TASK) calls racing each
            // other, with the second one tearing down/interrupting the OpenVPN
            // socket the first had just opened (InterruptedIOException in
            // OpenVPNThread) before the handshake could finish — the app looked
            // like it kept "trying a new server" without ever connecting.
            handler.sendEmptyMessage(what);
        } else {
            Screens.showCustomScreen(mActivity, cls);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Other utils
    // ─────────────────────────────────────────────────────────────────────────
    public static boolean checkInternetConnection(Activity mActivity) {
        final ConnectivityManager cm = (ConnectivityManager) mActivity.getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo nInfo = cm.getActiveNetworkInfo();
        return nInfo != null && nInfo.isConnectedOrConnecting();
    }

    public static void showToast(Activity mActivity, String message) {
        Toast.makeText(mActivity, message, Toast.LENGTH_SHORT).show();
    }

    public static void setThemeToWebView(Activity mActivity, WebView webView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            int nightModeFlags = mActivity.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            if (nightModeFlags == Configuration.UI_MODE_NIGHT_YES) {
                WebSettingsCompat.setForceDark(webView.getSettings(), WebSettingsCompat.FORCE_DARK_ON);
            } else {
                WebSettingsCompat.setForceDark(webView.getSettings(), WebSettingsCompat.FORCE_DARK_OFF);
            }
        }
    }

    public static String getAppVersionName() {
        return BuildConfig.VERSION_NAME;
    }

    public static void setDarkMode(final boolean b) {
        try {
            if (b) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
        } catch (Exception e) {
            Utils.getErrors(e);
        }
    }

    public static Typeface getRegularFont(Context context) {
        return ResourcesCompat.getFont(context, R.font.poppins);
    }

    // CHANGED: used to re-roll (well, tried to — the recursive call's result was
    // discarded, so it silently returned the "bad" number anyway) whenever the
    // pick landed on a multiple of ITEMS_PER_AD, to dodge the ad-placeholder
    // slots addBannerAds() used to splice into the list. Those slots are gone
    // (ads no longer live inside the server list — see MainActivity), so every
    // index is a real server and there is nothing left to dodge.
    public static int getRandomNumber(int min, int max) {
        return (new Random()).nextInt((max - min) + 1) + min;
    }

    public static Intent getOpenUrlIntent(Context c, boolean external) {
        return new Intent(Intent.ACTION_VIEW);
    }
}