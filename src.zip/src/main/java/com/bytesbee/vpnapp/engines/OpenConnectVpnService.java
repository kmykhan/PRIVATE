package pvt.zalmiltd.vpn.engines;

import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.widget.Toast;

import org.infradead.libopenconnect.LibOpenConnect;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.constants.IConstants;
import pvt.zalmiltd.vpn.models.Server;

/**
 * ADDED: OpenConnect engine (Cisco AnyConnect / ocserv servers), ported from UAE VPN Pro.
 *
 * A session does, in order: authenticate (obtainCookie, answering the login form with the server's credentials),
 * open the CSTP channel, establish the TUN device from the addresses/routes the server pushed, hand its fd to
 * libopenconnect, try DTLS and then run the library's main loop on a worker thread until the session ends.
 */
public class OpenConnectVpnService extends VpnService {

    private static final String TAG = "OpenConnect";

    private static final String REPORTED_OS = "android";
    private static final String MOBILE_DEVICE_ID = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    private static final int MAX_AUTH_FORMS = 3;
    private static final int MIN_MTU = 1280;
    private static final int DTLS_ATTEMPT_PERIOD_SEC = 60;
    private static final int RECONNECT_TIMEOUT_SEC = 300;
    private static final long STOP_JOIN_TIMEOUT_MS = 3_000L;
    private static final long STATS_INTERVAL_MS = 1_000L;

    //Without an IPv6 route IPv6 traffic would bypass the tunnel; the server drops it and apps fall back to IPv4
    private static final String BLACKHOLE_ADDRESS_V6 = "fd00:6f63::2";
    private static final int BLACKHOLE_PREFIX_V6 = 64;
    private static final String[] FALLBACK_DNS = {"1.1.1.1", "8.8.8.8"};

    private static Boolean libraryLoaded;

    private final Object lock = new Object();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private Thread worker;
    private Client client;
    private volatile boolean cancelled;
    private volatile boolean connected;

    private long lastRx, lastTx;

    /** libopenconnect.so is bundled for arm64-v8a and armeabi-v7a only. */
    static synchronized boolean isAvailable() {
        if (libraryLoaded == null) {
            try {
                System.loadLibrary("openconnect");
                libraryLoaded = true;
            } catch (Throwable t) {
                Log.e(TAG, "libopenconnect could not be loaded", t);
                libraryLoaded = false;
            }
        }
        return libraryLoaded;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (VpnEngines.ACTION_CONNECT.equals(action)) {
            String name = intent.getStringExtra(VpnEngines.EXTRA_NAME);
            VpnEngines.startForeground(this, getString(R.string.app_name), name == null ? "" : name);
            startSession(intent);
        } else if (VpnEngines.ACTION_DISCONNECT.equals(action)) {
            new Thread(() -> {
                stopSession();
                VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.DISCONNECTED);
                mainHandler.post(this::finish);
            }, "openconnect-stop").start();
        } else {
            stopSelf(startId);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onRevoke() {
        Log.w(TAG, "VPN permission revoked");
        new Thread(() -> {
            stopSession();
            VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.DISCONNECTED);
            mainHandler.post(this::finish);
        }, "openconnect-revoke").start();
    }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        cancelled = true;
        synchronized (lock) {
            if (client != null) client.cancel();
        }
        super.onDestroy();
    }

    private void finish() {
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void startSession(Intent intent) {
        final String host = intent.getStringExtra(VpnEngines.EXTRA_HOST);
        final String user = nullToEmpty(intent.getStringExtra(VpnEngines.EXTRA_USER));
        final String pass = nullToEmpty(intent.getStringExtra(VpnEngines.EXTRA_PASS));
        final ArrayList<String> apps = intent.getStringArrayListExtra(VpnEngines.EXTRA_APPS);
        final boolean appsAllowed = intent.getBooleanExtra(VpnEngines.EXTRA_APPS_ALLOWED, false);

        new Thread(() -> {
            //A server switch arrives as a new connect while the previous session is still up
            stopSession();
            cancelled = false;
            connected = false;
            VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.WAIT);

            if (!isAvailable() || host == null || host.isEmpty()) {
                toast(R.string.strServerUnavailable);
                VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.DISCONNECTED);
                mainHandler.post(this::finish);
                return;
            }
            Thread thread = new Thread(() -> run(host, user, pass, apps, appsAllowed), "openconnect");
            worker = thread;
            thread.start();
        }, "openconnect-start").start();
    }

    /** Cancels the running session and waits for its worker to wind down. */
    private void stopSession() {
        cancelled = true;
        mainHandler.removeCallbacks(statsTicker);
        synchronized (lock) {
            if (client != null) client.cancel();
        }
        Thread thread = worker;
        worker = null;
        if (thread != null && thread != Thread.currentThread()) {
            try {
                thread.join(STOP_JOIN_TIMEOUT_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void run(String host, String user, String pass, List<String> apps, boolean appsAllowed) {
        Client oc = new Client(user, pass);
        synchronized (lock) {
            if (cancelled) {
                oc.destroy();
                return;
            }
            client = oc;
        }

        ParcelFileDescriptor tun = null;
        String endState = IConstants.DISCONNECTED;
        try {
            oc.setLogLevel(LibOpenConnect.PRG_INFO);
            oc.setXMLPost(true);
            oc.setPFS(false);
            oc.setReportedOS(REPORTED_OS);
            oc.setMobileInfo("1.0", REPORTED_OS, MOBILE_DEVICE_ID);

            if (oc.parseURL(host) != 0) {
                toast(R.string.strServerUnavailable);
                return;
            }

            VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.AUTH);
            int cookieResult = oc.obtainCookie();
            if (cancelled) return;
            if (cookieResult != 0) {
                if (oc.authRejected) {
                    VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.AUTH_FAILED);
                } else {
                    toast(R.string.strServerUnreachable);
                }
                return;
            }

            VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.WAIT);
            if (oc.makeCSTPConnection() != 0) {
                if (!cancelled) toast(R.string.strServerUnreachable);
                return;
            }
            if (cancelled) return;

            tun = establishTun(oc.getIPInfo(), apps, appsAllowed);
            if (tun == null || oc.setupTunFD(tun.getFd()) != 0) {
                if (!cancelled) toast(R.string.strServerUnavailable);
                return;
            }

            connected = true;
            lastRx = 0;
            lastTx = 0;
            VpnEngines.post(this, Server.TYPE_OPENCONNECT, IConstants.CONNECTED);
            mainHandler.postDelayed(statsTicker, STATS_INTERVAL_MS);

            oc.setupDTLS(DTLS_ATTEMPT_PERIOD_SEC);
            //noinspection StatementWithEmptyBody
            while (!cancelled && oc.mainloop(RECONNECT_TIMEOUT_SEC, LibOpenConnect.RECONNECT_INTERVAL_MIN) >= 0) {
            }
        } catch (Exception e) {
            Log.e(TAG, "OpenConnect session crashed", e);
        } finally {
            mainHandler.removeCallbacks(statsTicker);
            connected = false;
            //Same order as ics-openconnect: the TUN goes first, the library context after it
            if (tun != null) {
                try {
                    tun.close();
                } catch (Exception ignored) {
                }
            }
            synchronized (lock) {
                if (client == oc) client = null;
            }
            oc.destroy();

            //A session that ends by itself (server dropped it, bad credentials, unreachable) takes the service down;
            //a stopSession() from a newer start or a disconnect reports on its own
            if (!cancelled) {
                VpnEngines.post(this, Server.TYPE_OPENCONNECT, endState);
                mainHandler.post(this::finish);
            }
        }
    }

    private final Runnable statsTicker = new Runnable() {
        @Override
        public void run() {
            synchronized (lock) {
                if (client != null && connected) client.requestStats();
            }
            mainHandler.postDelayed(this, STATS_INTERVAL_MS);
        }
    };

    private ParcelFileDescriptor establishTun(LibOpenConnect.IPInfo info, List<String> apps, boolean appsAllowed) {
        if (info == null || info.addr == null) {
            Log.e(TAG, "Server pushed no IPv4 address");
            return null;
        }

        Builder builder = new Builder()
                .setSession(getString(R.string.app_name))
                .setMtu(Math.max(info.MTU, MIN_MTU));
        builder.addAddress(info.addr, prefixLength(info.netmask));

        String[] v6 = info.netmask6 == null ? null : info.netmask6.split("/");
        if (v6 != null && v6.length == 2) builder.addAddress(v6[0], Integer.parseInt(v6[1]));
        else builder.addAddress(BLACKHOLE_ADDRESS_V6, BLACKHOLE_PREFIX_V6);

        List<String> includes = new ArrayList<>();
        for (String route : info.splitIncludes) {
            if (route != null && !route.trim().isEmpty()) includes.add(route.trim());
        }
        if (includes.isEmpty()) {
            builder.addRoute("0.0.0.0", 0);
            builder.addRoute("::", 0);
        } else {
            for (String route : includes) addRoute(builder, route);
        }

        List<String> dns = new ArrayList<>();
        for (String server : info.DNS) {
            if (server != null && !server.trim().isEmpty()) dns.add(server.trim());
        }
        if (dns.isEmpty()) {
            for (String server : FALLBACK_DNS) dns.add(server);
        }
        for (String server : dns) {
            try {
                builder.addDnsServer(server);
                //With split routes the resolver itself must still be reachable through the tunnel
                if (!includes.isEmpty()) builder.addRoute(server, server.contains(":") ? 128 : 32);
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "Ignoring invalid DNS server " + server);
            }
        }
        if (info.domain != null && !info.domain.trim().isEmpty()) {
            try {
                builder.addSearchDomain(info.domain.trim());
            } catch (IllegalArgumentException ignored) {
            }
        }

        applyAppFilter(builder, getPackageName(), apps, appsAllowed);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false);

        try {
            return builder.establish();
        } catch (Exception e) {
            Log.e(TAG, "Could not establish the TUN device", e);
            return null;
        }
    }

    /**
     * The app itself always stays outside the tunnel (its own sockets are protected anyway). With [allowed], only
     * [apps] use the VPN; otherwise [apps] are the ones kept out of it.
     */
    static void applyAppFilter(Builder builder, String ownPackage, List<String> apps, boolean allowed) {
        try {
            if (allowed && apps != null && !apps.isEmpty()) {
                for (String app : apps) {
                    if (app.equals(ownPackage)) continue;
                    try {
                        builder.addAllowedApplication(app);
                    } catch (Exception e) {
                        Log.w(TAG, "Could not route " + app + " through the VPN");
                    }
                }
                return;
            }
            builder.addDisallowedApplication(ownPackage);
            if (apps != null) {
                for (String app : apps) {
                    if (app.equals(ownPackage)) continue;
                    try {
                        builder.addDisallowedApplication(app);
                    } catch (Exception e) {
                        Log.w(TAG, "Could not exclude " + app + " from the VPN");
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "App filter could not be applied", e);
        }
    }

    /** Split routes come as addr/prefix (IPv6, sometimes IPv4) or addr/dotted.netmask (IPv4). */
    private static void addRoute(Builder builder, String route) {
        try {
            String[] parts = route.split("/");
            String address = parts[0];
            boolean v6 = address.contains(":");
            int prefix;
            if (parts.length == 1) prefix = v6 ? 128 : 32;
            else if (parts[1].contains(".")) prefix = prefixLength(parts[1]);
            else prefix = Integer.parseInt(parts[1]);
            builder.addRoute(address, prefix);
        } catch (Exception e) {
            Log.w(TAG, "Skipping invalid route " + route);
        }
    }

    private static int prefixLength(String netmask) {
        try {
            InetAddress address = InetAddress.getByName(netmask);
            if (address instanceof Inet6Address) return 32;
            int bits = 0;
            for (byte b : address.getAddress()) bits += Integer.bitCount(b & 0xFF);
            return bits;
        } catch (Exception e) {
            return 32;
        }
    }

    private void toast(int message) {
        mainHandler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show());
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }

    /** Answers the server's login form with the credentials that came with the server list. */
    private final class Client extends LibOpenConnect {

        private final String user;
        private final String pass;
        private int formsAnswered;
        volatile boolean authRejected;

        Client(String user, String pass) {
            this.user = user;
            this.pass = pass;
        }

        @Override
        public int onProcessAuthForm(AuthForm authForm) {
            //The server re-sends the form (usually with an error) when the previous answer was rejected
            if (authForm.error != null || ++formsAnswered > MAX_AUTH_FORMS) {
                Log.w(TAG, "Login rejected: " + authForm.error);
                authRejected = true;
                return OC_FORM_RESULT_CANCELLED;
            }
            for (FormOpt opt : authForm.opts) {
                if ((opt.flags & OC_FORM_OPT_IGNORE) != 0) continue;
                if (opt.type == OC_FORM_OPT_TEXT) opt.value = user;
                else if (opt.type == OC_FORM_OPT_PASSWORD) opt.value = pass;
                else if (opt.type == OC_FORM_OPT_SELECT && opt.value == null && !opt.choices.isEmpty()) {
                    //Keep whatever group the server preselected
                    opt.value = opt.choices.get(0).name;
                }
            }
            return OC_FORM_RESULT_OK;
        }

        //These servers use self-signed certificates and the list carries no fingerprint to pin, so every
        //certificate is accepted, exactly like the original app did
        @Override
        public int onValidatePeerCert(String msg) {
            return 0;
        }

        @Override
        public void onProtectSocket(int fd) {
            if (!protect(fd)) Log.w(TAG, "Could not protect socket " + fd);
        }

        @Override
        public void onProgress(int level, String msg) {
            if (level <= PRG_INFO) Log.d(TAG, "libopenconnect: " + msg.trim());
        }

        @Override
        public void onStatsUpdate(VPNStats stats) {
            long rx = stats.rxBytes, tx = stats.txBytes;
            long rxRate = lastRx == 0 ? 0 : Math.max(0, rx - lastRx);
            long txRate = lastTx == 0 ? 0 : Math.max(0, tx - lastTx);
            lastRx = rx;
            lastTx = tx;
            VpnEngines.postBytes(OpenConnectVpnService.this, rx, tx, rxRate, txRate);
        }
    }
}
