package pvt.zalmiltd.vpn;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import pvt.zalmiltd.vpn.engines.RealityConfig;
import pvt.zalmiltd.vpn.engines.VpnEngines;
import pvt.zalmiltd.vpn.managers.RemoteConfigManager;
import pvt.zalmiltd.vpn.models.Server;

/**
 * ADDED: the two server lists ported from UAE VPN Pro, mapped onto this app's Server model.
 *
 * OpenConnect: the Super VPN panel's api.php?action=get_servers, read from every configured mirror and merged (a
 * server listed by several mirrors, same IP, appears once).
 * Hydra: a paginated {data:[{name,country_code,city_name,link,status}], next_page_url} list of vless:// links.
 *
 * Servers whose engine cannot run on this device (x86 builds ship no libopenconnect/libXray) are left out.
 */
final class ExtraServerSources {

    private static final String TAG = "ExtraServerSources";
    private static final int MAX_HYDRA_PAGES = 20;
    private static final int PORT_CHECK_TIMEOUT_MS = 3000;
    private static final int OPENCONNECT_PORT = 443;

    private static final Map<String, String> COUNTRY_ALIASES = new HashMap<>();

    static {
        COUNTRY_ALIASES.put("united states of america", "us");
        COUNTRY_ALIASES.put("usa", "us");
        COUNTRY_ALIASES.put("uk", "gb");
        COUNTRY_ALIASES.put("great britain", "gb");
        COUNTRY_ALIASES.put("england", "gb");
        COUNTRY_ALIASES.put("uae", "ae");
        COUNTRY_ALIASES.put("russia", "ru");
        COUNTRY_ALIASES.put("turkey", "tr");
        COUNTRY_ALIASES.put("south korea", "kr");
        COUNTRY_ALIASES.put("korea", "kr");
        COUNTRY_ALIASES.put("vietnam", "vn");
        COUNTRY_ALIASES.put("czech republic", "cz");
        COUNTRY_ALIASES.put("hong kong", "hk");
        COUNTRY_ALIASES.put("taiwan", "tw");
        COUNTRY_ALIASES.put("iran", "ir");
    }

    private static Map<String, String> countriesByName;

    private ExtraServerSources() {
    }

    static List<Server> loadOpenConnect() {
        List<Server> servers = new ArrayList<>();
        List<String> mirrors = RemoteConfigManager.getOpenConnectListUrls();
        if (mirrors.isEmpty() || !VpnEngines.isAvailable(Server.TYPE_OPENCONNECT)) return servers;

        Set<String> seenIps = new HashSet<>();
        for (String mirror : mirrors) {
            try {
                JSONObject root = new JSONObject(get(mirror));
                if (root.optInt("status") != 1) continue;
                JSONArray list = root.getJSONArray("servers");
                for (int i = 0; i < list.length(); i++) {
                    JSONObject item = list.getJSONObject(i);
                    String ip = item.optString("IP", "").trim();
                    String user = item.optString("username", "");
                    String hostName = item.optString("HostName", "").trim();
                    String flag = item.optString("certificate", "");
                    boolean active = "1".equals(item.optString("ServerStatus", "1"));
                    //"f_0" marks the panel's "Auto Select" placeholder; the app has its own auto mode
                    boolean autoSelect = "f_0".equals(flag) || hostName.equalsIgnoreCase("Auto Select");
                    if (!active || autoSelect || ip.isEmpty() || user.isEmpty() || !seenIps.add(ip)) continue;

                    String iso = countryCode(hostName, flag.replace('_', ' '));
                    if (iso == null) continue;

                    String city = item.optString("city", "").trim();
                    String name = city.isEmpty() || city.equalsIgnoreCase("Random Server") ? hostName : city;

                    Server server = new Server(name, iso, null, user, item.optString("password", ""));
                    server.setVpnType(Server.TYPE_OPENCONNECT);
                    server.setHost(ip);
                    servers.add(server);
                }
            } catch (Exception e) {
                Log.w(TAG, "OpenConnect mirror failed: " + mirror, e);
            }
        }
        servers = keepReachable(servers);
        Log.d(TAG, "OpenConnect servers: " + servers.size());
        return servers;
    }

    static List<Server> loadHydra() {
        List<Server> servers = new ArrayList<>();
        if (!VpnEngines.isAvailable(Server.TYPE_HYDRA)) return servers;
        Set<String> seenLinks = new HashSet<>();

        //The app's own servers (Remote Config hydra_extra_servers) come first
        String extra = RemoteConfigManager.getHydraExtraServers();
        if (extra != null) {
            try {
                addHydraItems(new JSONArray(extra), servers, seenLinks);
            } catch (Exception e) {
                Log.w(TAG, "hydra_extra_servers is not a valid list", e);
            }
        }

        String firstPage = RemoteConfigManager.getHydraListUrl();
        String listHost = null;
        try {
            if (firstPage != null) listHost = new URL(firstPage).getHost();
        } catch (Exception ignored) {
        }

        String next = listHost == null ? null : firstPage;
        int pages = 0;
        while (next != null && pages++ < MAX_HYDRA_PAGES) {
            try {
                JSONObject page = new JSONObject(get(next));
                JSONArray data = page.optJSONArray("data");
                if (data != null) addHydraItems(data, servers, seenLinks);
                //Only follow the list's own pagination, never a link that leads somewhere else
                String nextUrl = page.optString("next_page_url", "");
                next = nextUrl.startsWith("https://") && listHost.equals(new URL(nextUrl).getHost()) ? nextUrl : null;
            } catch (Exception e) {
                Log.w(TAG, "Hydra list page failed: " + next, e);
                next = null;
            }
        }
        servers = keepReachable(servers);
        Log.d(TAG, "Hydra servers: " + servers.size());
        return servers;
    }

    /** Adds each active {country_code, city_name, name, status, link} item the Hydra engine can run, once per link. */
    private static void addHydraItems(JSONArray items, List<Server> servers, Set<String> seenLinks) throws Exception {
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.getJSONObject(i);
            String status = item.optString("status", "");
            if (!status.equals("1") && !status.equalsIgnoreCase("true") && !status.equalsIgnoreCase("active")) continue;
            String link = item.optString("link", "").trim();
            //Only links the Hydra engine can run (REALITY or plain VLESS over tcp/xhttp/grpc) are listed
            if (RealityConfig.parseOrNull(link) == null || !seenLinks.add(link)) continue;

            String iso = item.optString("country_code", "").trim().toLowerCase(Locale.ROOT);
            String city = item.optString("city_name", "").trim();
            String name = city.isEmpty() ? item.optString("name", iso.toUpperCase(Locale.ROOT)) : city;

            Server server = new Server(name, iso, null, "", "");
            server.setVpnType(Server.TYPE_HYDRA);
            server.setHydraLink(link);
            servers.add(server);
        }
    }

    /**
     * Drops servers whose port does not accept a TCP connection within PORT_CHECK_TIMEOUT_MS, so dead entries the
     * panels still list never reach the user. All servers are checked at once. If none answers at all, the network
     * itself is probably the problem, so the list is kept as it was rather than emptied.
     */
    private static List<Server> keepReachable(List<Server> servers) {
        if (servers.isEmpty()) return servers;
        java.util.concurrent.ExecutorService pool =
                java.util.concurrent.Executors.newFixedThreadPool(Math.min(servers.size(), 24));
        try {
            List<java.util.concurrent.Future<Boolean>> checks = new ArrayList<>();
            for (Server server : servers) {
                checks.add(pool.submit(() -> isReachable(server)));
            }
            List<Server> reachable = new ArrayList<>();
            for (int i = 0; i < servers.size(); i++) {
                boolean up;
                try {
                    up = checks.get(i).get(PORT_CHECK_TIMEOUT_MS + 2000L, java.util.concurrent.TimeUnit.MILLISECONDS);
                } catch (Exception e) {
                    up = false;
                }
                if (up) reachable.add(servers.get(i));
                else Log.d(TAG, "Hiding unreachable server " + servers.get(i).getCountry());
            }
            return reachable.isEmpty() ? servers : reachable;
        } finally {
            pool.shutdownNow();
        }
    }

    private static boolean isReachable(Server server) {
        String host;
        int port;
        if (Server.TYPE_HYDRA.equals(server.getVpnType())) {
            RealityConfig config = RealityConfig.parseOrNull(server.getHydraLink());
            if (config == null) return false;
            host = config.address();
            port = config.port();
        } else {
            host = server.getHost();
            port = OPENCONNECT_PORT;
        }
        if (host == null || host.isEmpty()) return false;
        try (java.net.Socket socket = new java.net.Socket()) {
            socket.connect(new java.net.InetSocketAddress(host, port), PORT_CHECK_TIMEOUT_MS);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static String countryCode(String... names) {
        synchronized (ExtraServerSources.class) {
            if (countriesByName == null) {
                countriesByName = new HashMap<>();
                for (String iso : Locale.getISOCountries()) {
                    String display = new Locale.Builder().setRegion(iso).build()
                            .getDisplayCountry(Locale.ENGLISH).toLowerCase(Locale.ROOT);
                    countriesByName.put(display, iso.toLowerCase(Locale.ROOT));
                }
            }
        }
        for (String name : names) {
            String key = name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
            if (key.isEmpty()) continue;
            String alias = COUNTRY_ALIASES.get(key);
            if (alias != null) return alias;
            String iso = countriesByName.get(key);
            if (iso != null) return iso;
        }
        return null;
    }

    private static String get(String address) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(address).openConnection();
        try {
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("Accept", "application/json");
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            }
            return sb.toString().trim();
        } finally {
            conn.disconnect();
        }
    }
}
