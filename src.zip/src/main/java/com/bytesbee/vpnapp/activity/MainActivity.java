package pvt.zalmiltd.vpn.activity;

import static androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult;
import static pvt.zalmiltd.vpn.constants.IConstants.MINUS;
import static pvt.zalmiltd.vpn.constants.IConstants.MY_IP;
import static pvt.zalmiltd.vpn.constants.IConstants.ONE;
import static pvt.zalmiltd.vpn.constants.IConstants.ONLY_SELECT;
import static pvt.zalmiltd.vpn.constants.IConstants.SELECT_NOT;
import static pvt.zalmiltd.vpn.constants.IConstants.VPN_IP;
import static pvt.zalmiltd.vpn.constants.IConstants.ZERO;
import static pvt.zalmiltd.vpn.managers.SessionManager.KEY_ONLY_SELECT;
import static pvt.zalmiltd.vpn.managers.SessionManager.KEY_SELECT_NOT;
import static pvt.zalmiltd.vpn.managers.UsageManager.KEY_TOTAL_CONNECTIONS;
import static pvt.zalmiltd.vpn.managers.UsageManager.STR_CONNECTIONS;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.ServerLoader;
import pvt.zalmiltd.vpn.adapter.NavigationAdapter;
import pvt.zalmiltd.vpn.constants.IConstants;
import pvt.zalmiltd.vpn.managers.RemoteConfigManager;
import pvt.zalmiltd.vpn.managers.SessionManager;
import pvt.zalmiltd.vpn.managers.UsageManager;
import pvt.zalmiltd.vpn.models.IPModel;
import pvt.zalmiltd.vpn.models.Navigation;
import pvt.zalmiltd.vpn.models.Server;
import pvt.zalmiltd.vpn.utils.Utils;
import com.google.android.ads.nativetemplates.TemplateView;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.yandex.mobile.ads.nativeads.NativeAdView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import de.blinkt.openvpn.VpnProfile;
import de.blinkt.openvpn.core.ConfigParser;
import de.blinkt.openvpn.core.OpenVPNService;
import de.blinkt.openvpn.core.OpenVPNThread;
import de.blinkt.openvpn.core.ProfileManager;
import de.blinkt.openvpn.core.VPNLaunchHelper;
import de.blinkt.openvpn.core.VpnStatus;
import pvt.zalmiltd.vpn.engines.VpnEngines;
import dev.shreyaspatil.MaterialDialog.BottomSheetMaterialDialog;

public class MainActivity extends BaseAppActivity implements View.OnClickListener {
    private DrawerLayout drawerLayout;
    private Activity mActivity;
    private Toolbar toolbar;
    private RecyclerView recyclerView;
    public static ArrayList<Server> items;
    public static boolean serversLoaded = false;
    private TextView txtStatus, txtCountryName, txtTime, txtUploadSpeed, txtDownloadSpeed;
    private TextView txtYourIPAddress, txtVPNIPAddress;
    private ImageView imgCountryFlag, imgInstalledApp;
    private TemplateView templateView;
    private NativeAdView yandexNativeAdView;
    private ConstraintLayout layoutServers;
    private LottieAnimationView animationView, imgConnect, imgDisconnect, imgDownload, imgUpload, imgTime;
    private SwitchCompat darkModeOnOff;
    private boolean vpnStart = false;
    private boolean isBegin = false;
    private Server server;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setInsetMode(findViewById(R.id.mainRootLayout));
        mActivity = this;
        init();
        initData();
        initListeners();

        final ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.strNavOpen, R.string.strNavClose);
        toggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.colorTitleText));
        drawerLayout.addDrawerListener(toggle);
        toggle.setDrawerIndicatorEnabled(true);
        toggle.syncState();
        setRecyclerView();

        // FIXED (crash: "MobileAds.initialize must be called before using
        // the Google Mobile Ads SDK"): these used to run immediately here,
        // which could fire before UIApplication.initializeAdsSdk() (called
        // from SplashActivity post-UMP-consent) had actually finished on a
        // fresh process. Deferring through runWhenAdsInitialized() runs them
        // right away once the SDK really is ready (or immediately if it
        // already was), instead of assuming it always already is by the
        // time MainActivity opens.
        UIApplication.runWhenAdsInitialized(() -> {
            if (mActivity == null || mActivity.isFinishing() || mActivity.isDestroyed()) return;
            Utils.initNativeAds(mActivity, templateView, yandexNativeAdView);
            Utils.firstLoadAds(mActivity);
        });

        askNotification13();
        goBack();
    }

    @Override
    public void onStart() {
        super.onStart();
        try {
            mHandler = new Handler(message -> {
                try {
                    Gson gson = new Gson();
                    IPModel ipModel = gson.fromJson((String) message.obj, IPModel.class);
                    String ip = ipModel.getIp();
                    Utils.sout("IP Value: " + ip + " = " + ipModel);
                    if (message.what == MY_IP) {
                        txtYourIPAddress.setText(ip);
                    } else if (message.what == VPN_IP) {
                        txtVPNIPAddress.setText(ip);
                    }
                } catch (Exception e) {
                    if (message.what == MY_IP) {
                        txtYourIPAddress.setText(getString(R.string.strDash));
                    } else if (message.what == VPN_IP) {
                        txtVPNIPAddress.setText(getString(R.string.strDash));
                    }
                }
                return true;
            });
        } catch (Exception ignored) {
        }
    }

    private void askNotification13() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

    final ActivityResultLauncher<String> requestPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGrant -> Utils.sout("PermissionLauncher: " + isGrant));

    public void init() {
        final Date Today = Calendar.getInstance().getTime();
        final SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
        TODAY = df.format(Today);

        toolbar = findViewById(R.id.toolbar);
        drawerLayout = findViewById(R.id.drawerLayout);
        recyclerView = findViewById(R.id.recyclerView);
        txtStatus = findViewById(R.id.txtStatus);
        layoutServers = findViewById(R.id.layoutServers);
        templateView = findViewById(R.id.templateView);
        yandexNativeAdView = findViewById(R.id.yandexNativeAdView);
        imgConnect = findViewById(R.id.imgConnect);
        imgDisconnect = findViewById(R.id.imgDisconnect);
        imgCountryFlag = findViewById(R.id.imgCountryFlag);
        imgInstalledApp = findViewById(R.id.imgInstalledApp);
        txtCountryName = findViewById(R.id.txtCountryName);
        txtTime = findViewById(R.id.txtTime);
        animationView = findViewById(R.id.animationView);
        imgDownload = findViewById(R.id.imgDownload);
        imgUpload = findViewById(R.id.imgUpload);
        imgTime = findViewById(R.id.imgTime);
        txtDownloadSpeed = findViewById(R.id.txtDownloadSpeed);
        txtUploadSpeed = findViewById(R.id.txtUploadSpeed);
        txtYourIPAddress = findViewById(R.id.txtYourIPAddress);
        txtVPNIPAddress = findViewById(R.id.txtVPNIPAddress);
        darkModeOnOff = findViewById(R.id.darkModeOnOff);

        final TextView mTxtVersionName = findViewById(R.id.txtVersionName);
        mTxtVersionName.setText(getString(R.string.version, Utils.getAppVersionName()));

        if (!serversLoaded || items == null || items.isEmpty()) {
            items = new ArrayList<>();
            // ADDED (perf: "app feels slow/heavy to open"): show whatever
            // list we fetched last time IMMEDIATELY, from disk, instead of
            // leaving the screen on "loading" until a fresh network round
            // trip finishes. loadServersFromRemote() below still runs right
            // away too, and silently swaps in the fresh list (or, on
            // failure, just keeps retrying in the background) once it
            // completes — the cached copy is only ever a placeholder, never
            // stale-forever.
            List<Server> cachedServers = SessionManager.get().getCachedServersList();
            if (cachedServers != null && !cachedServers.isEmpty()) {
                applyLoadedServers(cachedServers);
            }
            loadServersFromRemote();
        }
    }

    // ADDED: shared by the cached-list fast path above and the live
    // onServersLoaded() callback below — was previously duplicated inline
    // inside onServersLoaded()'s runOnUiThread().
    private void applyLoadedServers(List<Server> servers) {
        items = new ArrayList<>();
        serversLoaded = false;
        addBannerAds(servers);
        serversLoaded = true;
        if (SessionManager.get().getServer() == null && !items.isEmpty()) {
            for (Server s : items) {
                if (s != null && s.getIndex() != MINUS) {
                    SessionManager.get().saveServer(s);
                    server = s;
                    break;
                }
            }
        }
        if (server == null) {
            server = SessionManager.get().getServer();
        }
        // ADDED: the saved server is a snapshot from when it was picked; take
        // the same server from the fresh list so a renamed entry (and its new
        // position in the list) shows up here too.
        Server fresh = findSameServer(server);
        if (fresh != null) {
            server = fresh;
            SessionManager.get().saveServer(fresh);
        }
        if (server != null) {
            txtCountryName.setText(server.getCountry());
            setFlagByIso(server.getFlagIso(), server.getFlagIcon());
        }
    }

    /** The entry in [items] that connects to the same place as [saved], or null. */
    private Server findSameServer(Server saved) {
        if (saved == null || items == null) return null;
        for (Server s : items) {
            if (s == null || !s.getVpnType().equals(saved.getVpnType())) continue;
            String a, b;
            if (Server.TYPE_OPENCONNECT.equals(s.getVpnType())) {
                a = s.getHost();
                b = saved.getHost();
            } else if (Server.TYPE_HYDRA.equals(s.getVpnType())) {
                a = s.getHydraLink();
                b = saved.getHydraLink();
            } else {
                a = s.getOvpn();
                b = saved.getOvpn();
            }
            if (a != null && a.equals(b)) return s;
        }
        return null;
    }

    // CHANGED: the JSON source URL now comes from RemoteConfigManager
    // (Firebase Remote Config, with the old hardcoded GitHub URL kept only
    // as its fallback default) instead of being baked into ServerLoader.
    private void loadServersFromRemote() {
        new ServerLoader(RemoteConfigManager.getServersApiUrl(), new ServerLoader.ServerLoadListener() {
            @Override
            public void onServersLoaded(List<Server> servers) {
                // ADDED: persist to disk so the NEXT cold launch (this
                // Activity re-created after the process was killed, static
                // `items` gone) has an instant list to show via the cache
                // fast-path above, instead of a blank screen until this same
                // network call completes again.
                SessionManager.get().saveServersList(servers);
                runOnUiThread(() -> applyLoadedServers(servers));
            }

            @Override
            public void onServerLoadFailed(String error) {
                runOnUiThread(() -> {
                    if (serversLoaded && items != null && !items.isEmpty()) {
                        new android.os.Handler().postDelayed(() -> loadServersFromRemote(), 5000);
                    } else {
                        Toast.makeText(mActivity, "Server load failed, retrying...", Toast.LENGTH_SHORT).show();
                        new android.os.Handler().postDelayed(() -> loadServersFromRemote(), 3000);
                    }
                });
            }
        }).execute();
    }

    private void setFlagByIso(String iso, int fallbackRes) {
        if (iso != null && !iso.isEmpty()) {
            int resId = getResources().getIdentifier("flag_" + iso, "drawable", getPackageName());
            if (resId != 0) {
                imgCountryFlag.setImageResource(resId);
                return;
            }
        }
        if (fallbackRes != 0) {
            imgCountryFlag.setImageResource(fallbackRes);
        }
    }

    public void initData() {
        try {
            if (getIntent().getStringExtra(IConstants.BUNDLE_KEY_SERVER) == null) {
                server = SessionManager.get().getServer();
            } else {
                server = new Gson().fromJson(getIntent().getStringExtra(IConstants.BUNDLE_KEY_SERVER), Server.class);
                if (vpnStart) {
                    stopVpn();
                }
                resetFailover();
                prepareVpn();
            }
            if (server != null) {
                txtCountryName.setText(server.getCountry());
                setFlagByIso(server.getFlagIso(), server.getFlagIcon());
            }
        } catch (Exception e) {
            Utils.getErrors(e);
        }

        VpnStatus.initLogCache(mActivity.getCacheDir());

        darkModeOnOff.setChecked(SessionManager.get().isDarkModeOn());
        darkModeOnOff.setOnCheckedChangeListener((compoundButton, b) -> {
            SessionManager.get().setOnOffDarkMode(b);
            Utils.setDarkMode(b);
        });

        callIPAddress(MY_IP);
    }

    // FIXED (AdMob "Site Behavior: Navigation" policy violation): this used to
    // splice a null placeholder into the server list every ITEMS_PER_AD items,
    // which ServerListAdapter rendered as an inline banner ad row. Ads loading
    // asynchronously *after* the list had already rendered shifted every row
    // below them while the user was reaching for a country — exactly the
    // "content and ads overlap / accidental click" pattern AdMob flagged.
    // Ads no longer live inside the tappable list at all; see the single
    // anchored banner at the bottom of fragment_free_servers.xml instead.
    private void addBannerAds(List<Server> temp) {
        for (int i = ZERO; i < temp.size(); i++) {
            Server s = temp.get(i);
            s.setIndex(i);
            items.add(s);
        }
    }

    public void initListeners() {
        layoutServers.setOnClickListener(this);
        imgConnect.setOnClickListener(this);
        imgDisconnect.setOnClickListener(this);
        imgInstalledApp.setOnClickListener(this);
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));

        final ArrayList<Navigation> navItems = new ArrayList<>();
        navItems.add(new Navigation(getString(R.string.strSelectServer), R.drawable.ic_nb_server));
        navItems.add(new Navigation(getString(R.string.strUsageHistory), R.drawable.ic_nb_usage));
        navItems.add(new Navigation(getString(R.string.strTools), R.drawable.ic_nb_network_check));
        navItems.add(new Navigation(getString(R.string.strLogs), R.drawable.ic_nb_logs));
        navItems.add(new Navigation(getString(R.string.strPrivacyPolicy), R.drawable.ic_nb_policy));
        navItems.add(new Navigation(getString(R.string.strTermsOfService), R.drawable.ic_nb_termofservice));
        navItems.add(new Navigation(getString(R.string.strRate), R.drawable.ic_nb_star));
        navItems.add(new Navigation(getString(R.string.strFeedback), R.drawable.ic_nb_feedback));
        NavigationAdapter adapter = new NavigationAdapter(mActivity, getSupportFragmentManager(), navItems, () -> {
            if (drawerLayout != null) {
                if (drawerLayout.isOpen())
                    drawerLayout.close();
            }
        });
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.layoutServers) {
            Log.w("AdPolicyDebug", "layoutServers (Select Server icon) tapped -> Utils.showIntAdsCount()");
            Utils.showIntAdsCount(mActivity, SelectServersActivity.class);
        } else if (id == R.id.imgConnect || id == R.id.imgDisconnect) {
            if (vpnStart) {
                DisconnectFromConnectedServer();
            } else {
                if (animationView.getVisibility() == View.GONE) {
                    // FIXED (AdMob "Site Behavior: Navigation" policy violation —
                    // "an ad interrupting the app's core function mid-action" was
                    // the exact language of the flag): this used to route through
                    // Utils.showIntAds(mActivity, myHandler), which showed a
                    // full-screen interstitial FIRST and only called prepareVpn()
                    // once the user dismissed it — so tapping Connect visibly
                    // blocked the one thing the user just asked for behind an ad.
                    // Per AdMob's own "Recommended interstitial implementations"
                    // guidance (ads should sit at natural transition points, not
                    // right after a direct action tap — the "Next button" case
                    // they specifically call out as surprising/click-prone),
                    // Connect now runs immediately with no ad in front of it. The
                    // interstitial moved to setStatus()'s CONNECTED case instead —
                    // it fires once the connection transition has actually
                    // completed, a natural pause point, never blocking the tap.
                    Log.w("AdPolicyDebug", "Connect tapped -> prepareVpn() directly, NO ad here");
                    resetFailover();
                    prepareVpn();
                } else {
                    stopVpn();
                }
            }
        } else if (id == R.id.imgInstalledApp) {
            if (vpnStart) {
                Toast.makeText(mActivity, "Kindly disconnect and update this options to reflect new changes", Toast.LENGTH_SHORT).show();
            }
            final Intent intent = new Intent(mActivity, InstalledAppActivity.class);
            appLauncher.launch(intent);
        }
    }

    final ActivityResultLauncher<Intent> appLauncher = registerForActivityResult(
            new StartActivityForResult(),
            result -> {
            });

    public void DisconnectFromConnectedServer() {
        // ADDED: wrapped in try/catch — on some OEM ROMs (MIUI/Xiaomi devices in
        // particular) this library's internal theme-color lookup throws
        // UnsupportedOperationException ("Can't convert value ... to color:
        // type=0x1") while building the bottom-sheet view. It was already
        // non-fatal in practice (caught somewhere below us), but nothing here
        // guaranteed that, so a slightly different theme/attribute combination
        // could have turned it into a real crash. Now if the fancy confirmation
        // dialog can't be built at all, we fall back to a plain AlertDialog that
        // does the exact same job, instead of risking any crash.
        try {
            BottomSheetMaterialDialog mBottomSheetDialog = new BottomSheetMaterialDialog.Builder(this)
                    .setTitle(getString(R.string.strDisConnect))
                    .setMessage(getString(R.string.strDisconnectMsg))
                    .setCancelable(false)
                    .setPositiveButton(getString(R.string.lblDisconnect), R.drawable.ic_disconnect, (dialogInterface, which) -> {
                        stopVpn();
                        dialogInterface.dismiss();
                    })
                    .setNegativeButton(getString(R.string.cancel), R.drawable.ic_close, (dialogInterface, which) -> dialogInterface.dismiss())
                    .build();
            mBottomSheetDialog.show();
        } catch (Exception e) {
            Utils.getErrors(e);
            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle(getString(R.string.strDisConnect))
                    .setMessage(getString(R.string.strDisconnectMsg))
                    .setCancelable(false)
                    .setPositiveButton(getString(R.string.lblDisconnect), (dialogInterface, which) -> {
                        stopVpn();
                        dialogInterface.dismiss();
                    })
                    .setNegativeButton(getString(R.string.cancel), (dialogInterface, which) -> dialogInterface.dismiss())
                    .show();
        }
    }

    // REMOVED: myHandler (used to be the ad-dismiss callback for the old
    // ad-before-connect flow — see onClick() above). Connect no longer routes
    // through Utils.showIntAds, so nothing calls this anymore.

    // ADDED: no-op callback for the CONNECTED-state interstitial (see
    // setStatus() below) — that call site has nothing to do once the ad is
    // dismissed (or skipped), unlike the Connect tap which used to need
    // prepareVpn() run afterward.
    private final Handler adDismissNoOpHandler = new Handler(message -> true);

    public void stopVpn() {
        cancelFailover();
        try {
            isBegin = false;
            hideShowLoading(false);
            // ADDED: OpenConnect / Hydra sessions stop here too.
            VpnEngines.stopAll(this);
            OpenVPNService.abortConnectionVPN = true;
            ProfileManager.setConntectedVpnProfileDisconnected(this);
            OpenVPNThread.stop();
            txtStatus.setText(getString(R.string.strTapStart));
        } catch (Exception e) {
            Utils.getErrors(e);
        }
    }

    private VpnProfile vpnProfile;

    // ADDED: set by prepareVpn() when the chosen server belongs to the
    // OpenConnect or Hydra engine instead of OpenVPN; startVpn() then hands
    // it to VpnEngines rather than building an OpenVPN profile.
    private Server engineServer;

    private void startEngine(Server target) {
        final int selectedItem = SessionManager.get().getConnectTunnel();
        ArrayList<String> apps = new ArrayList<>();
        boolean appsAllowed = false;
        try {
            if (selectedItem == SELECT_NOT) {
                apps = SessionManager.get().getPackageList(KEY_SELECT_NOT);
            } else if (selectedItem == ONLY_SELECT) {
                apps = SessionManager.get().getPackageList(KEY_ONLY_SELECT);
                appsAllowed = true;
            }
        } catch (Exception e) {
            Utils.getErrors(e);
        }
        //An OpenVPN session still up would fight the new one for the VPN slot
        if (VpnStatus.isVPNActive()) {
            try {
                ProfileManager.setConntectedVpnProfileDisconnected(this);
                OpenVPNThread.stop();
            } catch (Exception e) {
                Utils.getErrors(e);
            }
        }
        VpnEngines.start(mActivity, target, apps, appsAllowed);

        isBegin = true;
        start_vpn();
        txtStatus.setText(getString(R.string.strWaitingMsg, txtCountryName.getText()));
        txtStatus.setTextColor(getResources().getColor(R.color.colorTitleText));
    }

    private void startVpn() {
        beginConnectAttempt();
        if (engineServer != null) {
            try {
                startEngine(engineServer);
            } catch (Exception e) {
                Utils.getErrors(e);
            }
            return;
        }
        try {
            // ADDED: switching from an OpenConnect/Hydra session to OpenVPN.
            VpnEngines.stopAll(mActivity);
            final int selectedItem = SessionManager.get().getConnectTunnel();
            ArrayList<String> bypassPackages = new ArrayList<>();
            try {
                if (selectedItem == SELECT_NOT) {
                    bypassPackages = SessionManager.get().getPackageList(KEY_SELECT_NOT);
                    vpnProfile.mAllowedAppsVpnAreDisallowed = true;
                } else if (selectedItem == ONLY_SELECT) {
                    bypassPackages = SessionManager.get().getPackageList(KEY_ONLY_SELECT);
                    vpnProfile.mAllowedAppsVpnAreDisallowed = false;
                }
            } catch (Exception e) {
                Utils.getErrors(e);
            }
            if (bypassPackages != null && !bypassPackages.isEmpty()) {
                vpnProfile.mAllowedAppsVpn.addAll(bypassPackages);
                vpnProfile.mAllowAppVpnBypass = true;
            }

            ProfileManager.setTemporaryProfile(mActivity, vpnProfile);
            VPNLaunchHelper.startOpenVpn(vpnProfile, mActivity, "New country selection", false);

            isBegin = true;
            start_vpn();

            txtStatus.setText(getString(R.string.strWaitingMsg, txtCountryName.getText()));
            txtStatus.setTextColor(getResources().getColor(R.color.colorTitleText));
        } catch (Exception e) {
            Utils.getErrors(e);
        }
    }

    // FIXED: prepareVpn() fetches/builds the .ovpn config on a background
    // Thread and only sets isBegin=true once that finishes and startVpn()
    // actually runs. That left a window — between the tap and the config
    // fetch completing — where the "!vpnStart && !isBegin" guard below was
    // still open. Any second trigger landing in that window (a fast double
    // tap on Connect, the AdMob/Yandex ad-dismiss callback firing again,
    // FreeServersFragment relaunching MainActivity while a fetch was still
    // in flight, etc.) slipped past the guard and kicked off a SECOND
    // config fetch + VPN start. When that second start reached
    // OpenVPNService.startOpenVPN(), stopOldOpenVPNProcess() tore down the
    // first connection's still-negotiating management socket a few seconds
    // in — "InterruptedIOException: read interrupted by close() on another
    // thread" with no crash anywhere in the log, which is exactly the
    // "servers connect nhi hory" symptom seen after the AdMob native-ad
    // crash was already fixed. isPreparingVpn closes that window.
    private volatile boolean isPreparingVpn = false;

    private void prepareVpn() {
        if (!vpnStart && !isBegin) {
            if (isPreparingVpn) {
                return;
            }
            if (Utils.checkInternetConnection(mActivity)) {
                isPreparingVpn = true;
                new Thread(() -> {
                    try {
                        Server autoSelect;
                        if (server != null && server.getCountry().equalsIgnoreCase(getString(R.string.strAutoSelect))) {
                            // CHANGED: no more ad placeholders inside MainActivity.items
                            // (see addBannerAds above), so every index in range is a real
                            // server now — no need to shrink the range to dodge ad slots.
                            final int totalSize = MainActivity.items.size() - ONE;
                            autoSelect = MainActivity.items.get(Utils.getRandomNumber(ONE, totalSize));
                        } else {
                            autoSelect = server;
                        }

                        if (autoSelect == null) {
                            isPreparingVpn = false;
                            return;
                        }

                        Utils.sout("Server Name:: " + autoSelect.getCountry() + " >> " + autoSelect.getIndex());

                        // ADDED: OpenConnect / Hydra servers carry no OpenVPN
                        // config at all — they only need the VPN permission.
                        if (VpnEngines.handles(autoSelect)) {
                            final Server target = autoSelect;
                            attemptServer = autoSelect;
                            runOnUiThread(() -> {
                                engineServer = target;
                                txtCountryName.setText(target.getCountry());
                                txtStatus.setText(getString(R.string.strWaitingMsg, txtCountryName.getText()));
                                txtStatus.setTextColor(getResources().getColor(R.color.colorTitleText));
                                hideShowLoading(true);

                                Intent intent = VpnService.prepare(mActivity);
                                if (intent != null)
                                    resultLauncher.launch(intent);
                                else
                                    startVpn();
                                isPreparingVpn = false;
                            });
                            return;
                        }

                        String ovpnPath = autoSelect.getOvpn();
                        StringBuilder config = new StringBuilder();

                        // ADDED: admin-panel API servers carry a full,
                        // already-built OpenVPN config (see ServerLoader /
                        // OvpnConfigBuilder) instead of a URL or an assets
                        // filename — use it directly, nothing to download
                        // or open.
                        if (ovpnPath != null && ovpnPath.startsWith(ServerLoader.RAW_CONFIG_PREFIX)) {
                            config.append(ovpnPath.substring(ServerLoader.RAW_CONFIG_PREFIX.length()));
                        } else {
                            InputStream conf;
                            if (ovpnPath != null && ovpnPath.startsWith("http")) {
                                HttpURLConnection ovpnConn = (HttpURLConnection) new URL(ovpnPath).openConnection();
                                ovpnConn.setConnectTimeout(15000);
                                ovpnConn.setReadTimeout(15000);
                                ovpnConn.connect();
                                conf = ovpnConn.getInputStream();
                            } else {
                                conf = getAssets().open(ovpnPath);
                            }

                            BufferedReader br = new BufferedReader(new InputStreamReader(conf));
                            String line;
                            while ((line = br.readLine()) != null) {
                                config.append(line).append("\n");
                            }
                        }
                        config.append("--data-ciphers DEFAULT:AES-128-CBC").append("\n");

                        ConfigParser configParser = new ConfigParser();
                        configParser.parseConfig(new StringReader(config.toString()));
                        vpnProfile = configParser.convertProfile();

                        if (vpnProfile.checkProfile(mActivity) != R.string.no_error_found) {
                            throw new RemoteException(getString(vpnProfile.checkProfile(mActivity)));
                        }

                        final Server finalServer = autoSelect;
                        attemptServer = autoSelect;
                        engineServer = null;
                        vpnProfile.mName = finalServer.getCountry();
                        vpnProfile.mProfileCreator = mActivity.getPackageName();
                        vpnProfile.mUsername = finalServer.getOvpnUserName();
                        vpnProfile.mPassword = finalServer.getOvpnUserPassword();
                        vpnProfile.mDNS1 = VpnProfile.DEFAULT_DNS1;
                        vpnProfile.mDNS2 = VpnProfile.DEFAULT_DNS2;
                        vpnProfile.mOverrideDNS = true;

                        runOnUiThread(() -> {
                            txtCountryName.setText(finalServer.getCountry());
                            txtStatus.setText(getString(R.string.strWaitingMsg, txtCountryName.getText()));
                            txtStatus.setTextColor(getResources().getColor(R.color.colorTitleText));
                            hideShowLoading(true);

                            Intent intent = VpnService.prepare(mActivity);
                            if (intent != null)
                                resultLauncher.launch(intent);
                            else
                                startVpn();
                            isPreparingVpn = false;
                        });

                    } catch (Exception e) {
                        Utils.getErrors(e);
                        isPreparingVpn = false;
                        runOnUiThread(() ->
                                Toast.makeText(mActivity, "Failed to load VPN config", Toast.LENGTH_SHORT).show());
                    }
                }).start();
            } else {
                Utils.showToast(mActivity, getString(R.string.strNoInternetConnectionMsg));
            }
        } else {
            stopVpn();
        }
    }

    private String TODAY;

    private void start_vpn() {
        long connection_today = UsageManager.get().getUsage(TODAY + STR_CONNECTIONS);
        long connection_total = UsageManager.get().getUsage(KEY_TOTAL_CONNECTIONS);
        UsageManager.get().setUsage(TODAY + STR_CONNECTIONS, connection_today + 1);
        UsageManager.get().setUsage(KEY_TOTAL_CONNECTIONS, connection_total + 1);
    }

    private String conn = "";

    // ADDED: automatic failover. When a server does not connect within
    // CONNECT_TIMEOUT_MS, or reports a failure (unreachable, login rejected)
    // before ever connecting, another server is tried automatically:
    //   1. up to SERVERS_PER_PROTOCOL servers of the same protocol, then
    //   2. the next protocol group (Hydra -> AnyConnect -> OpenVPN -> Hydra),
    // until every protocol has been tried. A whole protocol is often blocked
    // on a network, which is why it does not keep trying one protocol only.
    // When everything failed a dialog lets the user pick a server or retry.
    // A tap on Connect / a server resets it; any stopVpn() cancels it.
    private static final long CONNECT_TIMEOUT_MS = 35_000L;
    private static final int SERVERS_PER_PROTOCOL = 2;
    //DISCONNECTED from the session being replaced can arrive right after a new start; it is not this attempt failing
    private static final long FAILOVER_GRACE_MS = 1_200L;
    private static final long FAILOVER_RETRY_DELAY_MS = 1_500L;

    private final Handler failoverHandler = new Handler(Looper.getMainLooper());
    private Server attemptServer;
    private boolean connectAttemptActive;
    private long connectAttemptStartedAt;
    private final java.util.Set<String> triedProtocols = new java.util.HashSet<>();
    private final java.util.Set<Server> triedServers = new java.util.HashSet<>();
    private int triesInProtocol;

    private final Runnable connectTimeout = () -> {
        if (connectAttemptActive && !vpnStart) failover();
    };

    /** A fresh connect chosen by the user: every protocol and server may be tried again. */
    private void resetFailover() {
        triedProtocols.clear();
        triedServers.clear();
        triesInProtocol = 0;
    }

    private void beginConnectAttempt() {
        connectAttemptActive = true;
        connectAttemptStartedAt = System.currentTimeMillis();
        Server tried = findSameServer(attemptServer);
        if (tried != null) {
            triedServers.add(tried);
            triedProtocols.add(tried.getVpnType());
        }
        failoverHandler.removeCallbacks(connectTimeout);
        failoverHandler.postDelayed(connectTimeout, CONNECT_TIMEOUT_MS);
    }

    private void onConnectAttemptSucceeded() {
        connectAttemptActive = false;
        resetFailover();
        failoverHandler.removeCallbacks(connectTimeout);
    }

    private void cancelFailover() {
        connectAttemptActive = false;
        failoverHandler.removeCallbacksAndMessages(null);
    }

    /** @return true when the failure was taken over by a failover to another server. */
    private boolean onConnectAttemptFailed() {
        if (!connectAttemptActive || vpnStart) return false;
        if (System.currentTimeMillis() - connectAttemptStartedAt < FAILOVER_GRACE_MS) return false;
        return failover();
    }

    private boolean failover() {
        Server failed = findSameServer(attemptServer);
        String failedType = failed != null ? failed.getVpnType() : (attemptServer != null ? attemptServer.getVpnType() : null);

        Server next = null;
        boolean switchedProtocol = false;
        if (triesInProtocol + 1 < SERVERS_PER_PROTOCOL) {
            next = nextOfSameProtocol(failed, failedType);
        }
        if (next != null) {
            triesInProtocol++;
        } else {
            next = firstOfNextProtocol(failedType);
            switchedProtocol = next != null;
            triesInProtocol = 0;
        }

        stopVpn();
        if (next == null) {
            Log.w("Failover", "Every protocol failed, giving up");
            resetFailover();
            txtStatus.setText(getString(R.string.strAllServersFailed));
            showConnectionFailedDialog();
            return true;
        }
        Log.w("Failover", "Server " + (failed == null ? "?" : failed.getCountry()) + " failed, trying " + next.getCountry()
                + (switchedProtocol ? " (next protocol " + next.getVpnType() + ")" : ""));

        server = next;
        SessionManager.get().saveServer(next);
        txtCountryName.setText(next.getCountry());
        setFlagByIso(next.getFlagIso(), next.getFlagIcon());
        txtStatus.setText(switchedProtocol
                ? getString(R.string.strSwitchingProtocol, protocolGroupName(next.getVpnType()))
                : getString(R.string.strTryingNextServer, next.getCountry()));
        hideShowLoading(true);
        failoverHandler.postDelayed(this::prepareVpn, FAILOVER_RETRY_DELAY_MS);
        return true;
    }

    /** The next not-yet-tried server of [type] after [current] in the list, wrapping around. */
    private Server nextOfSameProtocol(Server current, String type) {
        if (items == null || items.isEmpty() || type == null) return null;
        int at = current == null ? -1 : items.indexOf(current);
        for (int step = 1; step <= items.size(); step++) {
            Server candidate = items.get(((at + step) % items.size() + items.size()) % items.size());
            if (candidate != null && type.equals(candidate.getVpnType()) && !triedServers.contains(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    /** The first server of the next protocol group (in list order, wrapping) that has not been tried yet. */
    private Server firstOfNextProtocol(String currentType) {
        if (items == null || items.isEmpty()) return null;
        java.util.List<String> order = new ArrayList<>();
        for (Server s : items) {
            if (s != null && !order.contains(s.getVpnType())) order.add(s.getVpnType());
        }
        int at = currentType == null ? -1 : order.indexOf(currentType);
        for (int step = 1; step <= order.size(); step++) {
            String type = order.get(((at + step) % order.size() + order.size()) % order.size());
            if (triedProtocols.contains(type)) continue;
            for (Server s : items) {
                if (s != null && type.equals(s.getVpnType()) && !triedServers.contains(s)) return s;
            }
        }
        return null;
    }

    private String protocolGroupName(String type) {
        if (Server.TYPE_HYDRA.equals(type)) return getString(R.string.strGroupHydra);
        if (Server.TYPE_OPENCONNECT.equals(type)) return getString(R.string.strGroupAnyConnect);
        return getString(R.string.strGroupOpenVpn);
    }

    private void showConnectionFailedDialog() {
        if (isFinishing() || isDestroyed()) return;
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.strConnectionFailedTitle)
                .setMessage(R.string.strConnectionFailedMsg)
                .setPositiveButton(R.string.strChooseServer, (dialog, which) ->
                        startActivity(new Intent(mActivity, SelectServersActivity.class)))
                .setNeutralButton(R.string.strRetry, (dialog, which) -> {
                    resetFailover();
                    prepareVpn();
                })
                .setNegativeButton(R.string.cancel, (dialog, which) -> dialog.dismiss())
                .show();
    }

    public void setStatus(String connectionState) {
        if (connectionState != null) {
            conn = connectionState;
            Utils.sout("ConnectionState:: " + connectionState);
            switch (connectionState) {
                case IConstants.AUTH_FAILED:
                    txtStatus.setText(getString(R.string.strAuthFailedMsg));
                    onConnectAttemptFailed();
                    break;

                case IConstants.CONNECTRETRY:
                case IConstants.WAIT:
                    txtStatus.setText(getString(R.string.strWaitingMsg, txtCountryName.getText()));
                    txtStatus.setTextColor(getResources().getColor(R.color.colorTitleText));
                    hideShowLoading(true);
                    break;

                case IConstants.AUTH:
                    txtStatus.setText(getString(R.string.strAuthMsg));
                    txtStatus.setTextColor(getResources().getColor(R.color.colorTitleText));
                    hideShowLoading(true);
                    break;

                case IConstants.NO_NETWORK:
                    final Handler handler = new Handler(Looper.getMainLooper());
                    handler.postDelayed(() -> {
                        if (conn.equalsIgnoreCase(IConstants.NO_NETWORK)) {
                            txtStatus.setText(getString(R.string.strNoIntentConnection));
                            txtStatus.setTextColor(getResources().getColor(R.color.colorTitleText));
                            hideShowLoading(true);
                            stopTimer();
                        }
                    }, 1000 * 10);
                    break;

                case IConstants.CONNECTED:
                    onConnectAttemptSucceeded();
                    vpnStart = true;
                    isBegin = true;
                    txtStatus.setText(getString(R.string.strConnected));
                    imgConnect.setVisibility(View.GONE);
                    imgDisconnect.setVisibility(View.VISIBLE);
                    hideShowLoading(false);
                    imgDownload.playAnimation();
                    imgUpload.playAnimation();
                    imgTime.playAnimation();
                    startTimer = System.currentTimeMillis();
                    timerHandler.postDelayed(timerRunnable, 0);
                    callIPAddress(VPN_IP);
                    // ADDED (AdMob interstitial placement fix — see onClick()'s
                    // comment): the Connect-tap interstitial now fires HERE,
                    // once the connect transition has actually finished, instead
                    // of blocking the tap itself. Utils' shared full-screen-ad
                    // cooldown (see Utils.showIntAds) still applies, so a quick
                    // reconnect/retry cycle that re-enters CONNECTED won't stack
                    // ads — it just silently skips until the cooldown clears.
                    Log.w("AdPolicyDebug", "CONNECTED reached -> calling Utils.showIntAds()");
                    Utils.showIntAds(mActivity, adDismissNoOpHandler);
                    break;

                case IConstants.USERPAUSE:
                    break;

                case IConstants.ASSIGN_IP:
                    break;

                case IConstants.RECONNECTING:
                case IConstants.DISCONNECTED:
                    if (IConstants.DISCONNECTED.equals(connectionState) && onConnectAttemptFailed()) {
                        break;
                    }
                    isBegin = false;
                    if (vpnStart) {
                        vpnStart = false;
                        OpenVPNService.setDefaultStatus();
                        txtStatus.setText(getString(R.string.strTapStart));
                        stopTimer();
                    }
                    txtVPNIPAddress.setText(getString(R.string.strDash));
                    imgConnect.setVisibility(View.VISIBLE);
                    imgDisconnect.setVisibility(View.GONE);
                    hideShowLoading(false);
                    break;
            }
        }
    }

    private Handler backgroundHandler;

    private void initHandlerThread() {
        HandlerThread handlerThread = new HandlerThread("BackgroundThread");
        handlerThread.start();
        backgroundHandler = new Handler(handlerThread.getLooper());
    }

    private void callIPAddress(int ipAddr) {
        initHandlerThread();
        backgroundHandler.postDelayed(() -> {
            try {
                String myOwnIP = getMyOwnIP();
                Message msg = Message.obtain(mHandler, ipAddr, myOwnIP);
                msg.sendToTarget();
            } catch (Exception e) {
                Utils.getErrors(e);
            }
        }, 200);
    }

    private Handler mHandler;
    private HttpURLConnection urlConnection;

    private String getMyOwnIP() throws IllegalArgumentException {
        StringBuilder resp = new StringBuilder();
        try {
            final URL url = new URL("https://ipinfo.io/json");
            urlConnection = (HttpURLConnection) url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            while (true) {
                String line = in.readLine();
                if (line == null) return resp.toString();
                resp.append(line);
            }
        } catch (Exception e) {
            Utils.getErrors(e);
            return "";
        } finally {
            try {
                urlConnection.disconnect();
            } catch (Exception e) {
                Utils.getErrors(e);
            }
        }
    }

    private long startTimer;
    private final Handler timerHandler = new Handler();

    private final Runnable timerRunnable = new Runnable() {
        public void run() {
            try {
                long millis = System.currentTimeMillis() - startTimer;
                Date date = new Date(millis);
                DateFormat formatter = new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH);
                formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
                String formatted = formatter.format(date);
                txtTime.setText(formatted);
                timerHandler.postDelayed(this, 500);
            } catch (Exception ignored) {
            }
        }
    };

    private void stopTimer() {
        try {
            imgDownload.pauseAnimation();
            imgUpload.pauseAnimation();
            imgTime.pauseAnimation();
            imgDownload.setFrame(0);
            imgUpload.setFrame(0);
            imgTime.setFrame(0);
            if (timerRunnable != null) {
                timerHandler.removeCallbacks(timerRunnable);
                txtTime.setText(R.string.strStaticTime);
            }
        } catch (Exception e) {
            Utils.sout(e.getMessage());
        }
    }

    public void updateConnectionStatus(String byteIn, String bytesOut) {
        txtDownloadSpeed.setText(byteIn);
        txtUploadSpeed.setText(bytesOut);
    }

    final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                setStatus(intent.getStringExtra("state"));
            } catch (Exception e) {
                Utils.getErrors(e);
            }
            try {
                String strDownloadSpeed, strUploadSpeed;
                String byteIn = intent.getStringExtra("byteIn");
                String byteOut = intent.getStringExtra("byteOut");

                if (byteIn == null) strDownloadSpeed = getString(R.string.strStaticSpeed);
                else strDownloadSpeed = byteIn.split("-")[0];
                strDownloadSpeed = strDownloadSpeed.substring(1);

                if (byteOut == null) strUploadSpeed = getString(R.string.strStaticSpeed);
                else strUploadSpeed = byteOut.split("-")[0];
                strUploadSpeed = strUploadSpeed.substring(1);

                updateConnectionStatus(strDownloadSpeed, strUploadSpeed);
            } catch (Exception e) {
                Utils.getErrors(e);
            }
        }
    };

    @Override
    public void onPause() {
        LocalBroadcastManager.getInstance(mActivity).unregisterReceiver(broadcastReceiver);
        super.onPause();
    }

    @Override
    public void onResume() {
        try {
            LocalBroadcastManager.getInstance(mActivity).registerReceiver(broadcastReceiver, new IntentFilter("connectionState"));
            if (server == null) {
                server = SessionManager.get().getServer();
            }
            // ADDED: an OpenConnect/Hydra session reports CONNECTED once; a
            // MainActivity opened later (e.g. after picking a server) would
            // otherwise keep showing "tap to connect".
            if (!vpnStart && VpnEngines.isConnected()) {
                setStatus(IConstants.CONNECTED);
            }
        } catch (Exception e) {
            Utils.getErrors(e);
        }
        super.onResume();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    /**
     * ADDED with the ad retry policy.
     *
     * Utils holds the native and interstitial slots in STATIC fields, and the
     * retry backoff runs on a Handler posting delayed Runnables. Those Runnables
     * capture this Activity (through the WeakReference Utils keeps) and touch
     * templateView / yandexNativeAdView. Without cancelling here, a retry
     * scheduled up to 64 seconds out can still fire after the screen is gone:
     * best case it wastes a request on views nobody will see, worst case it
     * inflates a Yandex NativeBannerView into a detached parent.
     *
     * The weak refs plus the isFinishing() checks inside Utils already make that
     * a no-op rather than a crash, but cancelling is the cheaper, more honest
     * thing to do — it stops the work instead of letting it run and discard.
     *
     * Note this does NOT touch the app-open retry in UIApplication. That one is
     * deliberately tied to the Application context and must survive Activity
     * teardown, since its whole job is to have an ad ready for the next launch.
     */
    @Override
    protected void onDestroy() {
        Utils.cancelNativeRetry();
        Utils.cancelInterstitialRetry();
        super.onDestroy();
    }

    private long exitTime = 0;

    private void goBack() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                exitApp();
            }
        });
    }

    public void exitApp() {
        int DEFAULT_DELAY = 2000;
        if (drawerLayout != null) {
            if (drawerLayout.isOpen()) {
                drawerLayout.close();
                return;
            }
        }
        if ((System.currentTimeMillis() - exitTime) > DEFAULT_DELAY) {
            try {
                final Snackbar snackbar = Snackbar.make(findViewById(R.id.mainRootLayout), getString(R.string.press_again_to_exit), Snackbar.LENGTH_LONG);
                final View sbView = snackbar.getView();
                final TextView textView = sbView.findViewById(com.google.android.material.R.id.snackbar_text);
                textView.setTypeface(Utils.getRegularFont(mActivity));
                textView.setTextColor(ContextCompat.getColor(mActivity, R.color.colorSnackBar));
                snackbar.show();
            } catch (Exception e) {
                Utils.getErrors(e);
                Utils.showToast(mActivity, getString(R.string.press_again_to_exit));
            }
            exitTime = System.currentTimeMillis();
        } else {
            this.moveTaskToBack(true);
        }
    }

    public void hideShowLoading(boolean value) {
        if (value) {
            animationView.setVisibility(View.VISIBLE);
        } else {
            animationView.setVisibility(View.GONE);
            imgConnect.setVisibility(View.VISIBLE);
        }
    }

    final ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(
            new StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    try {
                        startVpn();
                    } catch (Exception e) {
                        Utils.getErrors(e);
                    }
                } else {
                    Utils.sout(getString(R.string.strPermissionDeniedMsg));
                }
            });
}