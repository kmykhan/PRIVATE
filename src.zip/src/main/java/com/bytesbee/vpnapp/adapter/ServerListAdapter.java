package pvt.zalmiltd.vpn.adapter;

import static pvt.zalmiltd.vpn.constants.IConstants.MINUS;

import android.annotation.SuppressLint;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.interfaces.onNewServerSelectedListener;
import pvt.zalmiltd.vpn.managers.SessionManager;
import pvt.zalmiltd.vpn.models.Server;
import pvt.zalmiltd.vpn.utils.Utils;

import java.util.ArrayList;
import java.util.List;

// FIXED (AdMob "Site Behavior: Navigation" policy violation): this adapter used
// to render a BANNER_AD_VIEW_TYPE row wherever MainActivity.addBannerAds() had
// spliced a null placeholder into the list, loading a banner ad asynchronously
// *inside* the tappable server list. That shifted rows the user was reaching
// for as ads popped in — the highest accidental-click risk AdMob flagged. Ads
// no longer live in this list at all: MainActivity no longer inserts the null
// placeholders, and FreeServersFragment now shows a single banner anchored
// below the list, outside the RecyclerView, with clear separation. This
// adapter is server rows only.
// CHANGED: the list now carries a heading row above each protocol group
// (HYDRA / ANYCONNECT / OPENVPN, in the order ServerLoader merges them).
// Headings are not clickable and not part of MainActivity.items, so rows and
// servers no longer share positions: every position goes through `rows`.
public class ServerListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_SERVER = 0;
    private static final int TYPE_HEADER = 1;

    private final List<Object> rows = new ArrayList<>();
    private final Context mContext;
    private int selectedIndex = MINUS;
    private final onNewServerSelectedListener onNewServerSelectedListener;

    public ServerListAdapter(Context mContext, ArrayList<Server> mItems, onNewServerSelectedListener onNewServerSelectedListener) {
        this.mContext = mContext;
        this.onNewServerSelectedListener = onNewServerSelectedListener;
        final Server mySer = SessionManager.get().getServer();
        if (mySer != null) selectedIndex = mySer.getIndex();

        String lastType = null;
        for (Server server : mItems) {
            if (server == null) continue;
            String type = server.getVpnType();
            if (!type.equals(lastType)) {
                rows.add(headingFor(type));
                lastType = type;
            }
            rows.add(server);
        }
    }

    private String headingFor(String type) {
        if (Server.TYPE_HYDRA.equals(type)) return mContext.getString(R.string.strGroupHydra);
        if (Server.TYPE_OPENCONNECT.equals(type)) return mContext.getString(R.string.strGroupAnyConnect);
        return mContext.getString(R.string.strGroupOpenVpn);
    }

    @Override
    public int getItemViewType(int position) {
        return rows.get(position) instanceof Server ? TYPE_SERVER : TYPE_HEADER;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            return new HeaderViewHolder(inflater.inflate(R.layout.row_item_server_header, parent, false));
        }
        return new ViewHolder(inflater.inflate(R.layout.row_item_servers, parent, false));
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        try {
            Object row = rows.get(position);
            if (holder instanceof HeaderViewHolder) {
                ((HeaderViewHolder) holder).txtHeader.setText((String) row);
                return;
            }
            final Server mServer = (Server) row;
            final ViewHolder h = (ViewHolder) holder;

            if (mServer.getFlagIso() != null && !mServer.getFlagIso().isEmpty()) {
                int resId = mContext.getResources().getIdentifier(
                        "flag_" + mServer.getFlagIso(), "drawable", mContext.getPackageName());
                if (resId != 0) {
                    h.imgCountry.setImageResource(resId);
                }
            } else if (mServer.getFlagIcon() != 0) {
                h.imgCountry.setImageResource(mServer.getFlagIcon());
            }

            h.txtCountryName.setText(mServer.getCountry());
            h.layout.setOnClickListener(view -> {
                selectedIndex = mServer.getIndex();
                notifyDataSetChanged();
                onNewServerSelectedListener.onNewServerSelected(mServer);
            });
            if (mServer.getIndex() == selectedIndex) {
                h.layout.setBackground(ContextCompat.getDrawable(mContext, R.drawable.rounded_background));
                h.imgSelected.setVisibility(View.VISIBLE);
            } else {
                h.layout.setBackground(ContextCompat.getDrawable(mContext, R.drawable.rounded_border));
                h.imgSelected.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Utils.getErrors(e);
        }
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    public static class HeaderViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtHeader;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            txtHeader = itemView.findViewById(R.id.txtHeader);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView txtCountryName;
        private final ImageView imgCountry;
        private final ImageView imgSelected;
        private final ConstraintLayout layout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgCountry = itemView.findViewById(R.id.imgCountry);
            imgSelected = itemView.findViewById(R.id.imgSelected);
            txtCountryName = itemView.findViewById(R.id.txtCountryName);
            layout = itemView.findViewById(R.id.layout);
        }
    }
}
