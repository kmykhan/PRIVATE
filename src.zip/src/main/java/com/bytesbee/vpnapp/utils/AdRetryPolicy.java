package pvt.zalmiltd.vpn.utils;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

/**
 * Exponential-backoff retry scheduler for the AdMob -> Yandex waterfall.
 *
 * WHY THIS EXISTS
 * Before this class, the waterfall in Utils/UIApplication was one-shot: AdMob
 * was asked once, and on no-fill the code fell through to Yandex and stopped.
 * If Yandex also failed, nothing was left holding an ad and nothing ever asked
 * again for the rest of the session -- firstLoadAds() was only called from the
 * onAdDismissed callbacks, which can never fire when no ad was ever loaded.
 * A single transient failure at launch (slow network, a moment of no-fill)
 * therefore killed ad revenue until the user restarted the app.
 *
 * No-fill is normal and temporary. AdMob returns ERROR_CODE_NO_FILL routinely
 * for low-value or over-supplied inventory and fills fine seconds later, which
 * is exactly why Google's own guidance is to retry with exponential backoff
 * rather than give up.
 *
 * WHY BACKOFF AND NOT A FIXED INTERVAL
 * Retrying every few seconds hurts three ways: it burns battery and data on a
 * VPN app that is already running a tunnel, it drags the publisher's fill rate
 * down (requests counted, impressions not), and repeated rapid requests for an
 * ad unit that is not filling look like invalid traffic. Doubling the delay
 * keeps the early retries responsive while the tail stays cheap.
 *
 * Delays: 4s, 8s, 16s, 32s, 64s, then capped at 64s, up to MAX_RETRIES.
 * Every retry runs the FULL waterfall again (AdMob first, then Yandex), so a
 * recovered AdMob always wins back priority instead of the app being stuck on
 * the fallback network for the rest of the session.
 */
public class AdRetryPolicy {

    private static final String TAG = "AdRetryPolicy";

    /** First backoff step. Doubles from here. */
    private static final long BASE_DELAY_MS = 4_000L;

    /** Ceiling for a single wait, so the tail does not grow unbounded. */
    private static final long MAX_DELAY_MS = 64_000L;

    /**
     * Give up after this many consecutive failures. Capped deliberately: past
     * roughly this point the failure is almost never transient no-fill but
     * something structural -- no network, a disabled ad unit, a policy hold on
     * the account -- and more requests will not fix any of those.
     */
    private static final int MAX_RETRIES = 6;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String name;

    private int attempt = 0;
    private boolean scheduled = false;

    /** @param name short label for logging, e.g. "interstitial" or "appopen". */
    public AdRetryPolicy(@NonNull String name) {
        this.name = name;
    }

    /**
     * Call when BOTH networks have failed for this slot.
     *
     * @param retryAction re-runs the whole waterfall from the top. Runs on the
     *                    main thread.
     * @return true if a retry was scheduled, false if the budget is spent.
     */
    public boolean scheduleRetry(@NonNull Runnable retryAction) {
        if (scheduled) {
            // A retry is already pending. Without this guard, two callbacks
            // failing close together (AdMob and Yandex often do) would queue
            // two chains that then both double independently.
            return true;
        }

        if (attempt >= MAX_RETRIES) {
            Log.w(TAG, name + ": giving up after " + attempt + " attempts");
            return false;
        }

        long delay = Math.min(BASE_DELAY_MS * (1L << attempt), MAX_DELAY_MS);
        attempt++;
        scheduled = true;

        Log.d(TAG, name + ": retry " + attempt + "/" + MAX_RETRIES + " in " + (delay / 1000) + "s");

        handler.postDelayed(() -> {
            scheduled = false;
            retryAction.run();
        }, delay);

        return true;
    }

    /**
     * Call the moment EITHER network fills. Resets the ladder so the next dry
     * spell starts again at 4s instead of inheriting an already-long delay.
     */
    public void reset() {
        if (attempt != 0) Log.d(TAG, name + ": filled, backoff reset");
        attempt = 0;
        handler.removeCallbacksAndMessages(null);
        scheduled = false;
    }

    /**
     * Drop any pending retry. Call from onDestroy of whatever owns this, so a
     * queued Runnable cannot fire against a finished Activity.
     */
    public void cancel() {
        handler.removeCallbacksAndMessages(null);
        scheduled = false;
    }

    /** True while waiting on a scheduled retry. Useful for skipping duplicate loads. */
    public boolean isRetryPending() {
        return scheduled;
    }
}
