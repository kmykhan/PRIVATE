package pvt.zalmiltd.vpn.fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.activity.MainActivity;
import pvt.zalmiltd.vpn.adapter.ServerListAdapter;
import pvt.zalmiltd.vpn.constants.IConstants;
import pvt.zalmiltd.vpn.managers.SessionManager;
import pvt.zalmiltd.vpn.models.Server;
import pvt.zalmiltd.vpn.utils.Utils;
import com.google.gson.Gson;

// AdMob (GMA Next-Gen SDK), Yandex fallback — for the single bottom-anchored
// banner. MOVED here from ServerListAdapter (see that class's comment): a
// banner belongs once, outside the scrolling list, not reloaded per row
// inside it.
import com.google.android.libraries.ads.mobile.sdk.banner.AdSize;
import com.google.android.libraries.ads.mobile.sdk.banner.AdView;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAd;
import com.google.android.libraries.ads.mobile.sdk.banner.BannerAdRequest;
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback;
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError;
import com.yandex.mobile.ads.banner.BannerAdEventListener;
import com.yandex.mobile.ads.banner.BannerAdSize;
import com.yandex.mobile.ads.banner.BannerAdView;

public class FreeServersFragment extends Fragment {
    private RecyclerView recyclerView;
    private AdView admobBanner;
    private BannerAdView yandexBanner;

    public FreeServersFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_free_servers, container, false);
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setHasFixedSize(true);
        admobBanner = view.findViewById(R.id.adViewID);
        yandexBanner = view.findViewById(R.id.yandexBannerAdView);
        loadBottomBannerAd();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        setRecyclerView();
    }

    // ── AdMob banner load, Yandex fallback — single banner, loaded once for
    // this screen instead of once per list row. ──────────────────────────────
    private void loadBottomBannerAd() {
        if (getContext() == null) return;
        admobBanner.setVisibility(View.VISIBLE);
        yandexBanner.setVisibility(View.GONE);

        String adUnitId = getString(R.string.banner_app_id);
        BannerAdRequest adRequest = new BannerAdRequest.Builder(adUnitId, AdSize.BANNER).build();

        admobBanner.loadAd(adRequest, new AdLoadCallback<BannerAd>() {
            @Override
            public void onAdLoaded(@NonNull BannerAd bannerAd) {
                // Next-Gen SDK fires this on a background coroutine thread, not
                // the main thread — touching views here directly would crash
                // with ViewRootImpl$CalledFromWrongThreadException.
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (getContext() == null) return;
                    admobBanner.setVisibility(View.VISIBLE);
                    yandexBanner.setVisibility(View.GONE);
                });
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (getContext() == null) return;
                    admobBanner.setVisibility(View.GONE);
                    loadYandexBottomBannerAd();
                });
            }
        });
    }

    private void loadYandexBottomBannerAd() {
        if (getContext() == null) return;
        String adUnitId = getString(R.string.yandex_banner_id);
        yandexBanner.setAdSize(BannerAdSize.sticky(getContext(), 320));

        yandexBanner.setBannerAdEventListener(new BannerAdEventListener() {
            @Override
            public void onAdLoaded() {
                yandexBanner.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(@NonNull com.yandex.mobile.ads.common.AdRequestError error) {
                yandexBanner.setVisibility(View.GONE);
            }

            @Override public void onAdClicked() {}
            @Override public void onImpression(com.yandex.mobile.ads.common.ImpressionData impressionData) {}
        });

        com.yandex.mobile.ads.common.AdRequest request =
                new com.yandex.mobile.ads.common.AdRequest.Builder(adUnitId).build();
        yandexBanner.loadAd(request);
    }

    private java.util.List<Server> shownItems;
    private final Handler listRefresh = new Handler(android.os.Looper.getMainLooper());

    @Override
    public void onPause() {
        listRefresh.removeCallbacksAndMessages(null);
        super.onPause();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setRecyclerView() {
        if (!isAdded() || recyclerView == null) return;
        if (!MainActivity.serversLoaded || MainActivity.items == null || MainActivity.items.isEmpty()) {
            // Servers abhi load nahi hue — retry after delay
            new Handler().postDelayed(this::setRecyclerView, 500);
            return;
        }
        // FIXED: used to compare only the item COUNT, so a freshly loaded list
        // with the same number of servers (renamed servers, changed IPs, ...)
        // never replaced the cached one on screen. MainActivity swaps in a
        // new list object on every load, so compare the list itself, and keep
        // checking while this screen is open so a load that finishes after it
        // opened still shows up.
        if (recyclerView.getAdapter() != null && shownItems == MainActivity.items) {
            if (isResumed()) listRefresh.postDelayed(this::setRecyclerView, 1000);
            return;
        }
        shownItems = MainActivity.items;
        ServerListAdapter serverListAdapter = new ServerListAdapter(getActivity(), MainActivity.items, server -> {
            Utils.sout(server.getCountry());
            SessionManager.get().saveServer(server);
            android.util.Log.w("AdPolicyDebug", "Server row tapped (" + server.getCountry() + ") -> Utils.showIntAds()");
            Utils.showIntAds(getActivity(), myHandler);
        });
        recyclerView.setAdapter(serverListAdapter);
        serverListAdapter.notifyDataSetChanged();
    }

    private final Handler myHandler = new Handler(message -> {
        Server server = SessionManager.get().getServer();
        Intent intent = new Intent(getActivity(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.putExtra(IConstants.BUNDLE_KEY_SERVER, new Gson().toJson(server));
        startActivity(intent);
        return true;
    });
}