package pvt.zalmiltd.vpn.managers;

import android.content.Context;

import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import java.util.HashMap;
import java.util.Map;

import pvt.zalmiltd.vpn.BuildConfig;
import pvt.zalmiltd.vpn.utils.UrlCipher;
import pvt.zalmiltd.vpn.utils.Utils;

/**
 * ADDED: wraps Firebase Remote Config so the servers-list source URL can be
 * changed from the Firebase Console without an app update — no more editing
 * a hardcoded constant in ServerLoader and re-publishing to the Play Store
 * just to point the app at a different JSON source.
 *
 * Falls back to DEFAULT_SERVERS_API_URL (the same GitHub raw JSON URL the
 * app used to hardcode) whenever Remote Config hasn't fetched a value yet —
 * first-ever launch before any fetch completes, offline, Remote Config
 * outage, etc. The app should never be left with no server source at all.
 */
public class RemoteConfigManager {

    // CHANGED: every server-source URL is now stored AES-256-GCM encrypted,
    // in these defaults AND in the Firebase Console (encode new values with
    // encode_urls.py in the project root), so none of them exists as a plain
    // string in the APK. A console value that does not decrypt with this
    // app's key (e.g. a plain URL pasted by mistake) is ignored and the
    // default below is used instead.
    //
    // servers_api_url: OpenVPN admin panel list (was https://zalmiltd.cloud/api/v1/list).
    private static final String DEFAULT_SERVERS_API_URL =
            "2bPXWZzKVZ0hydNMMg6ISnQJ5gHzQcPXqlZbP48KOWP3U2IOczuk0Sw8q9UqAw2510PGBsfvxxeHQTQR7ug=";

    // openconnect_list_urls: comma-separated mirrors of the OpenConnect
    // (AnyConnect) panel. hydra_list_url: first page of the Hydra (VLESS +
    // REALITY) list. Set either to an empty string in the console to hide
    // that group of servers.
    private static final String DEFAULT_OPENCONNECT_LIST_URLS =
            "19WSpWgGejLUWqKM8bkXcvRiwUZrxrN8P2GonEdQHA4zhaXqI8ruypVbLDkEj++0EYcX1xGgAmbswQh917oxR39wCX0ozaX0WVrOXxR0CpiJz00rgtl9qdDlfDIMRCc/5cN0yaNaJzMAa0xuXJLNZeYS6/0ujhgLjBAWZxtYXdk+REzP9TlmB2B9QGk5n3l3VGlA1+9OolvuLBRHnOU++WWENtUchTig71bQ6b47y42wVoKMdUw3FqYpCqpzHg==";
    private static final String DEFAULT_HYDRA_LIST_URL =
            "xnsn4UnvLYd42CiAzZFZpss0qwLt8DbGzUZMjWsP0oLHABiZSmUYYIr4Nm9A19srYk604/kK+IWbdVmuW50=";

    private static final String KEY_SERVERS_API_URL = "servers_api_url";
    private static final String KEY_OPENCONNECT_LIST_URLS = "openconnect_list_urls";
    private static final String KEY_HYDRA_LIST_URL = "hydra_list_url";
    private static final String KEY_HYDRA_EXTRA_SERVERS = "hydra_extra_servers";

    // hydra_extra_servers: the app's own Hydra (VLESS + REALITY) servers, a JSON
    // array of {country_code, city_name, status, link}, shown next to the Hydra
    // list. Set to an empty string in the console to hide them.
    private static final String DEFAULT_HYDRA_EXTRA_SERVERS =
            "v8tZttnbpPgr82hhzan7AQPPYjq2/ACuJK5kZHHhkL78ULaA4qgR39vNSdZOvFowQlky+apS8iNxaL7tiF8hz43rrJY2YC4/PWUe92svEo3tCsRDMvGqfJhpU9aVVcL7oq9xnCCJ4tPG8RSWLh8qMwZqV5gkyK2VkcKWRgflbs033pciYwPeXud1Ni6/xqoaH6bI4A5g6UuxY0I7ncce1URAnREyeo/EzykGJxEYnLD3ZngTaND++PKwvYr7HJqfaSwTt3MN10lE2kga8nY0s7Vbsx4EUhKXmAkQbjfeLJaBTHRBT5CZyV0z4wdmVZOERtovR6fg18vhBmlrgmm5CQC6NKSWZk6k+o+d6XJderXsR3s1K6MhHGiFbJIPiFU0wpWi/JEaHfLKS3uOK/l7DCt6OiWQq0whWJMSqRLi5IfRpYSyDu7mmnH50ltu5wrbXEaprFhqSAMJwsF46yFqI/KRdqQOfYeyYVP92i9+gBTB97RioDtrUyDYeL1gi2Wx1UUWOghBiCHmhdJA5HSezAoOQk09+HTw9+6S/Yy6Pg9OHQPPKZnI0Vhrpv3Dieue6/lzpx/NlQDgv+IMdLAOXgNy6DAKrDSY2XoYaGzegWGdYbYDenko4udsNJUF8pNyZEFzAgcnHvghd/v8x56f/oLfYnWondRrcdldlbbOa2djwqCcoq5Jo6r5wfMk67CBIFQP+O1fx0wpAsqRp0mxsMHbBJh1igmlbYc8RDyL4jCMQg/fLV/0Xt39BaazCVxWpULfLSBLrntm219gJJUjVn4k7ad4DUND+WLQ7pw0sQ8E/uk/C1DATbQ2XSSclFxVzpMExFEg8ykgBg1K/5rcAFxmhgFSns4AWeaueKQAu/I4loLYja5IFbYDFv1lsBuIbgXbFUiRpevO16EfrGFtEy36gYmtWbWOIdntEGLuu2horc9LUwPy2DCeNeGjp26La+RJWHXfbPlqVDL3Vo+UOXrNgz3c+nIqYXbk9VTYG1Givq5fW0vysq+iXROGRZRDBuKOXOyXBBPVFfXNDiBbM8rzZEw1KOCa+jjNvjOqn4zkCdiTUoHXMqBKMNQloMzIXYa/QwYcWxlQtiBkP30El691bR585hmVfw2ey02vDoLQn9xYbuFTouclmL7ufL8K/65/VGP8qohjLvM0TYLfRt1PUm7NeUyrL5QPJUg3LKIkUVXoJgJj1JtI6tkmjXTmb1IEFXK24Msf7tBVfTGBX3utmYhYrlk71YPyGFylr8VFiquXq9fbLOwd+Kf4+2cR+vE3VFkhfJF4mxKw850BLhoK5dQK2npPJhZ4rmUzmVh3RJ7ocp2/fOwa9emi9uV1Xo4PaZZ4XYbMf7c=";

    // Remote Config caches fetched values to disk itself, so this only
    // controls how often a FRESH network fetch is allowed — once an hour in
    // release builds is plenty for a value that changes rarely, and 0 in
    // debug builds so changes in the Firebase Console show up immediately
    // while testing.
    private static final long MIN_FETCH_INTERVAL_SECONDS = BuildConfig.DEBUG ? 0L : 3600L;

    private static FirebaseRemoteConfig remoteConfig;

    /** Call once from Application.onCreate(). */
    public static void init(Context context) {
        remoteConfig = FirebaseRemoteConfig.getInstance();

        FirebaseRemoteConfigSettings settings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(MIN_FETCH_INTERVAL_SECONDS)
                .build();
        remoteConfig.setConfigSettingsAsync(settings);

        Map<String, Object> defaults = new HashMap<>();
        defaults.put(KEY_SERVERS_API_URL, DEFAULT_SERVERS_API_URL);
        defaults.put(KEY_OPENCONNECT_LIST_URLS, DEFAULT_OPENCONNECT_LIST_URLS);
        defaults.put(KEY_HYDRA_LIST_URL, DEFAULT_HYDRA_LIST_URL);
        defaults.put(KEY_HYDRA_EXTRA_SERVERS, DEFAULT_HYDRA_EXTRA_SERVERS);
        remoteConfig.setDefaultsAsync(defaults);

        // Fire-and-forget: this app launch uses whatever is already
        // cached/default (see getServersApiUrl() below) — a successful
        // fetch+activate here only affects the NEXT read, which in practice
        // means the next time loadServersFromRemote() runs, later in this
        // same session or on a future launch.
        remoteConfig.fetchAndActivate()
                .addOnFailureListener(e -> Utils.getErrors(new Exception("RemoteConfig fetch failed", e)));
    }

    /** Safe to call anytime, even before init()'s fetch completes — never returns null/empty. */
    public static String getServersApiUrl() {
        String url = UrlCipher.decrypt(rawValue(KEY_SERVERS_API_URL));
        return (url == null || !url.startsWith("http")) ? UrlCipher.decrypt(DEFAULT_SERVERS_API_URL) : url.trim();
    }

    /** OpenConnect list mirrors; empty when disabled from the console. */
    public static java.util.List<String> getOpenConnectListUrls() {
        java.util.List<String> urls = new java.util.ArrayList<>();
        String value = decryptOrDefault(KEY_OPENCONNECT_LIST_URLS, DEFAULT_OPENCONNECT_LIST_URLS);
        if (value == null) return urls;
        for (String part : value.split(",")) {
            String url = part.trim();
            if (url.startsWith("https://")) urls.add(url);
        }
        return urls;
    }

    /** First page of the Hydra list, or null when disabled from the console. */
    public static String getHydraListUrl() {
        String value = decryptOrDefault(KEY_HYDRA_LIST_URL, DEFAULT_HYDRA_LIST_URL);
        return (value == null || !value.trim().startsWith("https://")) ? null : value.trim();
    }

    /** JSON array of the app's own Hydra servers, or null when disabled from the console. */
    public static String getHydraExtraServers() {
        String value = decryptOrDefault(KEY_HYDRA_EXTRA_SERVERS, DEFAULT_HYDRA_EXTRA_SERVERS);
        return (value == null || !value.trim().startsWith("[")) ? null : value.trim();
    }

    private static String rawValue(String key) {
        return remoteConfig == null ? null : remoteConfig.getString(key);
    }

    /**
     * An empty console value switches the source off (null); a value that does not decrypt falls back to the
     * encrypted default, like a missing one.
     */
    private static String decryptOrDefault(String key, String encryptedDefault) {
        String raw = remoteConfig == null ? encryptedDefault : remoteConfig.getString(key);
        if (raw == null || raw.trim().isEmpty()) return null;
        String plain = UrlCipher.decrypt(raw);
        return plain != null ? plain : UrlCipher.decrypt(encryptedDefault);
    }
}