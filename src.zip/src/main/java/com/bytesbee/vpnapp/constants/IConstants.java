package pvt.zalmiltd.vpn.constants;

public interface IConstants {
    String SOUT_MSG_PREFIX = "Prashant :: ";

    // UNUSED as of the AdMob "Site Behavior: Navigation" policy fix — this used
    // to space out ad placeholders spliced into the server list (MainActivity /
    // ServerListAdapter). Ads no longer live inside that list at all, so nothing
    // reads this anymore. Left defined rather than deleted in case any other
    // flavor/module still references it; safe to remove once confirmed unused
    // project-wide.
    int ITEMS_PER_AD = 3;
    int MINUS = -1;
    int ZERO = 0;
    int ONE = 1;

    int USER = 1;
    int SYSTEM = 2;
    int ALL = 3;

    int ALL_APPS = 1;
    int SELECT_NOT = 2;
    int ONLY_SELECT = 3;

    String PATH_ASSET_FOLDER = "file:///android_asset/";

    //Go to /assets folder and replace below files.
    String PRIVACY_POLICY = "h_privacy_policy.html";
    String TERMS_OF_USE = "h_terms_of_service.html";

    String BUNDLE_KEY_SERVER = "key_server";

    /**
     * Do not change anything from the below text.
     */
    String CONNECTED = "CONNECTED";
    String DISCONNECTED = "DISCONNECTED";
    String WAIT = "WAIT";
    String AUTH = "AUTH";
    String RECONNECTING = "RECONNECTING";
    String NO_NETWORK = "NONETWORK";
    String AUTH_FAILED = "AUTH_FAILED";
    String USERPAUSE = "USERPAUSE";
    String CONNECTRETRY = "CONNECTRETRY";
    String ASSIGN_IP = "ASSIGN_IP";
    //    String EXITING = "EXITING";

    int MY_IP = 1;
    int VPN_IP = 2;
}