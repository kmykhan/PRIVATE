package pvt.zalmiltd.vpn.utils;

/**
 * ADDED: shared OpenVPN client identity used for every server that comes
 * from the admin-panel API (ServerLoader's new flat-JSON format:
 * {ip,protocol,port,vpn_username,vpn_password,...} with no ready-made
 * .ovpn/cert of its own).
 *
 * Ported straight from the same CA/cert/key/TA values already used in the
 * com.bannu.vpn and com.techbuzz.uaevpnpro projects against this exact
 * backend — every server behind that API shares this one client identity;
 * only the "remote <ip> <port>" line changes per server (built at runtime
 * in OvpnConfigBuilder).
 */
public final class ApiServerSecrets {

    private ApiServerSecrets() {
    }

    public static final String CA_CERT =
            "-----BEGIN CERTIFICATE-----\n" +
                    "MIIDNjCCAh6gAwIBAgIUSAJCqpQO+ikJFfD9+4MLN2cDcm0wDQYJKoZIhvcNAQEL\n" +
                    "BQAwDzENMAsGA1UEAwwEenZwbjAeFw0yNTA0MjExODA0NDJaFw0yODAxMTYxODA0\n" +
                    "NDJaMA8xDTALBgNVBAMMBHp2cG4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\n" +
                    "AoIBAQDWyeSIRsDg9mqt8CN7QJ6HFqFaZdC3mvkdJ4RReAV6a4rIfpfJGfjUB3Dl\n" +
                    "yN6EcLoiqBdW4q61BEBH4VPzJzoxQxbwmyW+C4xYlejGO9pyUqxgdTpRkkhCcV+5\n" +
                    "FXAq22nTmIkBXdpVN+1+xMbn3sPIpoonFYXCQfctpLjYCqrypMyueZ4SFsiYRZni\n" +
                    "cg3GFxohQEqc00q/k8+O3GhTyofXoFOR2EVKcQFHSV2KpEEVl5Dw1DSFfHUb4GFI\n" +
                    "Ve68TabHrlgXiIeGueaUMLASlKXBbnx747LEbpzwWzTYzcE1oH86QAe+mrcoNGt0\n" +
                    "lNaPrGrE+OFztNynX2zEDLwEQw7TAgMBAAGjgYkwgYYwDAYDVR0TBAUwAwEB/zAd\n" +
                    "BgNVHQ4EFgQUi41zrPe3cin3Rmd+xNQjqEOUSc0wSgYDVR0jBEMwQYAUi41zrPe3\n" +
                    "cin3Rmd+xNQjqEOUSc2hE6QRMA8xDTALBgNVBAMMBHp2cG6CFEgCQqqUDvopCRXw\n" +
                    "/fuDCzdnA3JtMAsGA1UdDwQEAwIBBjANBgkqhkiG9w0BAQsFAAOCAQEAQUHhAHRC\n" +
                    "ZE5Q6nTeVAvu2l+QfV47KbxR5Pt00g+56+kFWWnjICTgR0Rq75Kx6UNfhO7+Y/jh\n" +
                    "RwlGC8yQxUFGHEs08sD5E09/SQOb5k+ttipPRT+3v3yT05JH0+cUAuTMqxL0nDKu\n" +
                    "VHeRqwclAWsOKga6EoMS8zSkYfhsUJ1fimFSK4DUk4uHlfAdv1yrEKabM9+AH2Z3\n" +
                    "Ae6gjpZ/qEWYpQTMwEfrv4gp5X7mVCV32iLlKyDHtVe6KfLvbArZdhNP7GZB0I1M\n" +
                    "+/e5JQEgt+K+mC8WEEJtYxO61sJgySHGxC69lI/V5gGlMhco0f6KMgqGa3RjTN0+\n" +
                    "FJzWT2RFT9Qx9A==\n" +
                    "-----END CERTIFICATE-----\n";

    public static final String CLIENT_CERT =
            "-----BEGIN CERTIFICATE-----\n" +
                    "MIIDRjCCAi6gAwIBAgIRAMrwmdI7jgzQajZVJpVzy3UwDQYJKoZIhvcNAQELBQAw\n" +
                    "DzENMAsGA1UEAwwEenZwbjAeFw0yNTA0MjExODA0NDNaFw0yNzA3MjUxODA0NDNa\n" +
                    "MBAxDjAMBgNVBAMMBXp2cG4wMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC\n" +
                    "AQEAytSz+8PTE9CazxuaJqGjY+1NT+UT4jOkGkqCpR1X5LUYqLLwzOnnK/hGhS2X\n" +
                    "zuUycD0N0CK32LrRojpytwTgCDwxhR1S5IfO0ntrm7VNVDGUXPfwozaQE90fedeH\n" +
                    "HkGqlzoBtKPImvOn7D+khXLXFNAQAuvcvr6VtH2hFCUJpbBsSCw/XRZMLUkaiiNC\n" +
                    "+uGopP6IawoTeRmLT5Sb1HzhjLM10thxfpRFgckBEVsvla9YoP5BQSvGln3PUx/D\n" +
                    "a9Ro52QQx8b07I8HrHZuGThXGdLIH473BslaoML5VN79P5jk5SLEteHCsokglT51\n" +
                    "FwzI3b3GMqfzL4AM5ReG6J47MQIDAQABo4GbMIGYMAkGA1UdEwQCMAAwHQYDVR0O\n" +
                    "BBYEFG5sET8Ql+r+CMbsiw6w5c4x736oMEoGA1UdIwRDMEGAFIuNc6z3t3Ip90Zn\n" +
                    "fsTUI6hDlEnNoROkETAPMQ0wCwYDVQQDDAR6dnBughRIAkKqlA76KQkV8P37gws3\n" +
                    "ZwNybTATBgNVHSUEDDAKBggrBgEFBQcDAjALBgNVHQ8EBAMCB4AwDQYJKoZIhvcN\n" +
                    "AQELBQADggEBAByqxrhQd+2o5q1Y9nFPQFqECfH1jnL4KWDsyVwEoq80TKhmsWw0\n" +
                    "Imgbiv54oxcis5tWOTCKEg/sUiPeZDPi9mx6ll7qbwPU6jeq1CPv8LKc31lns4J2\n" +
                    "H9jcDqi7XuA7WOf/Yrq4b1xWM0aWmGLRIHSXjwSxXHQ8J6UpHuNc5OSyBPnFchyp\n" +
                    "u1FF21NTWdse3Ny3C8hXdqMO1p6T89JnSKyU6YDXWdfHJGpWDhzxkLHHsvEotI0h\n" +
                    "taxkXqwUAHNFG495EQflaAenoygU+A74eSlhX8D7h7tWpygtNYCXkgarOiLMdc4G\n" +
                    "MKJAcfhoR3wpAsiYvppRGYYnTLGPjEBIlyo=\n" +
                    "-----END CERTIFICATE-----\n";

    public static final String CLIENT_KEY =
            "-----BEGIN PRIVATE KEY-----\n" +
                    "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDK1LP7w9MT0JrP\n" +
                    "G5omoaNj7U1P5RPiM6QaSoKlHVfktRiosvDM6ecr+EaFLZfO5TJwPQ3QIrfYutGi\n" +
                    "OnK3BOAIPDGFHVLkh87Se2ubtU1UMZRc9/CjNpAT3R9514ceQaqXOgG0o8ia86fs\n" +
                    "P6SFctcU0BAC69y+vpW0faEUJQmlsGxILD9dFkwtSRqKI0L64aik/ohrChN5GYtP\n" +
                    "lJvUfOGMszXS2HF+lEWByQERWy+Vr1ig/kFBK8aWfc9TH8Nr1GjnZBDHxvTsjwes\n" +
                    "dm4ZOFcZ0sgfjvcGyVqgwvlU3v0/mOTlIsS14cKyiSCVPnUXDMjdvcYyp/MvgAzl\n" +
                    "F4bonjsxAgMBAAECggEAEzMCHG1DYCdJWBxhQZHgUPen702cTbecq35tEmsOJFB+\n" +
                    "Fo3lnEfxwWg9aKLRsVxho10sHw0CQQoiCMymiit0d2MXPuXxMD+otKTJIVKOkM8m\n" +
                    "n4w6o4BpL/Ao6BQeLp+BodH0UmCEfyJcPVEi5hziPg6ZzWT9HrMUoaKYqjr9SEkZ\n" +
                    "CnLhLrAN0Z4Zy9iIcaU8nbocMQaLkgzSPbl182TDrxigVc+P9ZzskwhuZjJxf+ge\n" +
                    "K9uadGDjWKy+5VUNVY4AakQdzA8b1tQAHCppRH6F8V/zQqomnzyJiKIPzjefH+kD\n" +
                    "gNKJ1ws7NEv/RjTtYEjYODEwPU2Gf6yi2Dt8KLbtPwKBgQD6TLhec0PdVasXb/EW\n" +
                    "ya9KiuRIC/sCeGL4OW7g+ngBRzqoBWWgG4yL+ceC+cubQlblWCKLCdI4G2/7dEhM\n" +
                    "ApcHH31ZSvoe0J8OCpeTElCWuRp8vM6JAK8YNF2hqx0JGLNwIUq2GvfOcfMyQ10E\n" +
                    "Y1XZnvIcndmUhx/Zs7tptn+o7wKBgQDPczvFSEXA38AKU4Xe7tT4Mc0V4Z4yd2bQ\n" +
                    "YwT/ds3icZKTWwTu7UJGYJ3AwO1fCQ9c+xRGpsxFBdTLLjiPltNzZA3q9fwSF+Zc\n" +
                    "ykUjfuseCZwP75Q92WdgWwoFYsK+i3VWURQimHnnZX2fKUlDwOPqWofiWCyHVrkx\n" +
                    "CB7WRSkd3wKBgQD3SUzto5ts1PKP2Tyrct8IGmim9Y8sRZwh+TwecdaWDLVawtpA\n" +
                    "cHdO45vFPt11qvkG5ShbjXxvikv8dknnLrffhbDlwzmRsDM0QCq4VuPfxUjx6+dx\n" +
                    "W4ehtjq7Or8Y+ZpuMbYKbGJfSB0pj3walbl/o5U3yIvqPgWto/CI5JEDaQKBgQDJ\n" +
                    "0nMQ8Moj5csAgNeZ1sNNH65FnnV45Z8aF2uSWfPdXN7cC04WYK78pxxynX+R2M+g\n" +
                    "hwjn33iVoiGu9i3CzFq1RV8g+uWceLH+Di8LZHu7gl/ZRRz0uyCOpqNuL/IEzMqA\n" +
                    "CmtLaQoYLC31/YWwq+VQZ3kRpPTVSnLrF9pgXXKuAwKBgQDM8yofX792Za5+PS0e\n" +
                    "1uP6LjgB5sT1opWcu0sq9EyPmoO5xRVRMl2eEWVJqpnd7bpsh0ceawKFMQEQTEgg\n" +
                    "dp4ZBXBq4I+IZqDX7YiFtlm7rG1XFJ2wBafQhzYLFPnqbywVCRjkGfIeupvcAgMq\n" +
                    "clGwI7WmyBndkkt37z82YQTgZQ==\n" +
                    "-----END PRIVATE KEY-----\n";

    // 2048-bit static key, used via the OpenVPN "tls-crypt" directive (NOT
    // tls-auth) — see OvpnConfigBuilder. Confirmed by com.bannu.vpn's own
    // profile builder: tlsAuthDirection = "tls-crypt".
    public static final String TA =
            "-----BEGIN OpenVPN Static key V1-----\n" +
                    "67363a29a16dd3c6272ec3b0389291d3\n" +
                    "808e601c390c73516a73c9e4db061d8c\n" +
                    "9113542d1bdcf4987e77e66c4792f5f8\n" +
                    "e81c4118f0fc3a484f0cc950741b8909\n" +
                    "9d2dd8c8984b4dd4c74705f41404f3aa\n" +
                    "10563b2997a24b6f0435d137dc75bb16\n" +
                    "111555c6c66cf4d1a2360fe8770e26b8\n" +
                    "a811ca0937039e6fd912e0c242159ed1\n" +
                    "ecce72f0c39f49ae90addc7a386de96a\n" +
                    "002aa39256a276c2e13d33f5f48ce08c\n" +
                    "78b8998b52edc4d4b6c12988d3f02df7\n" +
                    "deab04e3a8017f4210715884ee373d57\n" +
                    "855170d451e2ff66344c13c5a32872e3\n" +
                    "afa7824d08da9450f7884ef59223a9b8\n" +
                    "407f9af3a4e071fd824f49efbda6031c\n" +
                    "1ba46f45ec5b28f7b794e6124faa3d0c\n" +
                    "-----END OpenVPN Static key V1-----\n";
}
