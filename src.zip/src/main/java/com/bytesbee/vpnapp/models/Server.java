package pvt.zalmiltd.vpn.models;

public class Server {
    private int index;
    private String country;
    private int flagIcon;       // local drawable (purane hardcoded servers ke liye)
    private String flagIso;     // ISO code e.g. "ae", "us", "gb" (remote JSON ke liye)
    private String ovpn;        // assets filename ya full URL
    private String ovpnUserName;
    private String ovpnUserPassword;

    // ADDED: which engine connects to this server. null (older cached lists)
    // and TYPE_OPENVPN both mean OpenVPN.
    public static final String TYPE_OPENVPN = "openvpn";
    public static final String TYPE_OPENCONNECT = "openconnect";
    public static final String TYPE_HYDRA = "hydra";

    private String vpnType;
    private String host;        // OpenConnect: server address (credentials in ovpnUserName/Password)
    private String hydraLink;   // Hydra: vless:// share link

    public Server() {
    }

    public String getVpnType() { return vpnType == null ? TYPE_OPENVPN : vpnType; }
    public void setVpnType(String vpnType) { this.vpnType = vpnType; }

    public String getHost() { return host; }
    public void setHost(String host) { this.host = host; }

    public String getHydraLink() { return hydraLink; }
    public void setHydraLink(String hydraLink) { this.hydraLink = hydraLink; }

    // Purana constructor — assets-based servers ke liye (backward compatible)
    public Server(String country, int flagIcon) {
        this.country = country;
        this.flagIcon = flagIcon;
    }

    // Purana constructor — assets-based
    public Server(String country, int flagIcon, String ovpn) {
        this.country = country;
        this.flagIcon = flagIcon;
        this.ovpn = ovpn;
    }

    // Purana constructor — assets-based with credentials
    public Server(String country, int flagIcon, String ovpn, String ovpnUserName, String ovpnUserPassword) {
        this.country = country;
        this.flagIcon = flagIcon;
        this.ovpn = ovpn;
        this.ovpnUserName = ovpnUserName;
        this.ovpnUserPassword = ovpnUserPassword;
    }

    // NAYA constructor — remote JSON ke liye (ISO code + URL)
    public Server(String country, String flagIso, String ovpn, String ovpnUserName, String ovpnUserPassword) {
        this.country = country;
        this.flagIso = flagIso;
        this.ovpn = ovpn;
        this.ovpnUserName = ovpnUserName;
        this.ovpnUserPassword = ovpnUserPassword;
    }

    public int getIndex() { return index; }
    public void setIndex(int index) { this.index = index; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public int getFlagIcon() { return flagIcon; }
    public void setFlagIcon(int flagIcon) { this.flagIcon = flagIcon; }

    public String getFlagIso() { return flagIso; }
    public void setFlagIso(String flagIso) { this.flagIso = flagIso; }

    public String getOvpn() { return ovpn; }
    public void setOvpn(String ovpn) { this.ovpn = ovpn; }

    public String getOvpnUserName() { return ovpnUserName; }
    public void setOvpnUserName(String ovpnUserName) { this.ovpnUserName = ovpnUserName; }

    public String getOvpnUserPassword() { return ovpnUserPassword; }
    public void setOvpnUserPassword(String ovpnUserPassword) { this.ovpnUserPassword = ovpnUserPassword; }
}