package pvt.zalmiltd.vpn.utils;

import android.util.Base64;

import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * ADDED: decrypts the server-source URLs that come from Firebase Remote Config (and the defaults baked into
 * RemoteConfigManager), so none of the admin panel / server list addresses exist as plain strings in the APK.
 *
 * Stored form is Base64(12-byte IV + AES-256-GCM ciphertext + tag), produced by encode_urls.py in the project root.
 * The key is split into 4 pieces that are only combined at the point of use. This stops casual scraping and static
 * analysis (jadx/apktool/strings), not someone hooking decrypt() at runtime. Never reuse this key in another app.
 */
public final class UrlCipher {

    private static final byte[] K1 = {(byte) 0x2E, (byte) 0x12, (byte) 0x37, (byte) 0x78, (byte) 0x0F, (byte) 0xE1, (byte) 0x9E, (byte) 0xB0};
    private static final byte[] K2 = {(byte) 0xB1, (byte) 0x6D, (byte) 0x38, (byte) 0x89, (byte) 0x01, (byte) 0xDC, (byte) 0x5A, (byte) 0x9B};
    private static final byte[] K3 = {(byte) 0x00, (byte) 0x23, (byte) 0xAA, (byte) 0x7D, (byte) 0x7A, (byte) 0x7C, (byte) 0xB4, (byte) 0xE4};
    private static final byte[] K4 = {(byte) 0x14, (byte) 0x9F, (byte) 0x83, (byte) 0xA0, (byte) 0x03, (byte) 0xE0, (byte) 0xDD, (byte) 0x8C};

    private UrlCipher() {
    }

    /** @return the plain text, or null when [encoded] is empty or not a value encrypted with this app's key. */
    public static String decrypt(String encoded) {
        if (encoded == null || encoded.trim().isEmpty()) return null;
        try {
            byte[] combined = Base64.decode(encoded.trim(), Base64.NO_WRAP);
            if (combined.length <= 12) return null;
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, combined, 0, 12));
            return new String(cipher.doFinal(combined, 12, combined.length - 12), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    private static SecretKeySpec key() {
        byte[] key = new byte[32];
        System.arraycopy(K1, 0, key, 0, 8);
        System.arraycopy(K2, 0, key, 8, 8);
        System.arraycopy(K3, 0, key, 16, 8);
        System.arraycopy(K4, 0, key, 24, 8);
        return new SecretKeySpec(key, "AES");
    }
}
