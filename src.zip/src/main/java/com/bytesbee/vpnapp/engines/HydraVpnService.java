package pvt.zalmiltd.vpn.engines;

import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import libXray.DialerController;
import libXray.LibXray;
import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.constants.IConstants;
import pvt.zalmiltd.vpn.models.Server;

/**
 * ADDED: Hydra engine (VLESS + REALITY through Xray-core via libXray), ported from UAE VPN Pro's HydraTunnelService.
 *
 * A start does, in order: route libXray's own sockets around the VPN, check the server port, probe the server with a
 * real VLESS + REALITY request, establish the TUN device, hand its fd to Xray-core's tun inbound and start the core.
 * Runs in the main process: this app has no other Go runtime (UAE VPN Pro isolates Hydra only because of
 * wireguard-go).
 */
public class HydraVpnService extends VpnService {

    private static final String TAG = "Hydra";

    private static final String TUN_ADDRESS_V4 = "172.19.0.1";
    private static final int TUN_PREFIX_V4 = 30;
    private static final String TUN_ADDRESS_V6 = "fdfe:dcba:9876::1";
    private static final int TUN_PREFIX_V6 = 126;
    private static final String[] FALLBACK_DNS = {"1.1.1.1", "1.0.0.1"};
    private static final String[] PROBE_URLS = {"https://cp.cloudflare.com/", "https://www.gstatic.com/generate_204"};
    //Measured at ~5-6s for a full REALITY round trip on a slow link, so leave generous headroom
    private static final int PORT_CHECK_TIMEOUT_MS = 4_000;
    private static final int PROBE_TIMEOUT_SECONDS = 10;
    private static final long WATCHDOG_INTERVAL_MS = 5_000L;
    private static final int API_VERSION = 3;
    //pingBatch reports this delay for an item that failed or timed out
    private static final long FAILED_DELAY_MS = 10_000L;

    private static Boolean libraryLoaded;

    //libXray calls block for seconds (probe) and must never run on the main thread
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Object lock = new Object();

    private ParcelFileDescriptor tun;
    private boolean coreRunning;
    private boolean resolverOverridden;
    private volatile boolean cancelled;
    //Incremented on every connect so a slow, superseded start gives up instead of racing the newer one
    private volatile int generation;

    private final DialerController dialerController = new DialerController() {
        @Override
        public boolean protectFd(long fd) {
            //Before the TUN exists nothing needs protecting; afterwards a failed protect must fail the dial
            return protect((int) fd) || tun == null;
        }
    };

    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            worker.execute(() -> {
                if (coreRunning && !cancelled && !isCoreRunning()) {
                    Log.e(TAG, "Xray core is no longer running");
                    shutdown();
                    endSession();
                }
            });
            mainHandler.postDelayed(this, WATCHDOG_INTERVAL_MS);
        }
    };

    /** libgojni.so is bundled for arm64-v8a and armeabi-v7a only; touching LibXray loads it. */
    static synchronized boolean isAvailable() {
        if (libraryLoaded == null) {
            try {
                LibXray.touch();
                libraryLoaded = true;
            } catch (Throwable t) {
                Log.e(TAG, "libXray could not be loaded", t);
                libraryLoaded = false;
            }
        }
        return libraryLoaded;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return super.onBind(intent);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (VpnEngines.ACTION_CONNECT.equals(action)) {
            String name = intent.getStringExtra(VpnEngines.EXTRA_NAME);
            VpnEngines.startForeground(this, getString(R.string.app_name), name == null ? "" : name);

            final String link = intent.getStringExtra(VpnEngines.EXTRA_LINK);
            final ArrayList<String> apps = intent.getStringArrayListExtra(VpnEngines.EXTRA_APPS);
            final boolean appsAllowed = intent.getBooleanExtra(VpnEngines.EXTRA_APPS_ALLOWED, false);
            final int id = ++generation;
            cancelled = false;
            VpnEngines.post(this, Server.TYPE_HYDRA, IConstants.WAIT);
            worker.execute(() -> start(id, link, apps, appsAllowed));
        } else if (VpnEngines.ACTION_DISCONNECT.equals(action)) {
            cancelled = true;
            generation++;
            worker.execute(() -> {
                shutdown();
                endSession();
            });
        } else {
            stopSelf(startId);
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onRevoke() {
        Log.w(TAG, "VPN permission revoked");
        cancelled = true;
        generation++;
        worker.execute(() -> {
            shutdown();
            endSession();
        });
    }

    @Override
    public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        cancelled = true;
        worker.execute(this::shutdown);
        worker.shutdown();
        super.onDestroy();
    }

    private void start(int id, String link, List<String> apps, boolean appsAllowed) {
        //A previous session may have left the core or the resolver override behind
        shutdown();
        if (id != generation) return;

        RealityConfig config = RealityConfig.parseOrNull(link);
        if (config == null || !isAvailable()) {
            fail(id, R.string.strServerUnavailable);
            return;
        }

        List<String> dns = new ArrayList<>();
        for (String server : FALLBACK_DNS) dns.add(server);

        try {
            LibXray.registerDialerController(dialerController);
            LibXray.registerListenerController(dialerController);
            LibXray.setDNS(dialerController, dns.get(0) + ":53");
            resolverOverridden = true;
        } catch (Exception e) {
            Log.e(TAG, "Could not prepare libXray sockets", e);
            fail(id, R.string.strServerUnavailable);
            return;
        }

        //A dead server or blocked port would otherwise cost the full probe timeout, twice
        if (!isPortOpen(config.address, config.port)) {
            fail(id, R.string.strServerUnreachable);
            return;
        }
        if (id != generation) return;

        //A wrong key, short id or user id only shows up as a failing request, so a probe is the only honest test
        String probeJson = config.buildProbeJson();
        boolean reachable = false;
        for (String url : PROBE_URLS) {
            if (id != generation) return;
            if (probe(probeJson, url)) {
                reachable = true;
                break;
            }
        }
        if (!reachable) {
            fail(id, R.string.strServerUnreachable);
            return;
        }
        if (id != generation) return;

        VpnEngines.post(this, Server.TYPE_HYDRA, IConstants.AUTH);
        ParcelFileDescriptor device = establishTun(dns, apps, appsAllowed);
        if (device == null) {
            fail(id, R.string.strServerUnavailable);
            return;
        }
        synchronized (lock) {
            tun = device;
        }
        if (id != generation) {
            shutdown();
            return;
        }

        JsonObject result = invoke("runXray", payload("xrayJson", config.buildXrayJson(device.getFd(), RealityConfig.DEFAULT_MTU)));
        if (!isSuccess(result)) {
            Log.e(TAG, "Xray core failed to start: " + errorOf(result));
            fail(id, R.string.strServerUnavailable);
            return;
        }
        synchronized (lock) {
            coreRunning = true;
        }
        if (id != generation) {
            shutdown();
            return;
        }

        VpnEngines.post(this, Server.TYPE_HYDRA, IConstants.CONNECTED);
        mainHandler.postDelayed(watchdog, WATCHDOG_INTERVAL_MS);
    }

    private ParcelFileDescriptor establishTun(List<String> dns, List<String> apps, boolean appsAllowed) {
        Builder builder = new Builder()
                .setSession(getString(R.string.app_name))
                .setMtu(RealityConfig.DEFAULT_MTU)
                .addAddress(TUN_ADDRESS_V4, TUN_PREFIX_V4)
                .addRoute("0.0.0.0", 0)
                //Without an IPv6 route, IPv6 traffic would keep flowing outside the tunnel
                .addAddress(TUN_ADDRESS_V6, TUN_PREFIX_V6)
                .addRoute("::", 0);

        for (String server : dns) {
            try {
                builder.addDnsServer(server);
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "Ignoring invalid DNS server " + server);
            }
        }
        OpenConnectVpnService.applyAppFilter(builder, getPackageName(), apps, appsAllowed);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false);

        try {
            return builder.establish();
        } catch (Exception e) {
            Log.e(TAG, "Could not establish the TUN device", e);
            return null;
        }
    }

    private void fail(int id, int message) {
        if (id != generation || cancelled) return;
        mainHandler.post(() -> Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show());
        shutdown();
        endSession();
    }

    private void endSession() {
        VpnEngines.post(this, Server.TYPE_HYDRA, IConstants.DISCONNECTED);
        mainHandler.post(() -> {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        });
    }

    /** Undoes everything start() did. Idempotent; runs on the worker. */
    private void shutdown() {
        mainHandler.removeCallbacks(watchdog);

        boolean wasRunning;
        ParcelFileDescriptor device;
        synchronized (lock) {
            wasRunning = coreRunning;
            device = tun;
            coreRunning = false;
            tun = null;
        }

        if (wasRunning) {
            JsonObject stopped = invoke("stopXray", null);
            if (!isSuccess(stopped)) Log.w(TAG, "stopXray: " + errorOf(stopped));
        }
        if (resolverOverridden) {
            resolverOverridden = false;
            try {
                LibXray.resetDNS();
            } catch (Throwable t) {
                Log.w(TAG, "resetDNS failed", t);
            }
        }
        if (device != null) {
            try {
                device.close();
            } catch (Exception e) {
                Log.w(TAG, "Closing the TUN device failed", e);
            }
        }
    }

    private boolean isPortOpen(String host, int port) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), PORT_CHECK_TIMEOUT_MS);
            return true;
        } catch (Exception e) {
            Log.w(TAG, "Server " + host + ":" + port + " does not accept connections: " + e.getMessage());
            return false;
        }
    }

    /**
     * Sends a real request through the outbound in a temporary Xray instance: reachability, the REALITY handshake,
     * the user id and the server's own egress all have to work. Never called while a runXray instance is active.
     */
    private boolean probe(String probeJson, String url) {
        JsonObject item = new JsonObject();
        item.addProperty("xrayJson", probeJson);
        JsonArray configs = new JsonArray();
        configs.add(item);
        JsonObject payload = new JsonObject();
        payload.add("configs", configs);
        payload.addProperty("timeout", PROBE_TIMEOUT_SECONDS);
        payload.addProperty("url", url);

        JsonObject response = invoke("pingBatch", payload);
        if (!isSuccess(response)) return false;
        try {
            JsonObject result = response.getAsJsonObject("data").getAsJsonArray("results").get(0).getAsJsonObject();
            long delay = result.has("delay") ? result.get("delay").getAsLong() : FAILED_DELAY_MS;
            return result.has("success") && result.get("success").getAsBoolean() && delay < FAILED_DELAY_MS;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isCoreRunning() {
        JsonObject response = invoke("getXrayState", null);
        try {
            return isSuccess(response) && response.getAsJsonObject("data").get("running").getAsBoolean();
        } catch (Exception e) {
            return false;
        }
    }

    private static JsonObject payload(String key, String value) {
        JsonObject payload = new JsonObject();
        payload.addProperty(key, value);
        return payload;
    }

    /** libXray's single entry point, API version 3: {apiVersion, method, payload} -> {success, data, error}. */
    private static JsonObject invoke(String method, JsonObject payload) {
        JsonObject request = new JsonObject();
        request.addProperty("apiVersion", API_VERSION);
        request.addProperty("method", method);
        if (payload != null) request.add("payload", payload);
        try {
            JsonElement response = JsonParser.parseString(LibXray.invoke(request.toString()));
            return response.isJsonObject() ? response.getAsJsonObject() : new JsonObject();
        } catch (Throwable t) {
            Log.e(TAG, "libXray " + method + " failed", t);
            return new JsonObject();
        }
    }

    private static boolean isSuccess(JsonObject response) {
        return response != null && response.has("success") && response.get("success").getAsBoolean();
    }

    private static String errorOf(JsonObject response) {
        return response != null && response.has("error") && !response.get("error").isJsonNull()
                ? response.get("error").getAsString() : "";
    }
}
