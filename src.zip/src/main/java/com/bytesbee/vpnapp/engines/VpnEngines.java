package pvt.zalmiltd.vpn.engines;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.ArrayList;
import java.util.Locale;

import pvt.zalmiltd.vpn.R;
import pvt.zalmiltd.vpn.activity.MainActivity;
import pvt.zalmiltd.vpn.constants.IConstants;
import pvt.zalmiltd.vpn.models.Server;

/**
 * ADDED: entry point for the two non-OpenVPN engines, OpenConnect (Cisco AnyConnect / ocserv servers) and Hydra
 * (VLESS + REALITY through Xray-core). Both report to MainActivity exactly like OpenVPNService does, through the
 * "connectionState" local broadcast with the IConstants state names, so the existing UI needs no second code path.
 */
public final class VpnEngines {

    private static final String TAG = "VpnEngines";

    static final String EXTRA_NAME = "name";
    static final String EXTRA_HOST = "host";
    static final String EXTRA_USER = "user";
    static final String EXTRA_PASS = "pass";
    static final String EXTRA_LINK = "link";
    static final String EXTRA_APPS = "apps";
    static final String EXTRA_APPS_ALLOWED = "apps_allowed";

    static final String ACTION_CONNECT = "pvt.zalmiltd.vpn.engine.CONNECT";
    static final String ACTION_DISCONNECT = "pvt.zalmiltd.vpn.engine.DISCONNECT";

    private static final String CHANNEL_ID = "vpn_engine_status";
    static final int NOTIFICATION_ID = 7310;

    private static volatile String state = IConstants.DISCONNECTED;
    private static volatile String activeType;

    private VpnEngines() {
    }

    /** True for servers that one of these engines (and not OpenVPN) connects to. */
    public static boolean handles(Server server) {
        return server != null && !Server.TYPE_OPENVPN.equals(server.getVpnType());
    }

    /** Whether this device can run the engine for [type]; both ship arm64-v8a and armeabi-v7a libraries only. */
    public static boolean isAvailable(String type) {
        if (Server.TYPE_OPENCONNECT.equals(type)) return OpenConnectVpnService.isAvailable();
        if (Server.TYPE_HYDRA.equals(type)) return HydraVpnService.isAvailable();
        return true;
    }

    /** An engine session is connecting or connected. */
    public static boolean isActive() {
        return activeType != null && !IConstants.DISCONNECTED.equals(state);
    }

    public static boolean isConnected() {
        return activeType != null && IConstants.CONNECTED.equals(state);
    }

    /**
     * Starts [server] with its engine. Any other engine session is stopped first; VPN permission must already be
     * granted. [apps] are excluded from the tunnel, or are the only apps routed through it when [appsAllowed].
     */
    public static void start(Context context, Server server, ArrayList<String> apps, boolean appsAllowed) {
        Class<? extends Service> target = serviceFor(server.getVpnType());
        if (target == null) return;

        for (String type : new String[]{Server.TYPE_OPENCONNECT, Server.TYPE_HYDRA}) {
            if (!type.equals(server.getVpnType())) stop(context, type);
        }

        Intent intent = new Intent(context, target)
                .setAction(ACTION_CONNECT)
                .putExtra(EXTRA_NAME, server.getCountry())
                .putExtra(EXTRA_HOST, server.getHost())
                .putExtra(EXTRA_USER, server.getOvpnUserName())
                .putExtra(EXTRA_PASS, server.getOvpnUserPassword())
                .putExtra(EXTRA_LINK, server.getHydraLink())
                .putStringArrayListExtra(EXTRA_APPS, apps == null ? new ArrayList<>() : apps)
                .putExtra(EXTRA_APPS_ALLOWED, appsAllowed);
        try {
            context.startService(intent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start " + target.getSimpleName(), e);
            post(context, server.getVpnType(), IConstants.DISCONNECTED);
        }
    }

    /** Stops every engine session; a no-op when none is running. */
    public static void stopAll(Context context) {
        stop(context, Server.TYPE_OPENCONNECT);
        stop(context, Server.TYPE_HYDRA);
    }

    private static void stop(Context context, String type) {
        Class<? extends Service> target = serviceFor(type);
        if (target == null) return;
        if (!type.equals(activeType)) return;
        try {
            context.startService(new Intent(context, target).setAction(ACTION_DISCONNECT));
        } catch (Exception e) {
            Log.w(TAG, "Could not stop " + target.getSimpleName(), e);
        }
    }

    private static Class<? extends Service> serviceFor(String type) {
        if (Server.TYPE_OPENCONNECT.equals(type)) return OpenConnectVpnService.class;
        if (Server.TYPE_HYDRA.equals(type)) return HydraVpnService.class;
        return null;
    }

    // ---- reporting, used by the engine services ----

    static void post(Context context, String type, String newState) {
        if (IConstants.DISCONNECTED.equals(newState)) {
            if (type.equals(activeType)) activeType = null;
        } else {
            activeType = type;
        }
        state = newState;
        Intent intent = new Intent("connectionState").putExtra("state", newState);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    /** Same "↓total - rate/s" format OpenVPNService uses, which MainActivity already parses. */
    static void postBytes(Context context, long in, long out, long inPerSecond, long outPerSecond) {
        Intent intent = new Intent("connectionState")
                .putExtra("byteIn", "↓" + readable(in) + " - " + readable(inPerSecond) + "/s")
                .putExtra("byteOut", "↑" + readable(out) + " - " + readable(outPerSecond) + "/s");
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    private static String readable(long bytes) {
        if (bytes < 1024) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        return String.format(Locale.US, "%.1f %sB", bytes / Math.pow(1024, exp), "KMGTPE".charAt(exp - 1));
    }

    static void startForeground(Service service, String title, String text) {
        NotificationManager manager = (NotificationManager) service.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, service.getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW));
        }

        PendingIntent open = PendingIntent.getActivity(service, 0,
                new Intent(service, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(service, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            service.startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            service.startForeground(NOTIFICATION_ID, notification);
        }
    }
}
