package pvt.zalmiltd.vpn.utils;

import java.util.Locale;

/**
 * ADDED: builds a full OpenVPN client config on the fly for admin-panel API
 * servers (ServerLoader's new flat-JSON format), which only gives an
 * ip/protocol/port/username/password per server — not a ready-made .ovpn
 * file the way the old GitHub JSON / bundled assets did.
 *
 * Every server from that API shares one client identity (CA/cert/key/TA in
 * ApiServerSecrets — the same ones com.bannu.vpn and com.techbuzz.uaevpnpro
 * already use against this exact backend); only the "remote" line and
 * auth-type change per server. Directives below (tls-crypt, auth SHA256,
 * verb 3, nobind, persist-tun, remote-cert-tls server, push-peer-info, and
 * the AES-256-GCM-vs-AES-256-CBC cipher split for cert-only vs
 * cert+user/pass servers) are copied 1:1 from com.bannu.vpn's own
 * ProfilesRepo.getDefaultProfile() so this connects the same way their
 * already-working app does, just expressed as plain OpenVPN config text
 * for de.blinkt.openvpn's ConfigParser instead of their VPNProfile object.
 */
public final class OvpnConfigBuilder {

    private OvpnConfigBuilder() {
    }

    public static String build(String protocol, String ip, int port, String username, String password) {
        String proto = (protocol == null || protocol.trim().isEmpty())
                ? "udp" : protocol.trim().toLowerCase(Locale.US);

        boolean hasUserPass = username != null && !username.trim().isEmpty();

        // Matches ProfilesRepo.getDefaultProfile(): AES-256-GCM for pure
        // client-cert auth, AES-256-CBC when username/password auth is
        // also required ("AES-256-GCM doesn't work in Android when
        // authentication is required" — their comment, kept here as-is).
        String cipher = hasUserPass ? "AES-256-CBC" : "AES-256-GCM";

        StringBuilder sb = new StringBuilder();
        sb.append("client\n");
        sb.append("dev tun\n");
        sb.append("proto ").append(proto).append("\n");
        sb.append("remote ").append(ip).append(" ").append(port).append("\n");
        sb.append("resolv-retry infinite\n");
        sb.append("nobind\n");
        sb.append("persist-tun\n");
        sb.append("remote-cert-tls server\n");
        sb.append("auth SHA256\n");
        sb.append("cipher ").append(cipher).append("\n");
        sb.append("push-peer-info\n");
        sb.append("verb 3\n");

        if (hasUserPass) {
            // Credentials themselves aren't inlined here — MainActivity
            // sets vpnProfile.mUsername/mPassword from the Server object
            // right after parsing, same as it already does for every
            // other server source. This directive just tells the client
            // to expect/send them.
            sb.append("auth-user-pass\n");
        }

        sb.append("<ca>\n").append(ApiServerSecrets.CA_CERT).append("</ca>\n");
        sb.append("<cert>\n").append(ApiServerSecrets.CLIENT_CERT).append("</cert>\n");
        sb.append("<key>\n").append(ApiServerSecrets.CLIENT_KEY).append("</key>\n");
        sb.append("<tls-crypt>\n").append(ApiServerSecrets.TA).append("</tls-crypt>\n");

        return sb.toString();
    }
}